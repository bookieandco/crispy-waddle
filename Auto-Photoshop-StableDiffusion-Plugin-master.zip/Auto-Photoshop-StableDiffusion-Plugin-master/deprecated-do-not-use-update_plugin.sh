#!/bin/bash
git pull