rootProject.name = "simplejavable"

