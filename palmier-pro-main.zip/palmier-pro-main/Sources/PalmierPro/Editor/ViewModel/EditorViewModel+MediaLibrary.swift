import AppKit
import AVFoundation

enum MediaPanelItemKey {
    static let folderPrefix = "folder-"
    static let timelinePrefix = "timeline-"

    static func folder(_ id: String) -> String {
        folderPrefix + id
    }

    static func folderId(from key: String) -> String? {
        guard key.hasPrefix(folderPrefix) else { return nil }
        return String(key.dropFirst(folderPrefix.count))
    }

    static func timeline(_ id: String) -> String {
        timelinePrefix + id
    }

    static func timelineId(from key: String) -> String? {
        guard key.hasPrefix(timelinePrefix) else { return nil }
        return String(key.dropFirst(timelinePrefix.count))
    }
}

private struct MediaImportPlan: Sendable {
    enum Parent: Sendable {
        case existingFolderId(String?)
        case plannedFolder(Int)
    }

    struct Folder: Sendable {
        let name: String
        let parent: Parent
    }

    struct File: Sendable {
        let url: URL
        let type: ClipType
        let name: String
        let parent: Parent
    }

    var folders: [Folder] = []
    var files: [File] = []
    var rejectedUnsupportedNames: [String] = []
    var rejectedLottieNames: [String] = []
}

private enum MediaImportScanner {
    struct Root: Sendable {
        let url: URL
        let parentFolderId: String?
    }

    static func scan(roots: [Root]) -> MediaImportPlan {
        var plan = MediaImportPlan()
        for root in roots {
            let parent = MediaImportPlan.Parent.existingFolderId(root.parentFolderId)
            if isDirectory(root.url) {
                scanFolder(at: root.url, parent: parent, into: &plan)
            } else {
                scanFile(at: root.url, parent: parent, isRootItem: true, into: &plan)
            }
        }
        return plan
    }

    static func isDirectory(_ url: URL) -> Bool {
        (try? url.resourceValues(forKeys: [.isDirectoryKey]))?.isDirectory ?? false
    }

    private static func scan(entries: [URL], parent: MediaImportPlan.Parent, into plan: inout MediaImportPlan) {
        let sorted = entries.sorted {
            $0.lastPathComponent.localizedStandardCompare($1.lastPathComponent) == .orderedAscending
        }
        for entry in sorted {
            if isDirectory(entry) {
                scanFolder(at: entry, parent: parent, into: &plan)
            } else {
                scanFile(at: entry, parent: parent, isRootItem: false, into: &plan)
            }
        }
    }

    private static func scanFolder(
        at url: URL,
        parent: MediaImportPlan.Parent,
        into plan: inout MediaImportPlan
    ) {
        guard let entries = directoryEntries(at: url) else { return }
        let folderIndex = plan.folders.count
        plan.folders.append(.init(name: url.lastPathComponent, parent: parent))
        scan(entries: entries, parent: .plannedFolder(folderIndex), into: &plan)
    }

    private static func directoryEntries(at url: URL) -> [URL]? {
        try? FileManager.default.contentsOfDirectory(
            at: url,
            includingPropertiesForKeys: [.isDirectoryKey],
            options: [.skipsHiddenFiles]
        )
    }

    private static func scanFile(
        at url: URL,
        parent: MediaImportPlan.Parent,
        isRootItem: Bool,
        into plan: inout MediaImportPlan
    ) {
        guard let type = ClipType(fileExtension: url.pathExtension.lowercased()) else {
            if isRootItem { plan.rejectedUnsupportedNames.append(url.lastPathComponent) }
            return
        }
        if type == .lottie, !LottieVideoGenerator.isLottie(at: url) {
            plan.rejectedLottieNames.append(url.lastPathComponent)
            return
        }
        plan.files.append(.init(
            url: url,
            type: type,
            name: url.deletingPathExtension().lastPathComponent,
            parent: parent
        ))
    }
}

extension EditorViewModel {

    func commitStagedProjectMedia(
        _ stagedURL: URL,
        filename: String,
        maxBytes: Int64? = nil,
        workAlreadyAdmitted: Bool = false
    ) async throws -> URL {
        defer { try? FileManager.default.removeItem(at: stagedURL) }
        guard projectURL != nil else {
            let destination = FileManager.default.temporaryDirectory.appendingPathComponent(filename)
            return try await Task.detached(priority: .userInitiated) {
                try FileIO.moveReplacingDestination(from: stagedURL, to: destination, maxBytes: maxBytes)
                return destination
            }.value
        }
        for _ in 0..<3 {
            guard let targetProjectURL = projectURL else { break }
            try Task.checkCancellation()
            do {
                let preparedURL = try await Task.detached(priority: .userInitiated) {
                    try FileIO.prepareStagedFile(from: stagedURL, nextTo: targetProjectURL, maxBytes: maxBytes)
                }.value
                defer { try? FileManager.default.removeItem(at: preparedURL) }
                try Task.checkCancellation()
                if !workAlreadyAdmitted {
                    try projectPackageCoordinator.beginMutation()
                }
                defer {
                    if !workAlreadyAdmitted {
                        projectPackageCoordinator.endMutation()
                    }
                }
                if let destination = try await projectPackageCoordinator.performMutation({ () -> URL? in
                    guard self.projectURL?.standardizedFileURL == targetProjectURL.standardizedFileURL else { return nil }
                    let destination = targetProjectURL.appendingPathComponent(Project.mediaDirectoryName, isDirectory: true)
                        .appendingPathComponent(filename, isDirectory: false)
                    try FileIO.installPreparedFile(from: preparedURL, to: destination)
                    return destination
                }) {
                    return destination
                }
            }
        }
        throw CocoaError(.fileNoSuchFile)
    }

    func rebaseProjectURL(from oldURL: URL, to newURL: URL) {
        guard projectURL?.standardizedFileURL == oldURL.standardizedFileURL else { return }
        let oldPrefix = oldURL.standardizedFileURL.path + "/"
        let newRoot = newURL.standardizedFileURL
        for asset in mediaAssets {
            let path = asset.url.standardizedFileURL.path
            guard path.hasPrefix(oldPrefix) else { continue }
            asset.url = newRoot.appendingPathComponent(String(path.dropFirst(oldPrefix.count)))
        }
        projectURL = newRoot
        refreshMissingMediaCache()
    }

    func importMediaAsset(_ asset: MediaAsset, skipAppend: Bool = false) {
        if !skipAppend, !mediaAssets.contains(where: { $0.id == asset.id }) {
            mediaAssets.append(asset)
        }
        updateManifestMetadata(for: [asset])
        Log.project.notice(
            "media imported asset=\(asset.id.prefix(8)) type=\(asset.type.rawValue)",
            telemetry: "Media asset imported",
            data: [
                "assetId": Telemetry.shortId(asset.id),
                "type": asset.type.rawValue,
                "skipAppend": skipAppend,
                "media": mediaAssets.count,
                "manifestEntries": mediaManifest.entries.count
            ]
        )
    }

    /// Resolve a drag pasteboard payload (one `palmier-asset://<id>` per line).
    func assetsFromDragPayload(_ payload: String) -> [MediaAsset] {
        payload.split(separator: "\n").compactMap { line in
            guard let id = MediaTab.assetId(fromDragString: String(line)) else { return nil }
            return mediaAssets.first { $0.id == id }
        }
    }

    func timelineIdsFromDragPayload(_ payload: String) -> [String] {
        payload.split(separator: "\n").compactMap { line in
            guard let id = MediaTab.timelineId(fromDragString: String(line)) else { return nil }
            return timeline(for: id)?.id
        }
    }

    /// Source-second ranges carried by search-moment drags, keyed by asset id.
    func segmentsFromDragPayload(_ payload: String) -> [String: ClosedRange<Double>] {
        var segments: [String: ClosedRange<Double>] = [:]
        for line in payload.split(separator: "\n") {
            guard let id = MediaTab.assetId(fromDragString: String(line)),
                  let segment = MediaTab.assetSegment(fromDragString: String(line)) else { continue }
            segments[id] = segment
        }
        return segments
    }

    func dismissMediaPanelToast() {
        mediaPanelToast = nil
    }

    @discardableResult
    func addMediaAsset(from url: URL, folderId: String? = nil, finalize: Bool = true) -> MediaAsset? {
        guard let type = ClipType(fileExtension: url.pathExtension.lowercased()) else {
            mediaPanelToast = MediaPanelToast(message: L10n.string("Can't import \"\(url.lastPathComponent)\" — unsupported file type."))
            return nil
        }
        if type == .lottie, !LottieVideoGenerator.isLottie(at: url) {
            mediaPanelToast = MediaPanelToast(message: L10n.string("Can't import \"\(url.lastPathComponent)\" — not a Lottie animation."))
            return nil
        }
        return addMediaAsset(from: url, type: type, folderId: folderId, finalize: finalize)
    }

    @discardableResult
    func addMediaAsset(from url: URL, type: ClipType, folderId: String? = nil, finalize: Bool = true) -> MediaAsset {
        let name = url.deletingPathExtension().lastPathComponent
        let asset = MediaAsset(url: url, type: type, name: name)
        asset.folderId = folderId
        importMediaAsset(asset)
        if finalize {
            Task { await finalizeImportedAsset(asset) }
        }
        return asset
    }

    struct MediaImportSummary: Sendable {
        var assetCount: Int
        var folderCount: Int
        var assets: [MediaAsset] = []
    }

    /// Import files and folders from the open panel or a Finder drop as one undo step
    @discardableResult
    func importFinderItems(
        _ urls: [URL],
        into folderId: String?,
        finalize: Bool = true,
        applying mutation: (@MainActor (@MainActor () -> MediaImportSummary) async throws -> MediaImportSummary)? = nil
    ) async throws -> MediaImportSummary {
        let previous = mediaImportTail
        mediaImportSequence &+= 1
        let sequence = mediaImportSequence
        let task = Task { @MainActor in
            _ = try? await previous?.value
            return try await performFinderImport(urls, into: folderId, finalize: finalize, applying: mutation)
        }
        mediaImportTail = task

        defer {
            if mediaImportSequence == sequence { mediaImportTail = nil }
        }
        return try await task.value
    }

    @discardableResult
    private func performFinderImport(
        _ urls: [URL],
        into folderId: String?,
        finalize: Bool,
        applying mutation: (@MainActor (@MainActor () -> MediaImportSummary) async throws -> MediaImportSummary)?
    ) async throws -> MediaImportSummary {
        let before = mediaLibraryUndoSnapshot()
        let roots = urls.map { MediaImportScanner.Root(url: $0, parentFolderId: folderId) }

        let plan = await Task.detached(priority: .userInitiated) {
            MediaImportScanner.scan(roots: roots)
        }.value
        if let mutation {
            return try await mutation { self.applyMediaImportPlan(plan, restoringFrom: before, finalize: finalize) }
        }
        return applyMediaImportPlan(plan, restoringFrom: before, finalize: finalize)
    }

    @discardableResult
    private func applyMediaImportPlan(
        _ plan: MediaImportPlan,
        restoringFrom before: MediaLibraryUndoSnapshot,
        finalize: Bool = true
    ) -> MediaImportSummary {
        let importedAssets = undo.withoutRegistration {
            var folderIds = Array(repeating: "", count: plan.folders.count)
            for (index, folder) in plan.folders.enumerated() {
                let parentId = parentFolderId(for: folder.parent, plannedFolderIds: folderIds)
                folderIds[index] = createFolder(name: folder.name, in: parentId)
            }

            let importedAssets = plan.files.map { file in
                let folderId = parentFolderId(for: file.parent, plannedFolderIds: folderIds)
                let asset = MediaAsset(url: file.url, type: file.type, name: file.name)
                asset.folderId = folderId
                return asset
            }
            if !importedAssets.isEmpty {
                mediaAssets.append(contentsOf: importedAssets)
                mediaManifest.entries.append(contentsOf: importedAssets.map { $0.toManifestEntry(projectURL: projectURL) })
                Log.project.notice(
                    "media import applied assets=\(importedAssets.count) folders=\(plan.folders.count)",
                    telemetry: "Media import applied",
                    data: [
                        "assets": importedAssets.count,
                        "folders": plan.folders.count,
                        "media": mediaAssets.count,
                        "manifestEntries": mediaManifest.entries.count
                    ]
                )
            }
            return importedAssets
        }

        if let name = plan.rejectedUnsupportedNames.last {
            mediaPanelToast = MediaPanelToast(message: L10n.string("Can't import \"\(name)\" — unsupported file type."))
        } else if let name = plan.rejectedLottieNames.last {
            mediaPanelToast = MediaPanelToast(message: L10n.string("Can't import \"\(name)\" — not a Lottie animation."))
        }

        let summary = MediaImportSummary(
            assetCount: mediaAssets.count - before.mediaAssets.count,
            folderCount: mediaManifest.folders.count - before.mediaManifest.folders.count,
            assets: importedAssets
        )
        guard summary.assetCount != 0 || summary.folderCount != 0 else { return summary }
        undo.register("Import Media", withTarget: self) { vm in
            vm.restoreMediaLibraryUndoSnapshot(before, actionName: "Import Media")
        }
        if finalize {
            for asset in importedAssets {
                Task { await finalizeImportedAsset(asset, batchManifestUpdate: true) }
            }
        }
        return summary
    }

    private func parentFolderId(for parent: MediaImportPlan.Parent, plannedFolderIds: [String]) -> String? {
        switch parent {
        case .existingFolderId(let id):
            id
        case .plannedFolder(let index):
            plannedFolderIds[index]
        }
    }

    func dropPlaceholderAssets(for urls: [URL]) -> [MediaAsset] {
        urls.compactMap { url in
            // hasDirectoryPath avoids disk access on the drag-hover path.
            guard !url.hasDirectoryPath,
                  let type = ClipType(fileExtension: url.pathExtension.lowercased()) else { return nil }
            let asset = MediaAsset(
                url: url, type: type,
                name: url.deletingPathExtension().lastPathComponent,
                duration: Defaults.imageDurationSeconds
            )
            asset.hasAudio = type == .video
            return asset
        }
    }

    func importFinderItemsToTimeline(
        _ urls: [URL],
        cursor: TrackDropTarget,
        atFrame: Int,
        ripple: Bool
    ) async {
        var before: MediaLibraryUndoSnapshot?
        let summary = try? await importFinderItems(urls, into: mediaPanelCurrentFolderId, finalize: false) { apply in
            before = self.mediaLibraryUndoSnapshot()
            return self.undo.withoutRegistration { apply() }
        }
        guard let summary, let before,
              summary.assetCount != 0 || summary.folderCount != 0 else { return }

        var placeable: [MediaAsset] = []
        for asset in summary.assets {
            if await finalizeImportedAsset(asset, batchManifestUpdate: true) {
                placeable.append(asset)
            }
        }
        // Revalidate after the awaits: bail if the project changed while metadata loaded.
        guard summary.assets.allSatisfy({ mediaAssetsById[$0.id] === $0 }) else { return }

        let operation: @MainActor () -> Void = { [weak self] in
            guard let self else { return }
            undo.perform("Add Media") {
                undo.register("Add Media", withTarget: self) { vm in
                    vm.restoreMediaLibraryUndoSnapshot(before, actionName: "Add Media")
                }
                if !placeable.isEmpty {
                    placeDroppedAssets(placeable, cursor: cursor, atFrame: atFrame, ripple: ripple)
                }
            }
        }
        if placeable.isEmpty {
            operation()
        } else {
            addClipsWithSettingsCheck(assets: placeable, operation: operation)
        }
    }

    @discardableResult
    func importPastedImageData(_ data: Data, fileExtension: String = "png") async -> MediaAsset? {
        let filename = "pasted-\(UUID().uuidString.prefix(8)).\(fileExtension)"
        do {
            let stagedURL = try await Task.detached(priority: .userInitiated) { try FileIO.stageData(data, pathExtension: fileExtension) }.value
            let destinationURL = try await commitStagedProjectMedia(stagedURL, filename: filename)
            return addMediaAsset(from: destinationURL)
        } catch {
            Log.project.error("importPastedImageData: write failed \(error.localizedDescription)")
            return nil
        }
    }

    func fitTextClipToContentIfNeeded(_ clip: inout Clip, canvasW: Double, canvasH: Double) -> Bool {
        guard clip.mediaType == .text else { return false }
        let natural = TextLayout.naturalSize(
            content: clip.textContent ?? " ",
            style: clip.textStyle ?? TextStyle(),
            maxWidth: CGFloat(canvasW) * 0.9,
            canvasHeight: CGFloat(canvasH)
        )
        let needW = Double(natural.width) / canvasW
        let needH = Double(natural.height) / canvasH
        let currentW = clip.transform.width
        let currentH = clip.transform.height
        if abs(needW - currentW) < 0.0001 && abs(needH - currentH) < 0.0001 { return false }
        let tl = clip.transform.topLeft
        let cy = tl.y + currentH / 2
        let alignment = (clip.textStyle ?? TextStyle()).alignment
        let cx: Double
        switch alignment {
        case .left:
            cx = tl.x + needW / 2
        case .right:
            cx = (tl.x + currentW) - needW / 2
        case .center:
            cx = tl.x + currentW / 2
        }
        clip.transform.centerX = cx
        clip.transform.centerY = cy
        clip.transform.width = needW
        clip.transform.height = needH
        return true
    }

    func clipDisplayLabel(for clip: Clip) -> String {
        if clip.mediaType == .text {
            let content = clip.textContent ?? ""
            if content.isEmpty { return "Text" }
            // Timeline label bar is single-line.
            return content
                .replacingOccurrences(of: "\n", with: " ")
                .replacingOccurrences(of: "\r", with: " ")
        }
        if let asset = mediaAssetsById[clip.mediaRef], asset.isGenerating {
            return asset.name
        }
        if clip.sourceClipType == .sequence, let nested = timeline(for: clip.mediaRef) {
            return nested.name
        }
        return mediaResolver.displayName(for: clip.mediaRef)
    }

    /// missing on disk or present-but-unloadable (no permission, ejected volume)
    func isMediaOffline(_ mediaRef: String) -> Bool {
        offlineMediaRefs.contains(mediaRef)
            || unprocessableMediaRefs.contains(mediaRef)
            || missingMediaRefs.contains(mediaRef)
    }

    /// Present-but-unpreparable (e.g. failed to encode)
    func isMediaUnprocessable(_ mediaRef: String) -> Bool {
        unprocessableMediaRefs.contains(mediaRef) && !missingMediaRefs.contains(mediaRef)
    }

    /// Recompute `missingMediaRefs` off the main thread, then publish on the main actor.
    func refreshMissingMediaCache() {
        let entries = mediaManifest.entries
        let projectPath = projectURL?.path
        missingMediaRefreshTask?.cancel()
        missingMediaRefreshTask = Task { [weak self] in
            let missing = await Task.detached(priority: .utility) {
                MediaResolver.missingAssetIds(entries: entries, projectPath: projectPath)
            }.value
            guard !Task.isCancelled else { return }
            await MainActor.run {
                guard let self else { return }
                let recovering = Set(self.mediaAssets.lazy.filter { $0.isGenerating || $0.isRecoveringGeneration }.map(\.id))
                let resolved = missing.subtracting(recovering)
                if self.missingMediaRefs != resolved {
                    self.missingMediaRefs = resolved
                }
                self.missingMediaRefreshTask = nil
            }
        }
    }

    func isClipMediaOffline(_ clip: Clip) -> Bool {
        if clip.sourceClipType == .sequence {
            return timeline(for: clip.mediaRef) == nil
        }
        return clip.mediaType != .text && isMediaOffline(clip.mediaRef)
    }

    func isClipMediaGenerating(_ clip: Clip) -> Bool {
        guard clip.mediaType != .text else { return false }
        return mediaAssetsById[clip.mediaRef]?.isGenerating ?? false
    }

    func renameMediaAsset(id: String, name: String) {
        guard let asset = mediaAssets.first(where: { $0.id == id }) else { return }
        let oldName = asset.name
        asset.name = name
        if let idx = mediaManifest.entries.firstIndex(where: { $0.id == id }) {
            mediaManifest.entries[idx].name = name
        }
        undo.register("Rename Asset", withTarget: self) { vm in
            vm.renameMediaAsset(id: id, name: oldName)
        }
    }

    func updateManifestMetadata(for assets: [MediaAsset]) {
        guard !assets.isEmpty else { return }
        var manifest = mediaManifest
        var indices: [String: Int] = [:]
        for index in manifest.entries.indices {
            indices[manifest.entries[index].id] = index
        }
        for asset in assets {
            let entry = asset.toManifestEntry(projectURL: projectURL)
            if let index = indices[asset.id] {
                manifest.entries[index] = entry
            } else {
                indices[asset.id] = manifest.entries.count
                manifest.entries.append(entry)
            }
        }
        mediaManifest = manifest
    }

    func queueManifestMetadataUpdate(for asset: MediaAsset) {
        pendingManifestMetadataUpdates[asset.id] = asset
        if pendingManifestMetadataUpdates.count >= 64 {
            flushPendingManifestMetadataUpdates()
        } else if pendingManifestMetadataFlushTask == nil {
            pendingManifestMetadataFlushTask = Task { @MainActor [weak self] in
                try? await Task.sleep(for: .milliseconds(20))
                guard !Task.isCancelled, let self else { return }
                pendingManifestMetadataFlushTask = nil
                flushPendingManifestMetadataUpdates()
            }
        }
    }

    func flushPendingManifestMetadataUpdates() {
        pendingManifestMetadataFlushTask?.cancel()
        pendingManifestMetadataFlushTask = nil
        let assets = pendingManifestMetadataUpdates.values.filter {
            mediaAssetsById[$0.id] === $0
        }
        pendingManifestMetadataUpdates.removeAll(keepingCapacity: true)
        updateManifestMetadata(for: assets)
    }

    @discardableResult
    func finalizeImportedAsset(
        _ asset: MediaAsset,
        batchManifestUpdate: Bool = false
    ) async -> Bool {
        Log.project.debug("media finalize start asset=\(asset.id.prefix(8)) type=\(asset.type.rawValue)")
        let metadataLoaded = await asset.loadMetadata(includeThumbnail: !batchManifestUpdate)
        guard metadataLoaded else {
            if FileManager.default.fileExists(atPath: asset.url.path) {
                unprocessableMediaRefs.insert(asset.id)
            } else {
                missingMediaRefs.insert(asset.id)
            }
            if asset.isGenerating || asset.isGenerated || asset.importInput != nil {
                asset.generationStatus = .failed("Could not read media file.")
            }
            recordManifestMetadata(for: asset, batching: batchManifestUpdate)
            Log.project.warning(
                "media finalize unreadable asset=\(asset.id.prefix(8)) type=\(asset.type.rawValue)",
                telemetry: "Media asset finalize unreadable",
                data: ["assetId": Telemetry.shortId(asset.id), "type": asset.type.rawValue]
            )
            refreshMissingMediaCache()
            refreshPreviewForFinalizedAsset(asset)
            return false
        }
        if asset.isGenerating {
            asset.generationStatus = .none
        }
        recordManifestMetadata(for: asset, batching: batchManifestUpdate)
        if FileManager.default.fileExists(atPath: asset.url.path) {
            missingMediaRefs.remove(asset.id)
            offlineMediaRefs.remove(asset.id)
            unprocessableMediaRefs.remove(asset.id)
        }
        refreshMissingMediaCache()
        searchIndex.schedule(asset)
        if !batchManifestUpdate {
            prepareMediaVisuals(for: asset)
        }
        refreshPreviewForFinalizedAsset(asset)
        Log.project.debug(
            "media finalize ok asset=\(asset.id.prefix(8)) type=\(asset.type.rawValue) duration=\(asset.duration)"
        )
        return true
    }

    func prepareMediaVisuals(for asset: MediaAsset) {
        switch asset.type {
        case .video:
            mediaVisualCache.generateWaveform(for: asset)
            mediaVisualCache.generateVideoThumbnails(for: asset)
        case .audio:
            mediaVisualCache.generateWaveform(for: asset)
        case .image:
            mediaVisualCache.generateImageThumbnail(for: asset)
        case .text, .lottie, .sequence:
            break
        }
    }

    private func recordManifestMetadata(for asset: MediaAsset, batching: Bool) {
        if batching {
            queueManifestMetadataUpdate(for: asset)
        } else {
            updateManifestMetadata(for: [asset])
        }
    }

    private func refreshPreviewForFinalizedAsset(_ asset: MediaAsset) {
        let usedOnTimeline = ([timeline] + timeline.reachableTimelines(resolve: timeline(for:))).contains { t in
            t.tracks.contains { $0.clips.contains { $0.mediaRef == asset.id } }
        }
        if usedOnTimeline {
            timelineRenderRevision &+= 1
            videoEngine?.rebuild()
        }
        if case .mediaAsset(let id, _, let type) = activePreviewTab,
           id == asset.id,
           type != .image {
            videoEngine?.previewAsset(asset)
            videoEngine?.seek(to: sourcePlayheadFrame, mode: .exact)
        }
    }

    struct TextClipSpec: Sendable {
        let trackIndex: Int
        let startFrame: Int
        var durationFrames: Int
        let content: String
        let style: TextStyle
        /// When nil the box is auto-fit to content and centered on the canvas.
        let transform: Transform?
        var captionGroupId: String? = nil
        /// Per-word timing (clip-relative frames) for karaoke animation; empty when unavailable.
        var words: [WordTiming]? = nil
        var animation: TextAnimation? = nil
        var fillMode: TextFillMode? = nil
    }

    /// Batch variant of `addTextClip` for agent flows.
    /// Caller owns undo + track creation.
    @discardableResult
    func placeTextClips(_ specs: [TextClipSpec], clearExistingRegions: Bool = true, refreshVisuals: Bool = true) -> [String] {
        guard !specs.isEmpty else { return [] }
        let canvasW = Double(timeline.width)
        let canvasH = Double(timeline.height)
        var createdIds = [String?](repeating: nil, count: specs.count)
        var batchTimeline = clearExistingRegions ? nil : timeline

        let orderedIndices: [Int]
        if clearExistingRegions {
            orderedIndices = Dictionary(grouping: specs.indices, by: { specs[$0].trackIndex })
                .values.flatMap { indices in
                    indices.sorted { specs[$0].startFrame < specs[$1].startFrame }
                }
        } else {
            orderedIndices = Array(specs.indices)
        }

        for i in orderedIndices {
            let spec = specs[i]
            let trackExists = batchTimeline?.tracks.indices.contains(spec.trackIndex)
                ?? timeline.tracks.indices.contains(spec.trackIndex)
            guard trackExists else { continue }
            let start = max(0, spec.startFrame)
            let duration = max(1, spec.durationFrames)
            if clearExistingRegions {
                clearRegion(trackIndex: spec.trackIndex, start: start, end: start + duration, prune: false)
            }

            let resolved: Transform
            if let t = spec.transform {
                resolved = t
            } else {
                let natural = TextLayout.naturalSize(
                    content: spec.content, style: spec.style, maxWidth: CGFloat(canvasW) * 0.9, canvasHeight: CGFloat(canvasH)
                )
                let w = Double(natural.width) / canvasW
                let h = Double(natural.height) / canvasH
                resolved = Transform(topLeft: ((1 - w) / 2, (1 - h) / 2), width: w, height: h)
            }
            var clip = Clip(
                mediaRef: "",
                mediaType: .text,
                sourceClipType: .text,
                startFrame: start,
                durationFrames: duration,
                transform: resolved
            )
            clip.textContent = spec.content
            clip.textStyle = spec.style
            clip.captionGroupId = spec.captionGroupId
            clip.wordTimings = spec.words
            clip.textAnimation = spec.animation
            clip.textFillMode = spec.fillMode == .footage ? .footage : nil
            if batchTimeline != nil {
                batchTimeline!.tracks[spec.trackIndex].clips.append(clip)
            } else {
                timeline.tracks[spec.trackIndex].clips.append(clip)
            }
            createdIds[i] = clip.id
        }

        if var updatedTimeline = batchTimeline {
            guard createdIds.contains(where: { $0 != nil }) else { return [] }
            for i in Set(specs.map(\.trackIndex)) where updatedTimeline.tracks.indices.contains(i) {
                updatedTimeline.tracks[i].clips.sort { $0.startFrame < $1.startFrame }
            }
            timeline = updatedTimeline
        } else {
            for i in Set(specs.map(\.trackIndex)) where timeline.tracks.indices.contains(i) {
                sortClips(trackIndex: i)
            }
        }
        if refreshVisuals {
            videoEngine?.refreshVisuals()
        }
        return createdIds.compactMap { $0 }
    }

    @discardableResult
    func addTextClip(content: String = "Text", style: TextStyle = TextStyle()) -> String? {
        let durationFrames = max(1, secondsToFrame(seconds: Defaults.textDurationSeconds, fps: timeline.fps))
        let canvasW = Double(timeline.width)
        let canvasH = Double(timeline.height)
        let natural = TextLayout.naturalSize(content: content, style: style, maxWidth: CGFloat(canvasW) * 0.9, canvasHeight: CGFloat(canvasH))
        let w = Double(natural.width) / canvasW
        let h = Double(natural.height) / canvasH
        let transform = Transform(topLeft: ((1 - w) / 2, (1 - h) / 2), width: w, height: h)

        var clip = Clip(
            mediaRef: "",
            mediaType: .text,
            sourceClipType: .text,
            startFrame: max(0, currentFrame),
            durationFrames: durationFrames,
            transform: transform
        )
        clip.textContent = content
        clip.textStyle = style
        let clipId = clip.id

        withTimelineSwap(actionName: "Add Text") {
            let trackIdx = insertTrack(at: 0, type: .video)
            timeline.tracks[trackIdx].clips.append(clip)
            sortClips(trackIndex: trackIdx)
        }
        selectedClipIds = [clipId]
        return clipId
    }
}
