module github.com/WebDecoy/FCaptcha/server-go

go 1.24

require (
	github.com/go-chi/chi/v5 v5.0.11
	github.com/go-chi/cors v1.2.1
)

require github.com/hashicorp/golang-lru/v2 v2.0.7

require github.com/WebDecoy/web-bot-auth v0.2.0
