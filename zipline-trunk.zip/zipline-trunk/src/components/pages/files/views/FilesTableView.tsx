import RelativeDate from '@/components/RelativeDate';
import { addMultipleToFolder, copyFile, deleteFile, downloadFile } from '@/components/file/actions';
import FolderComboboxOptions from '@/components/folders/FolderComboboxOptions';
import { Response } from '@/lib/api/response';
import { bytes } from '@/lib/bytes';
import { useFolders } from '@/lib/client/hooks/useFolders';
import { useFileNavStore } from '@/lib/client/store/fileNav';
import { NAMES, useFileTableSettingsStore } from '@/lib/client/store/fileTableSettings';
import { useSettingsStore } from '@/lib/client/store/settings';
import { type File } from '@/lib/db/models/file';
import { Tag } from '@/lib/db/models/tag';
import { buildFolderHierarchy } from '@/lib/folderHierarchy';
import {
  ActionIcon,
  Box,
  Button,
  Checkbox,
  Collapse,
  Combobox,
  Flex,
  Group,
  Input,
  InputBase,
  Paper,
  Pill,
  PillsInput,
  ScrollArea,
  Text,
  TextInput,
  Tooltip,
  useCombobox,
} from '@mantine/core';
import { useClipboard, useDebouncedValue } from '@mantine/hooks';
import {
  IconCopy,
  IconDownload,
  IconExternalLink,
  IconFile,
  IconStar,
  IconTrashFilled,
} from '@tabler/icons-react';
import { DataTable } from 'mantine-datatable';
import { parseAsInteger, useQueryState } from 'nuqs';
import { lazy, useEffect, useMemo, useReducer, useState } from 'react';
import { Link } from 'react-router-dom';
import useSWR from 'swr';
import { useShallow } from 'zustand/shallow';
import { DashboardFilesModals, DashboardFilesModalsUpdate } from '..';
import TableEditModal from '../TableEditModal';
import { bulkCopyLinks, bulkDelete, bulkFavorite } from '../bulk';
import TagPill from '../tags/TagPill';
import { useApiPagination } from '../useApiPagination';

const DashboardFileModal = lazy(() => import('@/components/file/DashboardFile/DashboardFileModal'));

type ReducerQuery = {
  state: { name: string; originalName: string; type: string; tags: string; id: string };
  action: { field: string; query: string };
};

const PER_PAGE_OPTIONS = [10, 20, 50, 70, 100];

function SearchFilter({
  setSearchField,
  searchQuery,
  setSearchQuery,
  field,
}: {
  searchQuery: {
    name: string;
    originalName: string;
    type: string;
    id: string;
  };
  setSearchField: (...args: any) => void;
  setSearchQuery: (...args: any) => void;
  field: 'name' | 'originalName' | 'type' | 'id';
}) {
  const onChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setSearchField(field);

    setSearchQuery({
      field,
      query: e.target.value,
    });
  };

  return (
    <TextInput
      label={NAMES[field as keyof typeof NAMES]}
      placeholder={`Search by ${NAMES[field as keyof typeof NAMES].toLowerCase()}`}
      value={searchQuery[field]}
      onChange={onChange}
      size='sm'
    />
  );
}

function TagsFilter({
  setSearchField,
  setSearchQuery,
  searchQuery,
}: {
  searchQuery: {
    name: string;
    originalName: string;
    type: string;
    tags: string;
  };
  setSearchField: (...args: any) => void;
  setSearchQuery: (...args: any) => void;
}) {
  const combobox = useCombobox();
  const { data: tags } = useSWR<Extract<Response['/api/user/tags'], Tag[]>>('/api/user/tags');

  const [value, setValue] = useState(() => searchQuery.tags.split(','));
  const handleValueSelect = (val: string) => {
    setValue((current) => (current.includes(val) ? current.filter((v) => v !== val) : [...current, val]));
  };

  const handleValueRemove = (val: string) => {
    setValue((current) => current.filter((v) => v !== val));
  };

  const values = value.map((tag) => <TagPill key={tag} tag={tags?.find((t) => t.id === tag) || null} />);

  const triggerSave = () => {
    setSearchField('tags');

    setSearchQuery({
      field: 'tags',
      query: value.join(','),
    });
  };

  return (
    <Combobox store={combobox} onOptionSubmit={handleValueSelect} withinPortal={false}>
      <Combobox.DropdownTarget>
        <PillsInput onBlur={() => triggerSave()} pointer onClick={() => combobox.toggleDropdown()} w={200}>
          <Pill.Group>
            {values.length > 0 ? values : <Input.Placeholder>Pick one or more tags</Input.Placeholder>}

            <Combobox.EventsTarget>
              <PillsInput.Field
                type='hidden'
                onBlur={() => combobox.closeDropdown()}
                onKeyDown={(event) => {
                  if (event.key === 'Backspace') {
                    event.preventDefault();
                    handleValueRemove(value[value.length - 1]);
                  }
                }}
              />
            </Combobox.EventsTarget>
          </Pill.Group>
        </PillsInput>
      </Combobox.DropdownTarget>

      <Combobox.Dropdown>
        <Combobox.Options>
          {tags?.map((tag) => (
            <Combobox.Option value={tag.id} key={tag.id} active={value.includes(tag.id)}>
              <Group gap='sm'>
                <Checkbox
                  checked={value.includes(tag.id)}
                  onChange={() => {}}
                  aria-hidden
                  tabIndex={-1}
                  style={{ pointerEvents: 'none' }}
                />
                <TagPill tag={tag} />
              </Group>
            </Combobox.Option>
          ))}
        </Combobox.Options>
      </Combobox.Dropdown>
    </Combobox>
  );
}

export default function FileTable({
  id,
  folderId,
  modals,
  setModals,
}: {
  id?: string;
  folderId?: string;
  modals?: Partial<DashboardFilesModals>;
  setModals?: DashboardFilesModalsUpdate;
}) {
  const clipboard = useClipboard();
  const warnDeletion = useSettingsStore((state) => state.settings.warnDeletion);

  const fields = useFileTableSettingsStore((state) => state.fields);

  const { data: folders } = useFolders();

  const folderOptions = useMemo(() => {
    if (!folders) return [];
    return buildFolderHierarchy(folders);
  }, [folders]);

  const [page, setPage] = useQueryState('page', parseAsInteger.withDefault(1));
  const [perpage, setPerpage] = useQueryState('perpage', parseAsInteger.withDefault(20));
  const [sort, setSort] = useState<
    | 'id'
    | 'createdAt'
    | 'updatedAt'
    | 'deletesAt'
    | 'name'
    | 'originalName'
    | 'size'
    | 'type'
    | 'views'
    | 'favorite'
  >('createdAt');
  const [order, setOrder] = useState<'asc' | 'desc'>('desc');

  const [searchField, setSearchField] = useState<'name' | 'originalName' | 'type' | 'tags' | 'id'>('name');
  const [searchQuery, setSearchQuery] = useReducer(
    (
      _state: { name: string; originalName: string; type: string; tags: string; id: string },
      action: { field: keyof ReducerQuery['state']; query: string },
    ) => ({
      name: action.field === 'name' ? action.query : '',
      originalName: action.field === 'originalName' ? action.query : '',
      type: action.field === 'type' ? action.query : '',
      tags: action.field === 'tags' ? action.query : '',
      id: action.field === 'id' ? action.query : '',
    }),
    { name: '', originalName: '', type: '', tags: '', id: '' },
  );
  const [debouncedQuery] = useDebouncedValue(searchQuery, 300);

  const [selectedFiles, setSelectedFiles] = useState<File[]>([]);

  const combobox = useCombobox();
  const [folderSearch, setFolderSearch] = useState('');

  const handleAddFolder = async (value: string) => {
    try {
      addMultipleToFolder(selectedFiles, value);
      setSelectedFiles([]);
    } catch {}
  };

  const searching =
    searchQuery.name.trim() !== '' ||
    searchQuery.originalName.trim() !== '' ||
    searchQuery.type.trim() !== '';

  const { data, isLoading } = useApiPagination({
    page,
    perpage,
    filter: 'all',
    sort,
    order,
    id,
    folderId,
    ...(searchQuery[searchField].trim() !== '' && {
      search: {
        field: searchField,
        query: debouncedQuery[searchField],
      },
    }),
  });

  const [current, setCurrent, setFiles] = useFileNavStore(
    useShallow((state) => [state.current, state.setCurrent, state.setFiles]),
  );
  const selectedFile = current ? (data?.page.find((file) => file.id === current) ?? null) : null;
  const ids = useMemo(() => (data?.page ?? []).map((file) => file.id), [data?.page]);

  useEffect(() => {
    setFiles(ids);
  }, [ids]);

  const FIELDS = [
    {
      accessor: 'name',
      sortable: true,
      filter: (
        <SearchFilter
          setSearchField={setSearchField}
          searchQuery={searchQuery}
          setSearchQuery={setSearchQuery}
          field='name'
        />
      ),
      filtering: searchField === 'name' && searchQuery.name.trim() !== '',
    },
    {
      accessor: 'originalName',
      sortable: true,
      filter: (
        <SearchFilter
          setSearchField={setSearchField}
          searchQuery={searchQuery}
          setSearchQuery={setSearchQuery}
          field='originalName'
        />
      ),
      filtering: searchField === 'originalName' && searchQuery.originalName.trim() !== '',
    },
    {
      accessor: 'tags',
      sortable: false,
      width: 200,
      render: (file: File) => (
        <ScrollArea w={180} onClick={(e) => e.stopPropagation()}>
          <Flex gap='sm'>
            {file.tags!.map((tag) => (
              <TagPill tag={tag} key={tag.id} />
            ))}
          </Flex>
        </ScrollArea>
      ),
      filter: (
        <TagsFilter
          setSearchField={setSearchField}
          searchQuery={searchQuery}
          setSearchQuery={setSearchQuery}
        />
      ),
      filtering: searchField === 'tags' && searchQuery.tags.trim() !== '',
    },
    {
      accessor: 'type',
      sortable: true,
      filter: (
        <SearchFilter
          setSearchField={setSearchField}
          searchQuery={searchQuery}
          setSearchQuery={setSearchQuery}
          field='type'
        />
      ),
      filtering: searchField === 'type' && searchQuery.type.trim() !== '',
    },
    { accessor: 'size', sortable: true, render: (file: File) => bytes(file.size) },
    {
      accessor: 'createdAt',
      sortable: true,
      render: (file: File) => <RelativeDate date={file.createdAt} />,
    },
    {
      accessor: 'favorite',
      sortable: true,
      title: 'Favorite?',
      render: (file: File) => (file.favorite ? <Text c='yellow'>Yes</Text> : 'No'),
    },
    {
      accessor: 'views',
      sortable: true,
      render: (file: File) => file.views,
    },
    {
      accessor: 'id',
      hidden: searchField !== 'id' || searchQuery.id.trim() === '',
      filtering: searchField === 'id' && searchQuery.id.trim() !== '',
    },
    {
      accessor: 'anonymous',
      sortable: true,
      title: 'Anonymous?',
      render: (file: File) => (file.anonymous ? <Text c='green'>Yes</Text> : 'No'),
    },
  ];

  const visibleFields = fields.filter((f) => f.visible).map((f) => f.field);
  const columns = FIELDS.filter((f) => visibleFields.includes(f.accessor as any));
  columns.sort((a, b) => {
    const aIndex = fields.findIndex((f) => f.field === a.accessor);
    const bIndex = fields.findIndex((f) => f.field === b.accessor);

    return aIndex - bIndex;
  });

  const unfavoriteAll = selectedFiles.every((file) => file.favorite);

  return (
    <>
      <DashboardFileModal
        open={!!selectedFile}
        setOpen={(open) => {
          if (!open) setCurrent(null);
        }}
        file={selectedFile}
        user={id}
        sequenced
      />

      {modals && setModals && (
        <TableEditModal opened={!!modals.table} onClose={() => setModals({ table: false })} />
      )}

      <Box>
        <Collapse expanded={selectedFiles.length > 0}>
          <Paper withBorder p='sm' my='sm'>
            <Text size='sm' c='dimmed' mb='xs'>
              Selections are saved across page changes. Currently selected <b>{selectedFiles.length}</b> file
              {selectedFiles.length > 1 ? 's' : ''}.
            </Text>

            <Group>
              <Group mr='auto'>
                <Button
                  variant='outline'
                  color='red'
                  leftSection={<IconTrashFilled size='1rem' />}
                  onClick={() =>
                    bulkDelete(
                      selectedFiles.map((x) => x.id),
                      setSelectedFiles,
                    )
                  }
                >
                  Delete files
                </Button>

                <Button
                  variant='outline'
                  color='yellow'
                  leftSection={<IconStar size='1rem' />}
                  onClick={() =>
                    bulkFavorite(
                      selectedFiles.map((x) => x.id),
                      !unfavoriteAll,
                    )
                  }
                >
                  {unfavoriteAll ? 'Unfavorite' : 'Favorite'} files
                </Button>

                <Button
                  variant='outline'
                  leftSection={<IconCopy size='1rem' />}
                  onClick={() => bulkCopyLinks(selectedFiles.map((x) => x.url!))}
                >
                  Copy file links
                </Button>

                {!id && (
                  <Combobox
                    store={combobox}
                    withinPortal={false}
                    onOptionSubmit={(value) => handleAddFolder(value)}
                  >
                    <Combobox.Target>
                      <InputBase
                        rightSection={<Combobox.Chevron />}
                        value={folderSearch}
                        onChange={(event) => {
                          combobox.openDropdown();
                          combobox.updateSelectedOptionIndex();
                          setFolderSearch(event.currentTarget.value);
                        }}
                        onClick={() => {
                          combobox.openDropdown();
                          setFolderSearch('');
                        }}
                        onFocus={() => {
                          combobox.openDropdown();
                          setFolderSearch('');
                        }}
                        onBlur={() => {
                          combobox.closeDropdown();
                          setFolderSearch('');
                        }}
                        placeholder='Add to folder...'
                        rightSectionPointerEvents='none'
                      />
                    </Combobox.Target>

                    <Combobox.Dropdown>
                      <FolderComboboxOptions folderOptions={folderOptions} searchValue={folderSearch} />
                    </Combobox.Dropdown>
                  </Combobox>
                )}
              </Group>

              <Button
                variant='outline'
                onClick={() => {
                  setSelectedFiles([]);
                }}
                justify='right'
                ml='auto'
              >
                Clear selection
              </Button>
            </Group>
          </Paper>
        </Collapse>

        {modals && setModals && modals.idSearch && (
          <Collapse expanded={modals.idSearch}>
            <Paper withBorder p='sm' mt='sm'>
              <TextInput
                placeholder='Search by ID'
                value={searchQuery.id}
                onChange={(e) => {
                  setSearchField('id');
                  setSearchQuery({
                    field: 'id',
                    query: e.target.value,
                  });
                }}
                size='sm'
              />
            </Paper>
          </Collapse>
        )}

        {/*@ts-ignore*/}
        <DataTable
          mt='xs'
          withTableBorder
          minHeight={200}
          records={data?.page ?? []}
          noRecordsText='No files'
          columns={[
            ...columns,
            {
              accessor: 'actions',
              textAlign: 'right',
              render: (file) => (
                <Group gap='sm' justify='right' wrap='nowrap'>
                  <Tooltip label='More details'>
                    <ActionIcon>
                      <IconFile size='1rem' />
                    </ActionIcon>
                  </Tooltip>

                  <Tooltip label='View file in new tab'>
                    <Link to={`/view/${file.name}`} target='_blank'>
                      <ActionIcon color='blue'>
                        <IconExternalLink size='1rem' />
                      </ActionIcon>
                    </Link>
                  </Tooltip>

                  <Tooltip label='Copy file link to clipboard'>
                    <ActionIcon
                      onClick={(e) => {
                        e.stopPropagation();
                        copyFile(file, clipboard);
                      }}
                    >
                      <IconCopy size='1rem' />
                    </ActionIcon>
                  </Tooltip>

                  <Tooltip label='Download file'>
                    <ActionIcon
                      color='gray'
                      onClick={(e) => {
                        e.stopPropagation();
                        downloadFile(file);
                      }}
                    >
                      <IconDownload size='1rem' />
                    </ActionIcon>
                  </Tooltip>

                  <Tooltip label='Delete file'>
                    <ActionIcon
                      color='red'
                      onClick={(e) => {
                        e.stopPropagation();
                        deleteFile(warnDeletion, file, () => {});
                      }}
                    >
                      <IconTrashFilled size='1rem' />
                    </ActionIcon>
                  </Tooltip>
                </Group>
              ),
            },
          ]}
          fetching={isLoading}
          totalRecords={searching ? data?.page.length : (data?.total ?? 0)}
          recordsPerPage={searching ? undefined : perpage}
          onRecordsPerPageChange={searching ? undefined : setPerpage}
          recordsPerPageOptions={searching ? undefined : PER_PAGE_OPTIONS}
          page={searching ? undefined : page}
          onPageChange={searching ? undefined : setPage}
          sortStatus={{
            columnAccessor: sort,
            direction: order,
          }}
          onSortStatusChange={(data) => {
            setSort(data.columnAccessor as any);
            setOrder(data.direction);
          }}
          onCellClick={({ record }) => setCurrent(record.id)}
          selectedRecords={selectedFiles}
          onSelectedRecordsChange={setSelectedFiles}
          paginationText={({ from, to, totalRecords }) => `${from} - ${to} / ${totalRecords} files`}
        />
      </Box>
    </>
  );
}
