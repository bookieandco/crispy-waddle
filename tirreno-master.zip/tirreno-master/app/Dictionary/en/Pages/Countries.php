<?php

/**
 * tirreno ~ open-source security framework
 * Copyright (c) Tirreno Technologies Sàrl (https://www.tirreno.com)
 *
 * Licensed under GNU Affero General Public License version 3 of the or any later version.
 * For full copyright and license information, please see the LICENSE
 * Redistributions of files must retain the above copyright notice.
 *
 * @copyright     Copyright (c) Tirreno Technologies Sàrl (https://www.tirreno.com)
 * @license       https://opensource.org/licenses/AGPL-3.0 AGPL License
 * @link          https://www.tirreno.com Tirreno(tm)
 */

declare(strict_types=1);

return [
    'countries_page_title' => 'Countries',
    'countries_breadcrumb_title' => 'Countries',
    'countries_search_placeholder' => 'Country',

    'countries_map_title' => 'Countries',
    'countries_map_title_tooltip' => 'This page outputs location-related information, as identified by IP addresses. The data is shown for a selected period of time. To open a page with detailed information on a particular country, click on a table row. The map visualizes the geolocated countries and the number of entities from each country.',
];
