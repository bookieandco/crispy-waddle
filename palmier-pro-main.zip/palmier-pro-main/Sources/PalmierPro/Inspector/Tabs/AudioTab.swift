import SwiftUI

extension InspectorView {

    @ViewBuilder
    func audioTabContent(audioClips: [Clip], hasNonTextVisualClips: Bool) -> some View {
        VStack(alignment: .leading, spacing: AppTheme.Spacing.zero) {
            levelsSection(audios: audioClips)
            EditorPanelGroup(L10n.string("Enhance"), contentSpacing: AppTheme.Spacing.smMd) {
                denoiseRow(audios: audioClips)
            }
            if !hasNonTextVisualClips {
                speedSection(clips: audioClips)
            }
        }
    }

    private func levelsSection(audios: [Clip]) -> some View {
        let single = audios.count == 1 ? audios.first : nil
        return EditorPanelGroup(
            L10n.string("Levels"),
            isExpanded: $audioLevelsExpanded,
            headerAccessory: {
                if audioLevelsExpanded {
                    keyframesToggleButton(enabled: single != nil)
                }
            }
        ) {
            if let clip = single, editor.keyframesPanelVisible {
                keyframesSplitContent(clip: clip) {
                    VStack(alignment: .leading, spacing: AppTheme.Spacing.md) {
                        volumeRow(audios: audios)
                        fadeRow(label: L10n.string("Fade In"), clips: audios, edge: .left)
                        fadeRow(label: L10n.string("Fade Out"), clips: audios, edge: .right)
                    }
                }
            } else {
                VStack(alignment: .leading, spacing: AppTheme.Spacing.smMd) {
                    volumeRow(audios: audios)
                    fadeRow(label: L10n.string("Fade In"), clips: audios, edge: .left)
                    fadeRow(label: L10n.string("Fade Out"), clips: audios, edge: .right)
                }
            }
        }
    }

    @ViewBuilder
    private func volumeRow(audios: [Clip]) -> some View {
        let single = audios.count == 1 ? audios.first : nil
        animatableRow(
            label: L10n.string("Volume"),
            clipId: single?.id,
            property: .volume,
            onReset: {
                commitPropertiesToClips(audios, actionName: "Reset Volume") { clip in
                    clip.volume = 1
                    clip.volumeTrack = nil
                }
            }
        ) {
            ScrubbableNumberField(
                value: sharedClipValue(audios) { clip in
                    clip.liveVolumeKfDb(at: editor.activeFrame) ?? VolumeScale.dbFromLinear(clip.volume)
                },
                range: VolumeScale.floorDb...VolumeScale.ceilingDb,
                format: "%.1f",
                valueSuffix: " dB",
                dragSensitivity: 0.3,
                fieldWidth: AppTheme.EditorPanel.numericFieldWidth,
                displayTextOverride: { db in db <= VolumeScale.floorDb ? "-∞ dB" : nil },
                onChanged: { db in
                    for c in audios { editor.applyVolume(clipId: c.id, valueDb: db) }
                }
            ) { db in
                commitToClips(audios, actionName: "Change Volume") { c in
                    editor.commitVolume(clipId: c.id, valueDb: db)
                }
            }
        }
    }

    @ViewBuilder
    private func denoiseRow(audios: [Clip]) -> some View {
        if !audios.isEmpty {
            let allOn = audios.allSatisfy(\.hasDenoiseEnabled)
            let baking = audios.contains { editor.denoiseInFlight.contains($0.mediaRef) }
            let failed = allOn && !baking && audios.contains {
                editor.denoiseFailed.contains($0.mediaRef)
            }
            VStack(alignment: .leading, spacing: AppTheme.Spacing.smMd) {
                propertyRow(
                    label: L10n.string("Denoise"),
                    onReset: {
                        editor.setDenoise(
                            clipIds: Set(audios.map(\.id)),
                            enabled: false,
                            actionName: "Reset Denoise"
                        )
                    }
                ) {
                    HStack(spacing: AppTheme.Spacing.sm) {
                        if allOn {
                            ScrubbableNumberField(
                                value: sharedClipValue(audios) { $0.denoiseAmount * 100 },
                                range: 0...100,
                                format: "%.0f",
                                valueSuffix: "%",
                                dragSensitivity: 0.5,
                                fieldWidth: AppTheme.EditorPanel.numericFieldWidth
                            ) { percent in
                                editor.setDenoise(
                                    clipIds: Set(audios.map(\.id)),
                                    enabled: true,
                                    amount: percent / 100,
                                    actionName: "Change Denoise Strength"
                                )
                            }
                            .help(L10n.string("Blends denoised and original audio — lower this if voices sound thin or over-compressed."))
                        }
                        Toggle(String(), isOn: Binding(
                            get: { allOn },
                            set: { enabled in
                                editor.setDenoise(
                                    clipIds: Set(audios.map(\.id)),
                                    enabled: enabled,
                                    actionName: enabled ? "Enable Denoise" : "Disable Denoise"
                                )
                            }
                        ))
                        .toggleStyle(.switch)
                        .controlSize(.mini)
                        .labelsHidden()
                        .accessibilityLabel(L10n.string("Denoise"))
                    }
                }
                .help(L10n.string("Removes background noise from this audio using an on-device model."))
                if baking {
                    HStack(spacing: AppTheme.Spacing.xs) {
                        ProgressView()
                            .controlSize(.small)
                        Text(L10n.string("Removing background noise…"))
                            .font(.system(size: AppTheme.FontSize.xs))
                            .foregroundStyle(AppTheme.Text.mutedColor)
                    }
                } else if failed {
                    Text(L10n.string("Denoise failed. Playback uses the original audio — adjust Strength to retry."))
                        .font(.system(size: AppTheme.FontSize.xs))
                        .foregroundStyle(AppTheme.Status.errorColor)
                }
            }
        }
    }


    @ViewBuilder
    private func fadeRow(label: String, clips: [Clip], edge: FadeEdge) -> some View {
        let fps = Double(max(1, editor.timeline.fps))
        let single = clips.count == 1 ? clips.first : nil
        let maxSeconds = single.map { Double($0.durationFrames) / fps } ?? 60.0
        let actionName = edge == .left ? "Change Fade In" : "Change Fade Out"
        propertyRow(
            label: label,
            onReset: {
                commitToClips(clips, actionName: "Reset \(label)") { clip in
                    editor.commitFade(clipId: clip.id, edge: edge, frames: 0)
                }
            },
            reservesKeyframeControls: true
        ) {
            ScrubbableNumberField(
                value: sharedClipValue(clips) { clip in
                    Double(clip.fadeFrames(edge)) / fps
                },
                range: 0...maxSeconds,
                format: "%.2f",
                valueSuffix: " s",
                dragSensitivity: 0.02,
                fieldWidth: AppTheme.EditorPanel.numericFieldWidth,
                onChanged: { seconds in
                    let frames = Int((seconds * fps).rounded())
                    for c in clips { editor.applyFade(clipId: c.id, edge: edge, frames: frames) }
                }
            ) { seconds in
                let frames = Int((seconds * fps).rounded())
                commitToClips(clips, actionName: actionName) { c in
                    editor.commitFade(clipId: c.id, edge: edge, frames: frames)
                }
            }
        }
        .frame(height: KeyframesMetrics.rowHeight)
    }
}
