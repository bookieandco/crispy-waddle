<p align="center">
  <a href="https://nodemon.io/"><img src="https://user-images.githubusercontent.com/13700/35731649-652807e8-080e-11e8-88fd-1b2f6d553b2d.png" alt="Nodemon Logo"></a>
</p>

# nodemon

nodemon is a tool that helps develop Node.js based applications by automatically restarting the node application when file changes in the directory are detected.

nodemon does **not** require *any* additional changes to your code or method of development. nodemon is a replacement wrapper for `node`. To use `nodemon`, replace the word `node` on the command line when executing your script.

[![NPM version](https://badge.fury.io/js/nodemon.svg)](https://npmjs.org/package/nodemon)
[![Backers on Open Collective](https://opencollective.com/nodemon/backers/badge.svg)](#backers) [![Sponsors on Open Collective](https://opencollective.com/nodemon/sponsors/badge.svg)](#sponsors)

# Installation

Either through cloning with git or by using [npm](http://npmjs.org) (the recommended way):

```bash
npm install -g nodemon # or using yarn: yarn global add nodemon
```

And nodemon will be installed globally to your system path.

You can also install nodemon as a development dependency:

```bash
npm install --save-dev nodemon # or using yarn: yarn add nodemon -D
```

With a local installation, nodemon will not be available in your system path, so you can't use it directly from the command line. Instead, the local installation of nodemon can be run by calling it from within an npm script (such as `npm start`) or using `npx nodemon`.

# Usage

nodemon wraps your application, so you can pass all the arguments you would normally pass to your app:

```bash
nodemon [your node app]
```

For CLI options, use the `-h` (or `--help`) argument:

```bash
nodemon -h
```

Using nodemon is simple, if my application accepted a host and port as the arguments, I would start it like so:

```bash
nodemon ./server.js localhost 8080
```

Any output from this script is prefixed with `[nodemon]`, otherwise all output from your application, errors included, will be echoed out as expected.

You can also pass the `inspect` flag to node through the command line as you would normally:

```bash
nodemon --inspect ./server.js 80
```

If you have a `package.json` file for your app, you can omit the main script entirely and nodemon will read the `package.json` for the `main` property and use that value as the app ([ref](https://github.com/remy/nodemon/issues/14)).

nodemon will also search for the `scripts.start` property in `package.json` (as of nodemon 1.1.x).

Also check out the [FAQ](https://github.com/remy/nodemon/blob/master/faq.md) or [issues](https://github.com/remy/nodemon/issues) for nodemon.

## Automatic re-running

nodemon was originally written to restart hanging processes such as web servers, but now supports apps that cleanly exit. If your script exits cleanly, nodemon will continue to monitor the directory (or directories) and restart the script if there are any changes.

## Manual restarting

Whilst nodemon is running, if you need to manually restart your application, instead of stopping and restarting nodemon, you can type `rs` with a carriage return, and nodemon will restart your process.

## Config files

nodemon supports local and global configuration files. These are usually named `nodemon.json` and can be located in the current working directory or in your home directory. An alternative local configuration file can be specified with the `--config <file>` option.

The specificity is as follows, so that a command line argument will always override the config file settings:

- command line arguments
- local config
- global config

A config file can take any of the command line arguments as JSON key values, for example:

```json
{
  "verbose": true,
  "ignore": ["*.test.js", "**/fixtures/**"],
  "execMap": {
    "rb": "ruby",
    "pde": "processing --sketch={{pwd}} --run"
  }
}
```

The above `nodemon.json` file might be my global config so that I have support for ruby files and processing files, and I can run `nodemon demo.pde` and nodemon will automatically know how to run the script even though there is no out-of-the-box support for processing scripts.

A further example of options can be seen in [sample-nodemon.md](https://github.com/remy/nodemon/blob/master/doc/sample-nodemon.md)

### package.json

If you want to keep all your package configurations in one place, nodemon supports using `package.json` for configuration.
Specify the config in the same format as you would for a config file but under `nodemonConfig` in the `package.json` file, for example, take the following `package.json`:

```json
{
  "name": "nodemon",
  "homepage": "http://nodemon.io",
  "...": "... other standard package.json values",
  "nodemonConfig": {
    "ignore": ["**/test/**", "**/docs/**"],
    "delay": 2500
  }
}
```

Note that if you specify a `--config` file or provide a local `nodemon.json` any `package.json` config is ignored.

*This section needs better documentation, but for now you can also see `nodemon --help config` ([also here](https://github.com/remy/nodemon/blob/master/doc/cli/config.txt))*.

## Using nodemon as a module

Please see [doc/requireable.md](doc/requireable.md)

## Using nodemon as child process

Please see [doc/events.md](doc/events.md#Using_nodemon_as_child_process)

## Running non-node scripts

nodemon can also be used to execute and monitor other programs. nodemon will read the file extension of the script being run and monitor that extension instead of `.js` if there's no `nodemon.json`:

```bash
nodemon --exec "python -v" ./app.py
```

Now nodemon will run `app.py` with python in verbose mode (note that if you're not passing args to the exec program, you don't need the quotes), and look for new or modified files with the `.py` extension.

### Default executables

Using the `nodemon.json` config file, you can define your own default executables using the `execMap` property. This is particularly useful if you're working with a language that isn't supported by default by nodemon.

To add support for nodemon to know about the `.pl` extension (for Perl), the `nodemon.json` file would add:

```json
{
  "execMap": {
    "pl": "perl"
  }
}
```

Now running the following, nodemon will know to use `perl` as the executable:

```bash
nodemon script.pl
```

It's generally recommended to use the global `nodemon.json` to add your own `execMap` options. However, if there's a common default that's missing, this can be merged into the project so that nodemon supports it by default, by changing [default.js](https://github.com/remy/nodemon/blob/master/lib/config/defaults.js) and sending a pull request.

## Monitoring multiple directories

By default nodemon monitors the current working directory. If you want to take control of that option, use the `--watch` option to add specific paths:

```bash
nodemon --watch app --watch libs app/server.js
```

Now nodemon will only restart if there are changes in the `./app` or `./libs` directory. By default nodemon will traverse sub-directories, so there's no need to explicitly include sub-directories.

Nodemon also supports unix globbing, e.g `--watch './lib/*'`. The globbing pattern must be quoted. For advanced globbing, [see `picomatch` documentation](https://github.com/micromatch/picomatch#advanced-globbing), the library that nodemon uses through `chokidar` (which in turn uses it through `anymatch`).

## Specifying extension watch list

By default, nodemon looks for files with the `.js`, `.mjs`, `.coffee`, `.litcoffee`, and `.json` extensions. If you use the `--exec` option and monitor `app.py` nodemon will monitor files with the extension of `.py`. However, you can specify your own list with the `-e` (or `--ext`) switch like so:

```bash
nodemon -e js,pug
```

Now nodemon will restart on any changes to files in the directory (or subdirectories) with the extensions `.js`, `.pug`.

## Ignoring files

By default, nodemon will only restart when a `.js` JavaScript file changes. In some cases you will want to ignore some specific files, directories or file patterns, to prevent nodemon from prematurely restarting your application.

This can be done via the command line:

```bash
nodemon --ignore lib/ --ignore tests/
```

Or specific files can be ignored:

```bash
nodemon --ignore lib/app.js
```

Patterns can also be ignored (but be sure to quote the arguments):

```bash
nodemon --ignore 'lib/*.js'
```

**Important** the ignore rules are patterns matched to the full absolute path, and this determines how many files are monitored. If using a wild card glob pattern, it needs to be used as `**` or omitted entirely. For example, `nodemon --ignore '**/test/**'` will work, whereas `--ignore '*/test/*'` will not.

Note that by default, nodemon will ignore the `.git`, `node_modules`, `bower_components`, `.nyc_output`, `coverage` and `.sass-cache` directories and *add* your ignored patterns to the list. If you want to indeed watch a directory like `node_modules`, you need to [override the underlying default ignore rules](https://github.com/remy/nodemon/blob/master/faq.md#overriding-the-underlying-default-ignore-rules).

## Application isn't restarting

In some networked environments (such as a container running nodemon reading across a mounted drive), you will need to use the `legacyWatch: true` which enables Chokidar's polling.

Via the CLI, use either `--legacy-watch` or `-L` for short:

```bash
nodemon -L
```

Though this should be a last resort as it will poll every file it can find.

## Delaying restarting

In some situations, you may want to wait until a number of files have changed. The timeout before checking for new file changes is 1 second. If you're uploading a number of files and it's taking some number of seconds, this could cause your app to restart multiple times unnecessarily.

To add an extra throttle, or delay restarting, use the `--delay` command:

```bash
nodemon --delay 10 server.js
```

For more precision, milliseconds can be specified.  Either as a float:

```bash
nodemon --delay 2.5 server.js
```

Or using the time specifier (ms):

```bash
nodemon --delay 2500ms server.js
```

The delay figure is number of seconds (or milliseconds, if specified) to delay before restarting. So nodemon will only restart your app the given number of seconds after the *last* file change.

If you are setting this value in `nodemon.json`, the value will always be interpreted in milliseconds. E.g., the following are equivalent:

```bash
nodemon --delay 2.5

{
  "delay": 2500
}
```

## Gracefully reloading your script

It is possible to have nodemon send any signal that you specify to your application.

```bash
nodemon --signal SIGHUP server.js
```

Your application can handle the signal as follows.

```js
process.on("SIGHUP", function () {
  reloadSomeConfiguration();
  process.kill(process.pid, "SIGTERM");
})
```

Please note that nodemon will send this signal to every process in the process tree.

If you are using `cluster`, then each worker (as well as the master) will receive the signal. If you wish to terminate all workers on receiving a `SIGHUP`, a common pattern is to catch the `SIGHUP` in the master, and forward `SIGTERM` to all workers, while ensuring that all workers ignore `SIGHUP`.

```js
if (cluster.isMaster) {
  process.on("SIGHUP", function () {
    for (const worker of Object.values(cluster.workers)) {
      worker.process.kill("SIGTERM");
    }
  });
} else {
  process.on("SIGHUP", function() {})
}
```

## Controlling shutdown of your script

nodemon sends a kill signal to your application when it sees a file update. If you need to clean up on shutdown inside your script you can capture the kill signal and handle it yourself.

The following example will listen once for the `SIGUSR2` signal (used by nodemon to restart), run the clean up process and then kill itself for nodemon to continue control:

```js
// important to use `on` and not `once` as nodemon can re-send the kill signal
process.on('SIGUSR2', function () {
  gracefulShutdown(function () {
    process.kill(process.pid, 'SIGTERM');
  });
});
```

Note that the `process.kill` is *only* called once your shutdown jobs are complete. Hat tip to [Benjie Gillam](http://www.benjiegillam.com/2011/08/node-js-clean-restart-and-faster-development-with-nodemon/) for writing this technique up.

## Triggering events when nodemon state changes

If you want growl like notifications when nodemon restarts or to trigger an action when an event happens, then you can either `require` nodemon or add event actions to your `nodemon.json` file.

For example, to trigger a notification on a Mac when nodemon restarts, `nodemon.json` looks like this:

```json
{
  "events": {
    "restart": "osascript -e 'display notification \"app restarted\" with title \"nodemon\"'"
  }
}
```

A full list of available events is listed on the [event states wiki](https://github.com/remy/nodemon/wiki/Events#states). Note that you can bind to both states and messages.

## Pipe output to somewhere else

```js
nodemon({
  script: ...,
  stdout: false // important: this tells nodemon not to output to console
}).on('readable', function() { // the `readable` event indicates that data is ready to pick up
  this.stdout.pipe(fs.createWriteStream('output.txt'));
  this.stderr.pipe(fs.createWriteStream('err.txt'));
});
```

## Using nodemon in your gulp workflow

Check out the [gulp-nodemon](https://github.com/JacksonGariety/gulp-nodemon) plugin to integrate nodemon with the rest of your project's gulp workflow.

## Using nodemon in your Grunt workflow

Check out the [grunt-nodemon](https://github.com/ChrisWren/grunt-nodemon) plugin to integrate nodemon with the rest of your project's grunt workflow.

## Pronunciation

> nodemon, is it pronounced: node-mon, no-demon or node-e-mon (like pokémon)?

Well...I've been asked this many times before. I like that I've been asked this before. There's been bets as to which one it actually is.

The answer is simple, but possibly frustrating. I'm not saying (how I pronounce it). It's up to you to call it as you like. All answers are correct :)

## Design principles

- Fewer flags is better
- Works across all platforms
- Fewer features
- Let individuals build on top of nodemon
- Offer all CLI functionality as an API
- Contributions must have and pass tests

Nodemon is not perfect, and CLI arguments have sprawled beyond where I'm completely happy, but perhaps they can be reduced a little one day.

## FAQ

See the [FAQ](https://github.com/remy/nodemon/blob/master/faq.md) and please add your own questions if you think they would help others.

## Backers

Thank you to all [our backers](https://opencollective.com/nodemon#backer)! 🙏

[![nodemon backers](https://opencollective.com/nodemon/backers.svg?width=890)](https://opencollective.com/nodemon#backers)

## Sponsors

Support this project by becoming a sponsor. Your logo will show up here with a link to your website. [Sponsor this project today ❤️](https://opencollective.com/nodemon#sponsor)

<div style="overflow: hidden; margin-bottom: 80px;"><!--oc--><a title='Netpositive' data-id='162674' data-tier='1' href='https://najlepsibukmacherzy.pl/ranking-legalnych-bukmacherow/'><img alt='Netpositive' src='https://opencollective-production.s3.us-west-1.amazonaws.com/52acecf0-608a-11eb-b17f-5bca7c67fe7b.png' style='object-fit: contain; float: left; margin:12px' height='120' width='120'></a>
<a title='Goread.io' data-id='320564' data-tier='1' href='https://goread.io/buy-instagram-followers'><img alt='Goread.io' src='https://opencollective-production.s3.us-west-1.amazonaws.com/7d1302a0-0f33-11ed-a094-3dca78aec7cd.png' style='object-fit: contain; float: left; margin:12px' height='120' width='120'></a>
<a title='Best Australian online casinos. Reviewed by Correct Casinos.' data-id='322445' data-tier='1' href='https://www.correctcasinos.com/australian-online-casinos/'><img alt='Best Australian online casinos. Reviewed by Correct Casinos.' src='https://opencollective-production.s3.us-west-1.amazonaws.com/fef95200-1551-11ed-ba3f-410c614877c8.png' style='object-fit: contain; float: left; margin:12px' height='120' width='120'></a>
<a title='Buy Instagram Likes' data-id='411448' data-tier='1' href='https://poprey.com/'><img alt='Buy Instagram Likes' src='https://opencollective-production.s3.us-west-1.amazonaws.com/fe650970-c21c-11ec-a499-b55e54a794b4.png' style='object-fit: contain; float: left; margin:12px' height='120' width='120'></a>
<a title='OnlineCasinosSpelen' data-id='423738' data-tier='1' href='https://onlinecasinosspelen.com'><img alt='OnlineCasinosSpelen' src='https://opencollective-production.s3.us-west-1.amazonaws.com/account-avatar/47e87426-6a55-4f69-9fb5-4e5032dc35a8/5d10dd22-320e-47d4-84e6-d144874f1f5f.png' style='object-fit: contain; float: left; margin:12px' height='120' width='120'></a>
<a title='Beoordelen van nieuwe online casino&apos;s 2023' data-id='424449' data-tier='1' href='https://Nieuwe-Casinos.net'><img alt='Beoordelen van nieuwe online casino&apos;s 2023' src='https://opencollective-production.s3.us-west-1.amazonaws.com/account-avatar/b803f279-c2a2-42da-8f05-d23e73cb8b26/aba64d6d-97e8-468c-b598-db08e0a134c5.png' style='object-fit: contain; float: left; margin:12px' height='120' width='120'></a>
<a title='Buy real Instagram followers from Twicsy starting at only $2.97. Twicsy has been voted the best site to buy followers from the likes of US Magazine.' data-id='453050' data-tier='1' href='https://twicsy.com/buy-instagram-followers'><img alt='Buy real Instagram followers from Twicsy starting at only $2.97. Twicsy has been voted the best site to buy followers from the likes of US Magazine.' src='https://opencollective-production.s3.us-west-1.amazonaws.com/account-avatar/f07b6f83-d0ed-43c6-91ae-ec8fa90512cd/twicsy-followers.png' style='object-fit: contain; float: left; margin:12px' height='120' width='120'></a>
<a title='SocialWick offers the best Instagram Followers in the market. If you are looking to boost your organic growth, buy Instagram followers from SocialWick' data-id='462750' data-tier='1' href='https://www.socialwick.com/instagram/followers'><img alt='SocialWick offers the best Instagram Followers in the market. If you are looking to boost your organic growth, buy Instagram followers from SocialWick' src='https://opencollective-production.s3.us-west-1.amazonaws.com/account-avatar/4a977a23-f63a-489a-891b-c0eb8cab1cb4/icon.png' style='object-fit: contain; float: left; margin:12px' height='120' width='120'></a>
<a title='Buy Telegram Members' data-id='501897' data-tier='1' href='https://buycheapestfollowers.com/buy-telegram-channel-members'><img alt='Buy Telegram Members' src='https://github-production-user-asset-6210df.s3.amazonaws.com/13700/286696172-747dca05-a1e8-4d93-a9e9-95054d1566df.png' style='object-fit: contain; float: left; margin:12px' height='120' width='120'></a>
<a title='We review the entire iGaming industry from A to Z' data-id='504258' data-tier='1' href='https://casinolandia.com'><img alt='We review the entire iGaming industry from A to Z' src='https://opencollective-production.s3.us-west-1.amazonaws.com/account-avatar/5f858add-77f1-47a2-b577-39eecb299c8c/Logo264.jpg' style='object-fit: contain; float: left; margin:12px' height='120' width='120'></a>
<a title='CryptoCasinos.online' data-id='525119' data-tier='1' href='https://cryptocasinos.online/'><img alt='CryptoCasinos.online' src='https://opencollective-production.s3.us-west-1.amazonaws.com/account-avatar/97712948-3b1b-4026-a109-257d879baa23/CryptoCasinos.Online-FBcover18.jpg' style='object-fit: contain; float: left; margin:12px' height='120' width='120'></a>
<a title='No deposit casino promo Codes 2024 - The best online Casinos websites. No deposit bonus codes, Free Spins and Promo Codes. Stake, Roobet, Jackpotcity and more.' data-id='540890' data-tier='1' href='https://www.ownedcore.com/casino'><img alt='No deposit casino promo Codes 2024 - The best online Casinos websites. No deposit bonus codes, Free Spins and Promo Codes. Stake, Roobet, Jackpotcity and more.' src='https://opencollective-production.s3.us-west-1.amazonaws.com/account-avatar/8bd4b78c-95e2-4c41-b4f4-d7fd6c0e12cd/logo4-e6140c27.webp' style='object-fit: contain; float: left; margin:12px' height='120' width='120'></a>
<a title='Boost your social media presence effortlessly with top-quality Instagram and TikTok followers and likes.' data-id='579911' data-tier='1' href='https://leofame.com/buy-instagram-followers'><img alt='Boost your social media presence effortlessly with top-quality Instagram and TikTok followers and likes.' src='https://opencollective-production.s3.us-west-1.amazonaws.com/account-avatar/186c0e19-b195-4228-901a-ab1b70d63ee5/WhatsApp%20Image%202024-06-21%20at%203.50.43%20AM.jpg' style='object-fit: contain; float: left; margin:12px' height='120' width='120'></a>
<a title='Social Media Management and all kinds of followers' data-id='587050' data-tier='1' href='https://www.socialfollowers.uk/buy-tiktok-followers/'><img alt='Social Media Management and all kinds of followers' src='https://opencollective-production.s3.us-west-1.amazonaws.com/account-avatar/8941f043-5d00-4e33-a1fd-f2d27ca54963/Social%20Followers%20Uk%20logo%20black.png' style='object-fit: contain; float: left; margin:12px' height='120' width='120'></a>
<a title='At Buzzoid, you can buy Instagram followers quickly, safely, and easily with just a few clicks. Rated world&apos;s #1 IG service since 2012.' data-id='602382' data-tier='1' href='https://buzzoid.com/buy-instagram-followers/'><img alt='At Buzzoid, you can buy Instagram followers quickly, safely, and easily with just a few clicks. Rated world&apos;s #1 IG service since 2012.' src='https://opencollective-production.s3.us-west-1.amazonaws.com/account-avatar/f77464f7-0457-451a-b29d-8e3b161ce83f/285fbc9f-6461-4393-8942-da62d1bed968.png' style='object-fit: contain; float: left; margin:12px' height='120' width='120'></a>
<a title='Zamsino.com' data-id='608094' data-tier='1' href='https://zamsino.com/'><img alt='Zamsino.com' src='https://opencollective-production.s3.us-west-1.amazonaws.com/account-avatar/e3e99af5-a024-4d85-8594-8fd22e506bc9/Zamsino.com%20Logo.png' style='object-fit: contain; float: left; margin:12px' height='120' width='120'></a>
<a title='Buzzvoice is your one-stop shop for all your social media marketing needs. With Buzzvoice, you can buy followers, comments, likes, video views and more!' data-id='646075' data-tier='1' href='https://buzzvoice.com/'><img alt='Buzzvoice is your one-stop shop for all your social media marketing needs. With Buzzvoice, you can buy followers, comments, likes, video views and more!' src='https://opencollective-production.s3.us-west-1.amazonaws.com/acd68da0-e71e-11ec-a84e-fd82f80383c1.jpg' style='object-fit: contain; float: left; margin:12px' height='120' width='120'></a>
<a title='' data-id='648524' data-tier='1' href='https://www.c19.cl/'><img alt='' src='https://opencollective-production.s3.us-west-1.amazonaws.com/account-avatar/01b96d4c-4852-4499-8c70-e3ec57d0c58c/2024-05-09_17-27%20(1).png' style='object-fit: contain; float: left; margin:12px' height='120' width='120'></a>
<a title='SocialBoosting: Buy Instagram &amp; TikTok Followers, Likes, Views' data-id='653711' data-tier='1' href='https://www.socialboosting.com/'><img alt='SocialBoosting: Buy Instagram &amp; TikTok Followers, Likes, Views' src='https://opencollective-production.s3.us-west-1.amazonaws.com/account-avatar/80a54dfd-8952-4851-8cab-dcfa4a8a0a87/favicon.gif' style='object-fit: contain; float: left; margin:12px' height='120' width='120'></a>
<a title='Casino Online Chile' data-id='678929' data-tier='1' href='https://www.acee.cl/'><img alt='Casino Online Chile' src='https://opencollective-production.s3.us-west-1.amazonaws.com/account-avatar/292c66d6-0c5c-40e8-96f0-900dcdeaaf47/acee-casino-chile.png' style='object-fit: contain; float: left; margin:12px' height='120' width='120'></a>
<a title='casino online chile' data-id='709152' data-tier='1' href='https://chilecasinoonline.cl/'><img alt='casino online chile' src='https://opencollective-production.s3.us-west-1.amazonaws.com/account-avatar/7f3780b2-b7a7-47aa-9837-c01099585495/casino-online-chile-logo.png' style='object-fit: contain; float: left; margin:12px' height='120' width='120'></a>
<a title='Bei Releaf erhalten Sie schnell und diskret Ihr Cannabis Rezept online. Unsere Ärzte prüfen Ihre Angaben und stellen bei Eignung das Rezept aus. Anschließend können Sie legal und sicher medizinisches Cannabis über unsere Partnerapotheken kaufen.' data-id='727109' data-tier='1' href='https://releaf.com/de'><img alt='Bei Releaf erhalten Sie schnell und diskret Ihr Cannabis Rezept online. Unsere Ärzte prüfen Ihre Angaben und stellen bei Eignung das Rezept aus. Anschließend können Sie legal und sicher medizinisches Cannabis über unsere Partnerapotheken kaufen.' src='https://opencollective-production.s3.us-west-1.amazonaws.com/account-avatar/b686d646-5029-4b4c-8cab-9645ab2679de/9da596d1-f48a-41ec-947d-a64dd8e7529c.png' style='object-fit: contain; float: left; margin:12px' height='120' width='120'></a>
<a title='kasyno online polska' data-id='727891' data-tier='1' href='https://kasyno.it.com/'><img alt='kasyno online polska' src='https://opencollective-production.s3.us-west-1.amazonaws.com/account-avatar/060d6f02-ab32-410b-9428-ac604b570892/Kasyno%20Polska.png' style='object-fit: contain; float: left; margin:12px' height='120' width='120'></a>
<a title='Нова українська букмекерська контора' data-id='742475' data-tier='1' href='https://betking.com.ua/sports-book/'><img alt='Нова українська букмекерська контора' src='https://opencollective-production.s3.us-west-1.amazonaws.com/account-avatar/c56d2fe2-f9fb-4d63-947c-77575f4b15c6/stavki.jpg' style='object-fit: contain; float: left; margin:12px' height='120' width='120'></a>
<a title='We specialize in the online gambling industry, helping players access reliable and verified information about the best online casinos and pokies in Australia. Our team tests casinos and games, collects user reviews from Trustpilot, and organizes them in o' data-id='753333' data-tier='1' href='https://au.trustpilot.com/review/bestpayidpokies.net'><img alt='We specialize in the online gambling industry, helping players access reliable and verified information about the best online casinos and pokies in Australia. Our team tests casinos and games, collects user reviews from Trustpilot, and organizes them in o' src='https://opencollective-production.s3.us-west-1.amazonaws.com/account-avatar/985a0ae7-54c3-4680-8816-bc8d656f7562/payidpokies.png' style='object-fit: contain; float: left; margin:12px' height='120' width='120'></a>
<a title='Wolf Winner Casino' data-id='754359' data-tier='1' href='https://www.wolfwinner.fun/en'><img alt='Wolf Winner Casino' src='https://opencollective-production.s3.us-west-1.amazonaws.com/account-avatar/556e09fb-d232-4c99-9644-9d28e1cfe27b/wolf-winner-casino-logo.png' style='object-fit: contain; float: left; margin:12px' height='120' width='120'></a>
<a title='AUCrazyVegas' data-id='756605' data-tier='1' href='https://au.crazyvegas.com/'><img alt='AUCrazyVegas' src='https://opencollective-production.s3.us-west-1.amazonaws.com/account-avatar/be59e9fa-a83d-4244-9e74-f54b7f454e14/au.png' style='object-fit: contain; float: left; margin:12px' height='120' width='120'></a>
<a title='BetPokies.co.nz is your New Zealand guide in the world of online gambling. Our site was created by gamblers for gamblers.' data-id='760968' data-tier='1' href='https://nz.trustpilot.com/review/betpokies.co.nz'><img alt='BetPokies.co.nz is your New Zealand guide in the world of online gambling. Our site was created by gamblers for gamblers.' src='https://opencollective-production.s3.us-west-1.amazonaws.com/117c78d0-973e-11ed-b663-5b4207ae3c06.png' style='object-fit: contain; float: left; margin:12px' height='120' width='120'></a>
<a title='We test dozens of casinos every month and select the coolest ones for Australian players. ' data-id='767300' data-tier='1' href='https://au.trustpilot.com/review/payid-casino.net'><img alt='We test dozens of casinos every month and select the coolest ones for Australian players. ' src='https://opencollective-production.s3.us-west-1.amazonaws.com/account-avatar/ecd8a5f4-fd86-4903-a512-cbfaff35e7ef/payidpokiessites.png' style='object-fit: contain; float: left; margin:12px' height='120' width='120'></a>
<a title='' data-id='783792' data-tier='1' href='https://time.now/'><img alt='' src='https://opencollective-production.s3.us-west-1.amazonaws.com/account-avatar/4cca6170-acb2-4b1a-b85b-7715416237cf/time-now-logo3.png' style='object-fit: contain; float: left; margin:12px' height='120' width='120'></a>
<a title='Best online sports betting and casino company.' data-id='784673' data-tier='1' href='https://global.fun88.com/'><img alt='Best online sports betting and casino company.' src='https://opencollective-production.s3.us-west-1.amazonaws.com/account-avatar/1688ebca-4984-4b9b-a24d-8fdd1233892f/fun88-logo.png' style='object-fit: contain; float: left; margin:12px' height='120' width='120'></a>
<a title='บริษัทรับแทงบอลออนไลน์ที่ดีที่สุดในประเทศไทย' data-id='787477' data-tier='1' href='https://www.fun88thclub.com/th/'><img alt='บริษัทรับแทงบอลออนไลน์ที่ดีที่สุดในประเทศไทย' src='https://opencollective-production.s3.us-west-1.amazonaws.com/account-avatar/bbf7174c-fc01-4ce6-86b5-f621e350969d/fun88-logo.png' style='object-fit: contain; float: left; margin:12px' height='120' width='120'></a>
<a title='Nhà cái cá cược thể thao trực tuyến tốt nhất tại Việt Nam' data-id='787478' data-tier='1' href='https://www.fun88vnw.com/vn/'><img alt='Nhà cái cá cược thể thao trực tuyến tốt nhất tại Việt Nam' src='https://opencollective-production.s3.us-west-1.amazonaws.com/account-avatar/ed704e1d-3894-48bb-83e3-6094b2c68a5c/fun88-logo.png' style='object-fit: contain; float: left; margin:12px' height='120' width='120'></a>
<a title='ThePokies Net' data-id='787930' data-tier='1' href='https://au.trustpilot.com/review/thepokies-au.com'><img alt='ThePokies Net' src='https://opencollective-production.s3.us-west-1.amazonaws.com/account-avatar/7981d14b-e79a-45a6-91b5-6040b0077e28/pokiesnet-casino.jpg' style='object-fit: contain; float: left; margin:12px' height='120' width='120'></a>
<a title='iDEAL Casinos' data-id='791586' data-tier='1' href='https://nl.trustpilot.com/review/idealcasinos.co.com'><img alt='iDEAL Casinos' src='https://opencollective-production.s3.us-west-1.amazonaws.com/account-avatar/974ae057-b821-4404-b0b7-c85c075996a4/Screen-Shot-2023-03-17-at-10.17.00.png' style='object-fit: contain; float: left; margin:12px' height='120' width='120'></a>
<a title='POLi Pay Casinos' data-id='796704' data-tier='1' href='https://nz.trustpilot.com/review/surfpokies.com'><img alt='POLi Pay Casinos' src='https://opencollective-production.s3.us-west-1.amazonaws.com/account-avatar/cd762491-d631-4fa3-a49e-bd373e6a338b/polii.png' style='object-fit: contain; float: left; margin:12px' height='120' width='120'></a>
<a title='TopKasynoOnline PL' data-id='797659' data-tier='1' href='https://pl.topkasynoonline.com/'><img alt='TopKasynoOnline PL' src='https://opencollective-production.s3.us-west-1.amazonaws.com/account-avatar/6cdee969-d731-44d6-b8ff-fc4f6d4dab9c/TKOlogo.png' style='object-fit: contain; float: left; margin:12px' height='120' width='120'></a>
<a title='SocialDawn is a digital marketing brand focused on social media growth and performance campaigns. We help creators and businesses improve visibility and engagement through data-driven strategies and campaign management.' data-id='800963' data-tier='1' href='https://www.socialdawn.com/'><img alt='SocialDawn is a digital marketing brand focused on social media growth and performance campaigns. We help creators and businesses improve visibility and engagement through data-driven strategies and campaign management.' src='https://opencollective-production.s3.us-west-1.amazonaws.com/account-avatar/96eab328-005c-466e-8857-4b5902021396/logosocialdawn.png' style='object-fit: contain; float: left; margin:12px' height='120' width='120'></a>
<a title='Create the most suitable order for your target audience from Buy.Fans, the world&apos;s most reliable and most preferred social media service platform for 12 years, and strengthen your page!' data-id='806895' data-tier='1' href='https://buy.fans/'><img alt='Create the most suitable order for your target audience from Buy.Fans, the world&apos;s most reliable and most preferred social media service platform for 12 years, and strengthen your page!' src='https://opencollective-production.s3.us-west-1.amazonaws.com/account-avatar/abf8298b-10f6-4fa5-875f-b1d32645e2bb/buyfans.png' style='object-fit: contain; float: left; margin:12px' height='120' width='120'></a>
<a title='Buy YouTube Views' data-id='808438' data-tier='1' href='https://www.reddit.com/r/YouTubeCamp/comments/1p318xp/whats_the_best_site_to_buy_youtube_views_as_a/'><img alt='Buy YouTube Views' src='https://opencollective-production.s3.us-west-1.amazonaws.com/account-avatar/bd991172-54eb-4a44-a6c4-d88578833242/OC%20pfp%204.webp' style='object-fit: contain; float: left; margin:12px' height='120' width='120'></a>
<a title='Calculators' data-id='810718' data-tier='1' href='https://calculator.now/'><img alt='Calculators' src='https://opencollective-production.s3.us-west-1.amazonaws.com/account-avatar/e924bc22-24fb-47a3-8af3-e9b51cd3338e/calculator-icon.png' style='object-fit: contain; float: left; margin:12px' height='120' width='120'></a>
<a title='Exact Time Now on Time.so' data-id='810774' data-tier='1' href='https://time.so/'><img alt='Exact Time Now on Time.so' src='https://opencollective-production.s3.us-west-1.amazonaws.com/account-avatar/0b626987-0f88-4cd6-932a-7d0175f5331e/favicon-256x256.png' style='object-fit: contain; float: left; margin:12px' height='120' width='120'></a>
<a title='We are the #1 source for social media advertising on all of the major social networks: Instagram, Youtube, TikTok, Facebook, Twitter X, and Spotify' data-id='812176' data-tier='1' href='https://mysocialfollowing.com/'><img alt='We are the #1 source for social media advertising on all of the major social networks: Instagram, Youtube, TikTok, Facebook, Twitter X, and Spotify' src='https://opencollective-production.s3.us-west-1.amazonaws.com/account-avatar/2fc5fcda-c764-41df-906f-9c4fd24a5201/logo.png' style='object-fit: contain; float: left; margin:12px' height='120' width='120'></a>
<a title='Paysafecard Casino' data-id='812791' data-tier='1' href='https://de.trustpilot.com/review/onlinecasinospaysafecard.com'><img alt='Paysafecard Casino' src='https://opencollective-production.s3.us-west-1.amazonaws.com/account-avatar/641d34bb-f65f-4df5-a6ec-ad5ab35df1e0/paysafe.png' style='object-fit: contain; float: left; margin:12px' height='120' width='120'></a>
<a title='Buy TikTok Followers' data-id='819543' data-tier='1' href='https://www.reddit.com/r/TikTokLounge/comments/1rv7lfz/whats_the_best_site_to_buy_tiktok_followers_that/'><img alt='Buy TikTok Followers' src='https://opencollective-production.s3.us-west-1.amazonaws.com/account-avatar/751ffbfb-ef83-4b6c-a7b5-3286651bd8f0/online-casino-with-slot-machine-and-playing-cards-poker-free-vector.webp' style='object-fit: contain; float: left; margin:12px' height='120' width='120'></a>
<a title='Slotsjudge polskie kasyna.' data-id='839816' data-tier='1' href='https://slotsjudge-pl.com/'><img alt='Slotsjudge polskie kasyna.' src='https://opencollective-production.s3.us-west-1.amazonaws.com/account-avatar/66ef0e50-4a52-439f-8c46-a6918c2d4ea1/200x200.png' style='object-fit: contain; float: left; margin:12px' height='120' width='120'></a>
<a title='Buy Instagram Views' data-id='842526' data-tier='1' href='https://socialfollowers.io/instagram-views-services'><img alt='Buy Instagram Views' src='https://opencollective-production.s3.us-west-1.amazonaws.com/account-avatar/0ceaea4f-2624-43e7-a7ea-96832bbe8396/socialfollowersio_instagram_profile.jpg' style='object-fit: contain; float: left; margin:12px' height='120' width='120'></a>
<a title='apuesdeportivas.es' data-id='844554' data-tier='1' href='https://apuesdeportivas.es/'><img alt='apuesdeportivas.es' src='https://opencollective-production.s3.us-west-1.amazonaws.com/account-avatar/241e7f53-7540-443f-8063-60b9f3979069/logo%20(1).png' style='object-fit: contain; float: left; margin:12px' height='120' width='120'></a>
<a title='JBO Vietnam là thương hiệu giải trí trực tuyến nổi bật tại Việt Nam, cung cấp cá cược thể thao, esports, casino trực tuyến và nhiều trò chơi hấp dẫn khác.' data-id='848938' data-tier='1' href='https://www.jbo88b.com/vn/'><img alt='JBO Vietnam là thương hiệu giải trí trực tuyến nổi bật tại Việt Nam, cung cấp cá cược thể thao, esports, casino trực tuyến và nhiều trò chơi hấp dẫn khác.' src='https://opencollective-production.s3.us-west-1.amazonaws.com/account-avatar/382d0a06-2e32-43cc-8e91-b61bad5568b7/newLogo-Picsart-BackgroundChanger.png' style='object-fit: contain; float: left; margin:12px' height='120' width='120'></a>
<a title='At Socialboom, you can buy youtube comments, views, likes and subscribers quickly and safely. We are rated #1 best YouTube Service by Entrepreneur.' data-id='855617' data-tier='1' href='https://socialboom.io/buy-youtube-comments'><img alt='At Socialboom, you can buy youtube comments, views, likes and subscribers quickly and safely. We are rated #1 best YouTube Service by Entrepreneur.' src='https://opencollective-production.s3.us-west-1.amazonaws.com/account-avatar/0828bfc9-4e43-45f8-be2e-e1d34fcc0057/socialboom_icon.png' style='object-fit: contain; float: left; margin:12px' height='120' width='120'></a>
<a title='buy Twitter Likes and Retweets' data-id='855986' data-tier='1' href='https://www.reddit.com/r/InfluencerAsk/comments/1upqtjt/best_site_to_buy_twitter_followers_likes_and/'><img alt='buy Twitter Likes and Retweets' src='https://opencollective-production.s3.us-west-1.amazonaws.com/account-avatar/7cc615fb-2678-40d5-ad3a-444314b8e3a8/6r_10.jpg' style='object-fit: contain; float: left; margin:12px' height='120' width='120'></a>
<a title='JBO Thailand คือแพลตฟอร์มความบันเทิงออนไลน์ครบวงจร ให้บริการการเดิมพันกีฬา อีสปอร์ต คาสิโนสด และเกมยอดนิยม ผ่านระบบทันสมัย ใช้งานง่าย รองรับทุกอุปกรณ์ พร้อมมอบประสบการณ์ที่มีคุณภาพ ปลอดภัย และน่าเชื่อถือสำหรับผู้ใช้งานชาวไทย.' data-id='856471' data-tier='1' href='https://www.jbo579.com/th/'><img alt='JBO Thailand คือแพลตฟอร์มความบันเทิงออนไลน์ครบวงจร ให้บริการการเดิมพันกีฬา อีสปอร์ต คาสิโนสด และเกมยอดนิยม ผ่านระบบทันสมัย ใช้งานง่าย รองรับทุกอุปกรณ์ พร้อมมอบประสบการณ์ที่มีคุณภาพ ปลอดภัย และน่าเชื่อถือสำหรับผู้ใช้งานชาวไทย.' src='https://opencollective-production.s3.us-west-1.amazonaws.com/account-avatar/8b5789f1-7bab-4f9e-ae06-98d809114757/header-logo-TH-Picsart-BackgroundChanger.png' style='object-fit: contain; float: left; margin:12px' height='120' width='120'></a>
<a title='Buy Instagram Followers from Billingsgazette, rated best by LATimes' data-id='857722' data-tier='1' href='https://billingsgazette.com/exclusive/article_2ed65e9c-fe39-5733-ad90-231f600a18a4.html'><img alt='Buy Instagram Followers from Billingsgazette, rated best by LATimes' src='https://opencollective-production.s3.us-west-1.amazonaws.com/account-avatar/61b5b139-2654-4060-920a-22125f9e90d3/billingsgazette.png' style='object-fit: contain; float: left; margin:12px' height='120' width='120'></a>
<a title='Social Gaming Platform' data-id='858181' data-tier='1' href='https://coinsmania.com/'><img alt='Social Gaming Platform' src='https://opencollective-production.s3.us-west-1.amazonaws.com/account-avatar/a68e4399-26f6-45fa-9d7a-383a572ce100/coinsmania.png' style='object-fit: contain; float: left; margin:12px' height='120' width='120'></a>
<a title='Buy YouTube Views from Billingsgazette where we rate the best sites to buy views' data-id='863533' data-tier='1' href='https://billingsgazette.com/exclusive/article_e9c7feb3-dc7e-5b4f-97d9-e9b4e101d37c.html'><img alt='Buy YouTube Views from Billingsgazette where we rate the best sites to buy views' src='https://opencollective-production.s3.us-west-1.amazonaws.com/account-avatar/cfc656a0-7e61-4b00-8a33-afe08f512c38/billingsgazette.png' style='object-fit: contain; float: left; margin:12px' height='120' width='120'></a><!--oc-->
</div>

Please note that links to the sponsors above are not direct endorsements nor affiliated with any of contributors of the nodemon project.

# License

MIT [http://rem.mit-license.org](http://rem.mit-license.org)
