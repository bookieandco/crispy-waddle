# Terminal Fincept

<div align="center">

[![License: AGPL-3.0](https://img.shields.io/badge/license-AGPL--3.0-C06524)](https://github.com/Fincept-Corporation/FinceptTerminal/blob/main/LICENSE)[![C++20](https://img.shields.io/badge/C%2B%2B-20-00599C?logo=cplusplus)](https://isocpp.org/)[![Qt6](https://img.shields.io/badge/Qt-6-41CD52?logo=qt&logoColor=white)](https://www.qt.io/)[![Python](https://img.shields.io/badge/Python-3.11+-3776AB?logo=python&logoColor=white)](https://www.python.org/)[![Hits](https://hits.sh/github.com/Fincept-Corporation/FinceptTerminal.svg?label=Visits)](https://hits.sh/github.com/Fincept-Corporation/FinceptTerminal/)

[![Twitter](https://img.shields.io/badge/-Twitter-1DA1F2?style=flat-square&logo=twitter&logoColor=white)](https://twitter.com/intent/tweet?text=Check%20out%20FinceptTerminal&url=https%3A//github.com/Fincept-Corporation/FinceptTerminal/)[![LinkedIn](https://img.shields.io/badge/-LinkedIn-0077B5?style=flat-square&logo=linkedin&logoColor=white)](https://www.linkedin.com/sharing/share-offsite/?url=https%3A//github.com/Fincept-Corporation/FinceptTerminal/)[![Facebook](https://img.shields.io/badge/-Facebook-1877F2?style=flat-square&logo=facebook&logoColor=white)](https://www.facebook.com/sharer/sharer.php?u=https%3A//github.com/Fincept-Corporation/FinceptTerminal/)[![Reddit](https://img.shields.io/badge/-Reddit-FF4500?style=flat-square&logo=reddit&logoColor=white)](https://www.reddit.com/submit?url=https%3A//github.com/Fincept-Corporation/FinceptTerminal/&title=FinceptTerminal)[![WhatsApp](https://img.shields.io/badge/-WhatsApp-25D366?style=flat-square&logo=whatsapp&logoColor=white)](https://api.whatsapp.com/send?text=Check%20out%20FinceptTerminal%3A%20https%3A//github.com/Fincept-Corporation/FinceptTerminal/)

### **Tu pensamiento es el único límite. Los datos no lo son.**

Plataforma de inteligencia financiera de última generación con análisis financiero de nivel institucional, automatización de IA y conectividad de datos ilimitada.

[📥 Descargar](https://github.com/Fincept-Corporation/FinceptTerminal/releases)·[📚 Documentos](https://github.com/Fincept-Corporation/FinceptTerminal/tree/main/docs)·[💬 Discusiones](https://github.com/Fincept-Corporation/FinceptTerminal/discussions)·[💬 Discordia](https://discord.gg/ae87a8ygbN)·[🤝 Socio](https://github.com/Fincept-Corporation/FinceptTerminal/blob/main/docs/COMMERCIAL_LICENSE.md)

![Fincept Terminal](https://raw.githubusercontent.com/Fincept-Corporation/FinceptTerminal/main/images/Dashboard.png)

</div>

* * *

## Acerca de

**Terminal fincept vch**es una aplicación de escritorio nativa pura de C++20. se utiliza**qt6**para interfaz de usuario y renderizado, integrado**Pitón**para análisis y ofrece rendimiento de clase terminal profesional en un único binario nativo.

* * *

## Características

| **Característica**                   | **Descripción**                                                                                                                                                                                                                            |
| ------------------------------------ | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| 📊**Análisis multiactivo**           | Modelos DCF, optimización de cartera, métricas de riesgo (VaR, Sharpe), valoración de derivados en renta variable, renta fija, derivados, cartera y alternativos a través de Python integrado                                              |
| 🤖**Agentes de IA**                  | Más de 20 personas de inversores (Buffett, Dalio, Graham), estrategias de fondos de cobertura, soporte de LLM local, múltiples proveedores (OpenAI, Anthropic, Gemini, Groq, DeepSeek, MiniMax, OpenRouter, Ollama)                        |
| 🌐**Más de 100 conectores de datos** | DBnomics, Polygon, Kraken, Yahoo Finance, FRED, FMI, Banco Mundial, AkShare, API gubernamentales, además de superposiciones de datos alternativos opcionales, como el sentimiento del mercado de Adanos para la investigación de acciones. |
| 📈**Comercio en tiempo real**        | Cripto (Kraken/HyperLiquid WebSocket), acciones, comercio algorítmico, motor de comercio de papel                                                                                                                                          |
| 🔬**Suite QuantLib**                 | 18 módulos de análisis cuantitativo: fijación de precios, riesgo, estocástico, volatilidad, renta fija                                                                                                                                     |
| 🚢**Inteligencia global**            | Seguimiento marítimo, análisis geopolítico, mapeo de relaciones, datos satelitales.                                                                                                                                                        |
| 🎨**Flujos de trabajo visuales**     | Editor de nodos para canales de automatización, integración de herramientas MCP                                                                                                                                                            |
| 🧠**Laboratorio cuantitativo de IA** | Modelos de aprendizaje automático, descubrimiento de factores, HFT, comercio de aprendizaje por refuerzo                                                                                                                                   |

* * *

## Instalación

### Opción 1: descargar binario prediseñado (recomendado)

Los archivos binarios prediseñados están disponibles en[Página de lanzamientos](https://github.com/Fincept-Corporation/FinceptTerminal/releases). No se requieren herramientas de compilación: simplemente extraiga y ejecute.

| Plataforma                | Descargar                                | Correr                                               |
| ------------------------- | ---------------------------------------- | ---------------------------------------------------- |
| **Ventanas x64**          | `FinceptTerminal-Windows-x64.zip`        | Extraer →`FinceptTerminal.exe`                       |
| **ventanas ARM64**        | `FinceptTerminal-Windows-arm64.zip`      | Extraer →`FinceptTerminal.exe`                       |
| **Linuxx64**              | `FinceptTerminal-Linux-x86_64.AppImage`  | `chmod +x`→`./FinceptTerminal-Linux-x86_64.AppImage` |
| **macOS (Apple Silicio)** | `FinceptTerminal-macOS-arm64.tar.gz`     | Extraer →`./FinceptTerminal`                         |
| **MacOS (Intel)**         | `FinceptTerminal-macOS-x64.tar.gz`       | Extraer →`./FinceptTerminal`                         |
| **macOS (universal)**     | `FinceptTerminal-macOS-universal.tar.gz` | Extraer →`./FinceptTerminal`                         |

* * *

### Opción 2: Inicio rápido (compilación con un clic)

Clona y ejecuta el script de instalación: instala todas las dependencias y crea la aplicación automáticamente:

```bash
# Linux / macOS
git clone https://github.com/Fincept-Corporation/FinceptTerminal.git
cd FinceptTerminal
chmod +x setup.sh && ./setup.sh
```

```bat
# Windows — run from Developer Command Prompt for VS 2022
git clone https://github.com/Fincept-Corporation/FinceptTerminal.git
cd FinceptTerminal
setup.bat
```

El script maneja: verificación del compilador, CMake, Qt6, Python, compilación y lanzamiento.

* * *

### Opción 3: ventana acoplable

```bash
# Pull and run
docker pull ghcr.io/fincept-corporation/fincept-terminal:latest
docker run --rm -e DISPLAY=$DISPLAY -v /tmp/.X11-unix:/tmp/.X11-unix \
    ghcr.io/fincept-corporation/fincept-terminal:latest

# Or build from source
git clone https://github.com/Fincept-Corporation/FinceptTerminal.git
cd FinceptTerminal
docker build -t fincept-terminal .
docker run --rm -e DISPLAY=$DISPLAY -v /tmp/.X11-unix:/tmp/.X11-unix fincept-terminal
```

> **Nota:**Docker está destinado principalmente a Linux. macOS y Windows requieren una configuración XServer adicional.

* * *

### Opción 4: compilar desde el código fuente (manual)

> **Las versiones están ancladas** (Qt 6.7.2, CMake 3.27.7, MSVC 19.38 / GCC 12.3 / Apple Clang 15.0, Python 3.11.9). Para evitar divergencias de traducción, consulte las instrucciones oficiales en inglés:
>
> 👉 **[README.md (English) — Build from Source](../../README.md#option-4--build-from-source-manual)**
>
> Inicio rápido con presets de CMake:
> ```bash
> ./setup.sh                                            # Linux / macOS — instalación automatizada
> setup.bat                                             # Windows (VS 2022 Developer Cmd)
>
> # O manual:
> cd FinceptTerminal/fincept-qt
> cmake --preset linux-release   && cmake --build --preset linux-release
> cmake --preset macos-release   && cmake --build --preset macos-release
> cmake --preset win-release     && cmake --build --preset win-release
> ```

* * *

## Lo que nos diferencia

**Terminal Fincept**es una plataforma financiera de código abierto creada para aquellos que se niegan a verse limitados por el software tradicional. Competimos en**profundidad analítica**y**accesibilidad a los datos**– no en información privilegiada ni en feeds exclusivos.

Las versiones recientes también admiten opciones opcionales.**Sentimiento del mercado de Adanos**conectividad en**Fuentes de datos → Datos alternativos**. Cuando se configura, Equity Research puede mostrar instantáneas del sentimiento minorista de fuentes cruzadas en Reddit, X, noticias financieras y Polymarket. Sin una conexión activa de Adanos, la función permanece inactiva y el resto de la aplicación se comporta exactamente como antes.

-   **Rendimiento nativo**— C++20 con Qt6, sin sobrecarga de Electron/web
-   **binario único**— sin Node.js, sin tiempo de ejecución del navegador, sin paquete de JavaScript
-   **Kit completo de analista buy-side**— renta variable, cartera, derivados, renta fija, finanzas corporativas, alternativos
-   **Más de 100 conectores de datos**— desde Yahoo Finance hasta las bases de datos gubernamentales
-   **Gratis y de código abierto**(AGPL-3.0) con licencias comerciales disponibles

* * *

## Hoja de ruta

| Línea de tiempo              | Hito                                                                                                             |
| ---------------------------- | ---------------------------------------------------------------------------------------------------------------- |
| **Primer trimestre de 2026** | Transmisión en tiempo real, backtesting avanzado, integraciones de corredores                                    |
| **vómitos 2026**             | Creador de estrategias de opciones, gestión de carteras múltiples, más de 50 agentes de IA                       |
| **KZ 2026**                  | API programática, interfaz de usuario de capacitación de aprendizaje automático, características institucionales |
| **Futuro**                   | Compañero móvil, sincronización en la nube, mercado comunitario                                                  |

* * *

## Contribuyendo

Estamos construyendo juntos el futuro del análisis financiero.

**Contribuir:**Nuevos conectores de datos, agentes de IA, módulos de análisis, pantallas C++, documentación

-   [Guía contribuyente](docs/CONTRIBUTING.md)
-   [Guía de contribución de C++](fincept-qt/CONTRIBUTING.md)
-   [Guía para contribuyentes de Python](docs/PYTHON_CONTRIBUTOR_GUIDE.md)
-   [Informar error](https://github.com/Fincept-Corporation/FinceptTerminal/issues)
-   [Solicitar función](https://github.com/Fincept-Corporation/FinceptTerminal/discussions)

* * *

## Para universidades y educadores

**Lleve análisis financieros de nivel profesional a su salón de clases.**

-   **$799/mes**por 20 cuentas
-   Acceso completo a los datos y API de Fincept
-   Perfecto para cursos de finanzas, economía y ciencia de datos
-   Análisis integrado de renta variable, cartera, derivados, renta fija y economía

**¿Interesado?**Correo electrónico**[support@fincept.in](mailto:support@fincept.in)**con el nombre de su institución.

[Detalles de la licencia universitaria](https://github.com/Fincept-Corporation/FinceptTerminal/blob/main/docs/COMMERCIAL_LICENSE.md)

* * *

## Licencia

**Licencia dual: AGPL-3.0 (código abierto) + Comercial**

### Código abierto (AGPL-3.0)

-   Gratis para uso personal, educativo y no comercial
-   Requiere modificaciones para compartir cuando se distribuye o se utiliza como servicio de red
-   Transparencia total del código fuente

### Licencia Comercial

-   Requerido para uso comercial o para acceder comercialmente a Fincept Data/API
-   Contacto:**[support@fincept.in](mailto:support@fincept.in)**
-   Detalles:[Guía de licencia comercial](https://github.com/Fincept-Corporation/FinceptTerminal/blob/main/docs/COMMERCIAL_LICENSE.md)

### Marcas registradas

"Fincept Terminal" y "Fincept" son marcas comerciales de Fincept Corporation.

© 2025-2026 Corporación Fincept. Reservados todos los derechos.

* * *

<div align="center">

### **Tu pensamiento es el único límite. Los datos no lo son.**

<div align="center">
<a href="https://star-history.com/#Fincept-Corporation/FinceptTerminal&Date">
 <picture>
   <source media="(prefers-color-scheme: dark)" srcset="https://api.star-history.com/svg?repos=Fincept-Corporation/FinceptTerminal&type=Date&theme=dark" />
   <source media="(prefers-color-scheme: light)" srcset="https://api.star-history.com/svg?repos=Fincept-Corporation/FinceptTerminal&type=Date" />
   <img alt="Star History Chart" src="https://api.star-history.com/svg?repos=Fincept-Corporation/FinceptTerminal&type=Date" />
 </picture>
</a>
</div>

[![Email](https://img.shields.io/badge/Email-support@fincept.in-blue)](mailto:support@fincept.in)

⭐**Estrella**· 🔄**Compartir**· 🤝**Contribuir**

</div>
