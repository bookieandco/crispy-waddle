﻿namespace Aardvark.UI.Suave

open Suave
open Suave.Filters
open Suave.Sockets
open Suave.Sockets.Control
open System
open System.IO
open System.Net.Sockets
open System.Runtime.InteropServices
open System.Threading
open System.Threading.Tasks
open Aardvark.Base
open Aardvark.UI

module internal Opcode =

    let ofWebSocketOpCode =
        LookupTable.lookup [
            WebSocketOpCode.Ping,   WebSocket.Opcode.Ping
            WebSocketOpCode.Pong,   WebSocket.Opcode.Pong
            WebSocketOpCode.Text,   WebSocket.Opcode.Text
            WebSocketOpCode.Binary, WebSocket.Opcode.Binary
            WebSocketOpCode.Close,  WebSocket.Opcode.Close
        ]

    let toWebSocketOpCode =
        LookupTable.lookup [
            WebSocket.Opcode.Ping,   WebSocketOpCode.Ping
            WebSocket.Opcode.Pong,   WebSocketOpCode.Pong
            WebSocket.Opcode.Text,   WebSocketOpCode.Text
            WebSocket.Opcode.Binary, WebSocketOpCode.Binary
            WebSocket.Opcode.Close,  WebSocketOpCode.Close
        ]

module internal SocketOp =

    let toTask (socketOp: Sockets.SocketOp<'T>) : Task<'T> =
        task {
            match! socketOp with
            | Choice1Of2 result ->
                return result

            | Choice2Of2 (Error.SocketError err) ->
                return raise <| SocketException(int err)

            | Choice2Of2 (Error.InputDataError (status, message)) ->
                let code = match status with Some status -> $" ({status})" | _ -> ""
                return raise <| ConnectionException($"Input data error: {message}{code}")

            | Choice2Of2 (Error.ConnectionError message) ->
                // See: https://github.com/SuaveIO/suave/blob/v2.5.6/src/Suave/Sockets/TcpTransport.fs
                if message.Contains "acceptArgs.AcceptSocket = null" then
                    return raise <| ConnectionException(ConnectionError.Lost)
                else
                    return raise <| ConnectionException(message)
        }

type internal WebSocket(socket: WebSocket.WebSocket) =

    member _.Send(message: WebSocketOpCode, data: byte[], cancellationToken: CancellationToken, [<Optional; DefaultParameterValue(true)>] endOfMessage: bool) : Task =
        if cancellationToken.IsCancellationRequested then
            Task.CompletedTask
        else
            let opcode = Opcode.ofWebSocketOpCode message
            let data = ByteSegment data
            SocketOp.toTask (socket.send opcode data endOfMessage)

    member _.Receive(buffer: SocketBuffer, cancellationToken: CancellationToken) =
        let rec read() =
            SocketMonad.socket {
                cancellationToken.ThrowIfCancellationRequested()

                let! opcode, data, endOfMessage = socket.read()
                buffer.Write(data)

                if endOfMessage then
                    return opcode
                else
                    let! _ = read()
                    return opcode
            }

        read()
        |> Async.map (Choice.map Opcode.toWebSocketOpCode)
        |> SocketOp.toTask

    member this.Close(cancellationToken: CancellationToken) =
        this.Send(WebSocketOpCode.Close, Array.empty, cancellationToken)

    interface IWebSocket with
        member _.Dispose() = ()
        member this.Send(message, data, cancellationToken, endOfMessage) = this.Send(message, data, cancellationToken, endOfMessage)
        member this.Receive(buffer, cancellationToken) = this.Receive(buffer, cancellationToken)
        member this.Close(cancellationToken) = this.Close(cancellationToken)

type HttpBackend private () =
    static let instance = HttpBackend()
    static member Instance : IHttpBackend<_, _> = instance

    interface IHttpBackend<HttpContext, WebPart> with
        member _.withContext handler =
            fun context ->
                let handler = handler context
                handler context

        member _.getRequest context =
            { new IHttpRequest with
                member _.Path = context.request.path
                member _.Body = new MemoryStream(context.request.rawForm)
                member _.Method = context.request.rawMethod
                member _.Header(name) =
                    match context.request.header name with
                    | Choice1Of2 value -> Some value
                    | _ -> None
                member _.Headers =
                    Map.ofList context.request.headers
                member _.QueryParam(name) =
                    context.request.query
                    |> List.tryPick (function n, Some v when n = name -> Some v | _ -> None)
                member _.QueryParams =
                    (Map.empty, context.request.query) ||> Seq.fold (fun result (name, value) ->
                        let value = Option.toList value

                        let values =
                            match result |> Map.tryFindV name with
                            | ValueSome old -> old @ value
                            | _ -> value

                        result |> Map.add name values
                    )
            }

        member _.async handler =
            fun ctx ->
                async {
                    let! handler = Async.AwaitTask handler
                    return! handler ctx
                }

        member _.choose handlers =
            choose handlers

        member _.route path =
            Filters.path path

        member _.routef path handler =
            pathScan path handler

        member _.subRoute path handler =
            let prefix = Filters.prefix path
            compose prefix handler

        member _.compose h1 h2 =
            compose h1 h2

        member _.mimeType mimeType =
            Writers.setMimeType mimeType

        member _.redirectTo _ location =
            Redirection.redirect location

        member _.handShake continuation =
            WebSocket.handShake (fun socket context ->
                let socket = new WebSocket(socket)

                async {
                    try
                        do! continuation socket context
                        return Choice1Of2 ()

                    with
                    | exn when (exn.GetBaseException() :? OperationCanceledException) ->
                        return Choice1Of2 ()

                    | :? SocketException as exn ->
                        let error = Error.SocketError (enum<SocketError> exn.ErrorCode)
                        return Choice2Of2 error

                    | exn ->
                        let error = Error.ConnectionError exn.Message
                        return Choice2Of2 error
                }
            )

        member _.method httpMethod =
            method <| HttpMethod.OTHER httpMethod

        member _.header key value =
            Writers.setHeader key (string value)

        member _.status (status: int) =
            fun ctx -> { ctx with response.status.code = status } |> succeed

        member _.response (data: uint8[]) =
            fun ctx -> { ctx with response.content = Bytes data } |> succeed

        member this.response (data: string) =
            fun ctx -> { ctx with response.content = Bytes (UTF8.bytes data) } |> succeed

        member _.sendFile filePath =
            Files.sendFile filePath false