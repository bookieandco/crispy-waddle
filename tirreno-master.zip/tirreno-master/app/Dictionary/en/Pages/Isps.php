<?php

/**
 * tirreno ~ open-source security framework
 * Copyright (c) Tirreno Technologies Sàrl (https://www.tirreno.com)
 *
 * Licensed under GNU Affero General Public License version 3 of the or any later version.
 * For full copyright and license information, please see the LICENSE
 * Redistributions of files must retain the above copyright notice.
 *
 * @copyright     Copyright (c) Tirreno Technologies Sàrl (https://www.tirreno.com)
 * @license       https://opensource.org/licenses/AGPL-3.0 AGPL License
 * @link          https://www.tirreno.com Tirreno(tm)
 */

declare(strict_types=1);

return [
    'isps_page_title' => 'ISPs',
    'isps_breadcrumb_title' => 'ISPs',
    'isps_search_placeholder' => 'ASN, Network operator or Description',
    'isps_table_title' => 'ISPs',
    'isps_table_title_tooltip' => 'This page displays analytics grouped by an internet service provider (ISP), as identified by IP address. The data is shown for a selected period of time. The chart displays the daily number of unique and newly reported active ISPs. To open a page with more details on a particular ISP, click on a table row.',
];
