import Foundation
import Testing
@testable import PalmierPro

@MainActor
private final class UndoCounter {
    var value = 0
}

@MainActor
private func setCounter(_ value: Int, actionName: String, counter: UndoCounter, undo: EditorUndo) {
    let previous = counter.value
    counter.value = value
    undo.register(actionName, withTarget: counter) { target in
        setCounter(previous, actionName: actionName, counter: target, undo: undo)
    }
}

@MainActor
@Suite("EditorUndo")
struct EditorUndoTests {
    private enum ExpectedError: Error { case expected }

    private func harness() -> (EditorUndo, UndoManager, UndoCounter) {
        let undo = EditorUndo()
        let manager = UndoManager()
        let counter = UndoCounter()
        undo.attach(manager)
        return (undo, manager, counter)
    }

    @Test func directRegistrationsAreSeparateBalancedGroups() {
        let (undo, manager, counter) = harness()

        setCounter(1, actionName: "First", counter: counter, undo: undo)
        setCounter(2, actionName: "Second", counter: counter, undo: undo)

        #expect(manager.groupsByEvent)
        #expect(manager.groupingLevel == 0)
        #expect(manager.undoActionName == "Second")
        undo.perform("No-op") {}
        #expect(manager.undoActionName == "Second")
        #expect(undo.undoLatest() == "Second")
        #expect(counter.value == 1)
        #expect(undo.undoLatest() == "First")
        #expect(counter.value == 0)
        manager.redo()
        #expect(counter.value == 1)
    }

    @Test func transactionPreservesExistingGroup() {
        let (undo, manager, counter) = harness()
        let textStorage = UndoCounter()
        manager.registerUndo(withTarget: textStorage) { _ in }
        let initialGroupingLevel = manager.groupingLevel

        setCounter(1, actionName: "Set", counter: counter, undo: undo)

        #expect(initialGroupingLevel > 0)
        #expect(manager.groupingLevel == initialGroupingLevel)
    }

    @Test func nestedTransactionsProduceOneUndoStep() {
        let (undo, manager, first) = harness()
        let second = UndoCounter()

        undo.perform("Outer") {
            setCounter(1, actionName: "First", counter: first, undo: undo)
            undo.perform("Inner") {
                setCounter(2, actionName: "Second", counter: second, undo: undo)
            }
        }

        #expect(manager.groupingLevel == 0)
        #expect(manager.undoActionName == "Outer")
        #expect(undo.undoLatest() == "Outer")
        #expect(first.value == 0)
        #expect(second.value == 0)
        #expect(manager.canUndo == false)
        #expect(manager.redoActionName == "Outer")
        manager.redo()
        #expect(manager.undoActionName == "Outer")
    }

    @Test func reportsOnlyCommittedOutermostActionsWithOrigin() {
        let (undo, manager, counter) = harness()
        var committedActionCount = 0
        var origin: Analytics.Origin?
        undo.onActionCommitted = {
            committedActionCount += 1
            origin = Analytics.origin
        }

        undo.perform("No-op") {}
        Analytics.$origin.withValue(Analytics.Origin(source: "agent", sessionID: "session-1")) {
            undo.perform("Outer") {
                setCounter(1, actionName: "Inner", counter: counter, undo: undo)
            }
        }

        #expect(committedActionCount == 1)
        #expect(origin?.source == "agent")
        #expect(origin?.sessionID == "session-1")
        withExtendedLifetime(manager) {}
    }

    @Test func replayingAnActionReportsNoNewCommit() {
        let (undo, manager, counter) = harness()
        setCounter(1, actionName: "Set Counter", counter: counter, undo: undo)
        var committedActionCount = 0
        undo.onActionCommitted = { committedActionCount += 1 }

        manager.undo()
        manager.redo()

        #expect(committedActionCount == 0)
    }

    @Test func transactionDoesNotCloseArmedEventGroup() {
        let (undo, manager, counter) = harness()
        let textStorage = UndoCounter()

        // A direct registration (AppKit-style, outside EditorUndo) lazily
        // opens the automatic event group. Foundation only disarms its
        // "event group open" bookkeeping in the deferred group ending that
        // NSDocument's save completion also invokes — nothing else clears it.
        manager.registerUndo(withTarget: textStorage) { _ in }
        let armedLevel = manager.groupingLevel
        #expect(armedLevel > 0)

        // An agent transaction must therefore never close the automatic
        // event group itself. 0.6.6's ToolExecutor did
        // (`if groupingLevel == 1 { endUndoGrouping() }`), which left the
        // bookkeeping armed with no open group; the next save completion
        // then raised "endUndoGrouping called with no matching begin" —
        // fatal under NSApplicationCrashOnExceptions, and far from the
        // cause. The transaction has to nest inside the armed group and
        // leave it open for its scheduled ending.
        undo.perform("Agent Edit") {
            setCounter(1, actionName: "Agent Edit", counter: counter, undo: undo)
        }
        #expect(manager.groupingLevel == armedLevel)
        #expect(manager.groupsByEvent)

        // removeAllActions is the public API that both drains the history
        // and cancels the scheduled automatic ending, so no armed state
        // leaks into other tests.
        manager.removeAllActions()
        #expect(manager.groupingLevel == 0)
    }

    @Test func throwingScopesRestoreUndoState() {
        let (undo, manager, counter) = harness()

        #expect(throws: ExpectedError.self) {
            try undo.perform("Throwing") {
                setCounter(1, actionName: "Set", counter: counter, undo: undo)
                throw ExpectedError.expected
            }
        }
        #expect(manager.groupingLevel == 0)
        _ = undo.undoLatest()
        #expect(counter.value == 0)
        manager.removeAllActions()

        #expect(throws: ExpectedError.self) {
            try undo.withoutRegistration {
                setCounter(1, actionName: "Suppressed", counter: counter, undo: undo)
                throw ExpectedError.expected
            }
        }
        #expect(undo.isRegistrationEnabled)
        #expect(manager.groupingLevel == 0)
        #expect(manager.canUndo == false)
    }
}
