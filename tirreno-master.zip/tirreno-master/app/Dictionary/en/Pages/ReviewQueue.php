<?php

/**
 * tirreno ~ open-source security framework
 * Copyright (c) Tirreno Technologies Sàrl (https://www.tirreno.com)
 *
 * Licensed under GNU Affero General Public License version 3 of the or any later version.
 * For full copyright and license information, please see the LICENSE
 * Redistributions of files must retain the above copyright notice.
 *
 * @copyright     Copyright (c) Tirreno Technologies Sàrl (https://www.tirreno.com)
 * @license       https://opensource.org/licenses/AGPL-3.0 AGPL License
 * @link          https://www.tirreno.com Tirreno(tm)
 */

declare(strict_types=1);

return [
    'reviewQueue_page_title' => 'Review queue',
    'reviewQueue_breadcrumb_title' => 'Review queue',

    'reviewQueue_search_placeholder' => 'Entity Name and Added to review date',

    'reviewQueue_table_title' => 'Entities for review',
    'reviewQueue_table_title_tooltip' => 'This page lists entities with low trust scores and facilitates their removal from the queue by performing a review process. To open a page with more information on an entity, click on an email address. The chart shows the number of entities added to the review queue each day during a selected period of time.',
];
