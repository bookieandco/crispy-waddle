import type { MenuItemConstructorOptions, MenuItem } from 'electron';
import { useCallback, useMemo } from 'react';

// TODO pull out?
const { getCurrentWindow, Menu } = window.require('@electron/remote');
// eslint-disable-next-line prefer-destructuring

// https://github.com/transflow/use-electron-context-menu
// https://www.electronjs.org/docs/latest/api/menu-item
export default function useNativeMenu(
  template: (MenuItemConstructorOptions | MenuItem)[],
  options: { x?: number, y?: number, onContext?: (e: MouseEvent) => void, onClose?: () => void } = {},
) {
  const menu = useMemo(() => Menu.buildFromTemplate(template), [template]);

  const { x, y, onContext, onClose } = options;

  const openMenu = useCallback((e: MouseEvent) => {
    // @ts-expect-error todo type this
    menu.popup({
      window: getCurrentWindow(),
      x,
      y,
      callback: onClose,
    });

    if (onContext) onContext(e);
  }, [menu, onClose, onContext, x, y]);

  const closeMenu = useCallback(() => menu.closePopup(), [menu]);

  return { openMenu, closeMenu };
}
