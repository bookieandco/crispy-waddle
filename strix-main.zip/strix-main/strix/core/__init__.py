"""Strix scan runtime core."""
