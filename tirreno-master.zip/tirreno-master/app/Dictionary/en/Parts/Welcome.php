<?php

/**
 * tirreno ~ open-source security framework
 * Copyright (c) Tirreno Technologies Sàrl (https://www.tirreno.com)
 *
 * Licensed under GNU Affero General Public License version 3 of the or any later version.
 * For full copyright and license information, please see the LICENSE
 * Redistributions of files must retain the above copyright notice.
 *
 * @copyright     Copyright (c) Tirreno Technologies Sàrl (https://www.tirreno.com)
 * @license       https://opensource.org/licenses/AGPL-3.0 AGPL License
 * @link          https://www.tirreno.com Tirreno(tm)
 */

declare(strict_types=1);

return [
    'Welcome_hello_with_name' => 'Hello, ',
    'Welcome_hello_without_name' => 'Hello',
    'Welcome_how_are_you_doing' => 'I hope you are having a great day!',
    'Welcome_global_search_placeholder' => 'Search Entity ID, IP, ASN',
];
