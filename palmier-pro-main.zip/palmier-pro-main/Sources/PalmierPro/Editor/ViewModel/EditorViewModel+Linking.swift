import AppKit

/// Snapshot of the video/audio track partition. Video/image tracks sit at
/// indices `[0, firstAudioIndex)`; audio tracks at `[firstAudioIndex, trackCount)`.
struct ZoneLayout {
    let trackCount: Int
    let firstAudioIndex: Int
    var videoTrackCount: Int { firstAudioIndex }
    var audioTrackCount: Int { trackCount - firstAudioIndex }
}

/// Link groups: clips that share a `linkGroupId` behave as one unit for selection, move, trim, and delete.
extension EditorViewModel {

    // MARK: - Indexes

    /// Reverse link-group index — built in a single O(tracks·clips) pass.
    var linkIndex: [String: [String]] {
        var m: [String: [String]] = [:]
        for t in timeline.tracks {
            for c in t.clips {
                if let g = c.linkGroupId { m[g, default: []].append(c.id) }
            }
        }
        return m
    }

    /// Video/audio zone partition.
    var zones: ZoneLayout {
        let count = timeline.tracks.count
        let firstAudio = timeline.tracks.firstIndex(where: { $0.type == .audio }) ?? count
        return ZoneLayout(trackCount: count, firstAudioIndex: firstAudio)
    }

    // MARK: - Group lookup

    /// Returns every clip id sharing a link group with any id in `ids`,
    /// including the inputs themselves.
    func expandToLinkGroup(_ ids: Set<String>) -> Set<String> {
        let idx = linkIndex
        var clipToGroup: [String: String] = [:]
        for (gid, members) in idx {
            for id in members { clipToGroup[id] = gid }
        }
        var groups = Set<String>()
        for id in ids {
            if let g = clipToGroup[id] { groups.insert(g) }
        }
        guard !groups.isEmpty else { return ids }
        var result = ids
        for g in groups {
            if let members = idx[g] { result.formUnion(members) }
        }
        return result
    }

    /// Ids of clips that share `clip`'s link group, excluding `clip` itself.
    func linkedPartnerIds(of clipId: String) -> [String] {
        for (_, members) in linkIndex where members.contains(clipId) {
            return members.filter { $0 != clipId }
        }
        return []
    }

    /// For a single-clip frame move, returns the linked-partner moves needed to keep
    /// audio/video in sync
    func partnerMoves(forMoveOf clipId: String, toFrame: Int) -> [(clipId: String, toFrame: Int)] {
        guard let lead = findClip(id: clipId) else { return [] }
        let currentFrame = timeline.tracks[lead.trackIndex].clips[lead.clipIndex].startFrame
        let delta = toFrame - currentFrame
        guard delta != 0 else { return [] }
        return linkedPartnerIds(of: clipId).compactMap { pid in
            guard let pLoc = findClip(id: pid) else { return nil }
            let pClip = timeline.tracks[pLoc.trackIndex].clips[pLoc.clipIndex]
            return (clipId: pid, toFrame: max(0, pClip.startFrame + delta))
        }
    }

    /// Returns the linked-partner IDs that should receive a timing-style change
    /// (durationFrames, trim, speed) applied uniformly to `clipIds`.
    func timingPropagationPartners(of clipIds: Set<String>) -> Set<String> {
        var out: Set<String> = []
        for id in clipIds {
            for pid in linkedPartnerIds(of: id) where !clipIds.contains(pid) {
                out.insert(pid)
            }
        }
        return out
    }

    // MARK: - Out-of-sync offset

    /// Batch-compute out-of-sync offsets for every linked clip in a single
    /// pass. Clips in sync (or unlinked) are absent from the returned map.
    func linkGroupOffsets() -> [String: Int] {
        let fps = timeline.fps
        let membersByGroup: [String: [String: MulticamSource.Member]] = multicamGroups.reduce(into: [:]) {
            $0[$1.id] = $1.members.reduce(into: [:]) { $0[$1.mediaRef] = $1 }
        }
        var byGroup: [String: [(id: String, start: Int)]] = [:]
        var mcByGroup: [String: [(id: String, start: Int, range: Range<Int>)]] = [:]
        for track in timeline.tracks {
            for clip in track.clips {
                if let mcId = clip.multicamGroupId, let member = membersByGroup[mcId]?[clip.mediaRef] {
                    mcByGroup[mcId, default: []].append(
                        (clip.id, member.anchorFrame(of: clip, fps: fps), clip.startFrame..<clip.endFrame))
                }
                guard let gid = clip.linkGroupId else { continue }
                byGroup[gid, default: []].append((clip.id, clip.startFrame - clip.trimStartFrame))
            }
        }
        var offsets: [String: Int] = [:]
        for (_, entries) in byGroup where entries.count > 1 {
            let ref = entries.lazy.map(\.start).min()!
            for entry in entries where entry.start != ref {
                offsets[entry.id] = entry.start - ref
            }
        }
        for (_, entries) in mcByGroup where entries.count > 1 {
            var cluster: [(id: String, start: Int, range: Range<Int>)] = []
            var clusterEnd = Int.min
            func flush() {
                guard cluster.count > 1, let ref = cluster.lazy.map(\.start).min() else { return }
                for entry in cluster where entry.start != ref {
                    offsets[entry.id] = entry.start - ref
                }
            }
            for entry in entries.sorted(by: { $0.range.lowerBound < $1.range.lowerBound }) {
                if entry.range.lowerBound >= clusterEnd {
                    flush()
                    cluster = []
                }
                cluster.append(entry)
                clusterEnd = max(clusterEnd, entry.range.upperBound)
            }
            flush()
        }
        return offsets
    }

    // MARK: - Link / Unlink commands

    /// Stamp a new `linkGroupId` on every clip in `ids`, merging pre-existing sub-groups into the new group.
    func linkClips(ids: Set<String>) {
        guard let ids = linkTargets(for: ids) else { return }
        let newGroup = UUID().uuidString
        mutateClips(ids: ids, actionName: "Link") { $0.linkGroupId = newGroup }
    }

    /// Clear `linkGroupId` on every clip that shares a group with any id in `ids`.
    func unlinkClips(ids: Set<String>) {
        mutateClips(ids: unlinkTargets(for: ids), actionName: "Unlink") { $0.linkGroupId = nil }
        selectedClipIds.removeAll()
    }

    // MARK: - Trim with linked propagation

    enum TrimEdge {
        case left, right
    }

    /// Apply a trim-drag commit. Expands the edit set to linked partners when `propagateToLinked` is on and hands off to `trimClips`.
    func commitTrim(clipId: String, edge: TrimEdge, deltaFrames: Int, propagateToLinked: Bool) {
        guard let loc = findClip(id: clipId) else { return }
        let leadClip = timeline.tracks[loc.trackIndex].clips[loc.clipIndex]
        var targets = [leadClip]
        if propagateToLinked {
            targets += linkedPartnerIds(of: clipId).compactMap { pid in
                findClip(id: pid).map { timeline.tracks[$0.trackIndex].clips[$0.clipIndex] }
            }
        }
        var deltaFrames = deltaFrames
        for target in targets {
            guard let bounds = multicamTrimBounds(for: target) else { continue }
            deltaFrames = edge == .left ? max(deltaFrames, -bounds.left) : min(deltaFrames, bounds.right)
        }
        let edits = targets.map { clip -> (clipId: String, trimStartFrame: Int, trimEndFrame: Int) in
            let v = trimValues(for: clip, edge: edge, delta: deltaFrames)
            return (clip.id, v.trimStart, v.trimEnd)
        }
        trimClips(edits)
    }

    /// Nest trim limits come from the child's live length, not creation time.
    func effectiveTrimEnd(for clip: Clip) -> Int {
        guard clip.sourceClipType == .sequence, let child = timeline(for: clip.mediaRef) else {
            return clip.trimEndFrame
        }
        return max(0, child.totalFrames - clip.trimStartFrame - clip.durationFrames)
    }

    /// Slip: shift which source range plays without moving the clip on the timeline.
    /// Positive delta (drag right) reveals earlier material: trimStart -= d, trimEnd += d.
    /// A clip's trim can be slipped only if it has bounded source material and isn't part of a multicam group.
    func isSlipEligible(_ clip: Clip) -> Bool {
        clip.mediaType != .image && clip.mediaType != .text && clip.multicamGroupId == nil
    }

    /// Linked partners of `clipId` whose trim should slip along with it — the same
    /// eligibility filter `commitSlip` applies, so live preview and commit agree.
    func slipPropagationPartnerIds(of clipId: String) -> [String] {
        linkedPartnerIds(of: clipId).filter { clipFor(id: $0).map(isSlipEligible) ?? false }
    }

    func commitSlip(clipId: String, deltaFrames: Int, propagateToLinked: Bool) {
        guard let loc = findClip(id: clipId) else { return }
        let lead = timeline.tracks[loc.trackIndex].clips[loc.clipIndex]
        var targets = [lead]
        if propagateToLinked {
            targets += slipPropagationPartnerIds(of: clipId).compactMap { pid in
                findClip(id: pid).map { timeline.tracks[$0.trackIndex].clips[$0.clipIndex] }
            }
        }
        targets = targets.filter(isSlipEligible)
        guard !targets.isEmpty else { return }

        // Clamp the shared timeline delta to the tightest headroom in the group.
        var delta = deltaFrames
        for t in targets {
            let speed = max(t.speed, 0.001)
            delta = min(delta, Int((Double(t.trimStartFrame) / speed).rounded(.down)))
            delta = max(delta, -Int((Double(effectiveTrimEnd(for: t)) / speed).rounded(.down)))
        }
        guard delta != 0 else { return }

        // Per-clip source shift, clamped to each clip's live trim headroom (nested
        // tail room, not stale trimEndFrame) so rounding through speed never drives a
        // trim negative. Slow-motion clips can round a non-zero delta to zero here.
        func appliedSourceDelta(for c: Clip) -> Int {
            let sourceDelta = Int((Double(delta) * c.speed).rounded())
            return max(-effectiveTrimEnd(for: c), min(c.trimStartFrame, sourceDelta))
        }
        guard targets.contains(where: { appliedSourceDelta(for: $0) != 0 }) else { return }

        mutateClips(ids: Set(targets.map(\.id)),
                    actionName: targets.count == 1 ? "Slip Clip" : "Slip Clips") { c in
            let applied = appliedSourceDelta(for: c)
            c.trimStartFrame -= applied
            c.trimEndFrame += applied
        }
    }

    func trimValues(for clip: Clip, edge: TrimEdge, delta: Int) -> (trimStart: Int, trimEnd: Int) {
        let sourceDelta = Int((Double(delta) * clip.speed).rounded())
        // Image/Text clips have no source-material bound, so their trim fields can go negative
        let unbounded = clip.mediaType == .image || clip.mediaType == .text
        switch edge {
        case .left:
            let newStart = clip.trimStartFrame + sourceDelta
            return (unbounded ? newStart : max(0, newStart), clip.trimEndFrame)
        case .right:
            let newEnd = clip.trimEndFrame - sourceDelta
            return (clip.trimStartFrame, unbounded ? newEnd : max(0, newEnd))
        }
    }

    // MARK: - Track-zone routing for drops

    /// Index of the topmost video/image track, or nil if none exist.
    var topVisualTrackIndex: Int? {
        let z = zones
        return z.videoTrackCount > 0 ? 0 : nil
    }

    /// First audio track with no overlap at [startFrame, startFrame+duration), else nil.
    func availableAudioTrackIndex(startFrame: Int, duration: Int) -> Int? {
        let z = zones
        for i in z.firstAudioIndex..<z.trackCount {
            let track = timeline.tracks[i]
            let conflicts = track.clips.contains { c in
                !(c.endFrame <= startFrame || c.startFrame >= startFrame + duration)
            }
            if !conflicts { return i }
        }
        return nil
    }

    /// Where the visual half of a drop lands. Cursor in the audio zone mirrors
    /// around the divider so moving the cursor down there pushes the ghost up.
    func resolveVisualDropTarget(cursor: TrackDropTarget) -> TrackDropTarget {
        let z = zones

        if z.trackCount == 0 { return .newTrackAt(0) }

        switch cursor {
        case .existingTrack(let idx):
            guard timeline.tracks.indices.contains(idx) else { return .newTrackAt(0) }
            if timeline.tracks[idx].type != .audio {
                return .existingTrack(idx)
            }
            let distance = idx - z.firstAudioIndex
            let mirrored = z.firstAudioIndex - 1 - distance
            if (0..<z.firstAudioIndex).contains(mirrored) {
                return .existingTrack(mirrored)
            }
            if let v = topVisualTrackIndex { return .existingTrack(v) }
            return .newTrackAt(0)
        case .newTrackAt(let insertIdx):
            if insertIdx <= z.firstAudioIndex {
                return .newTrackAt(insertIdx)
            }
            let distance = insertIdx - z.firstAudioIndex
            return .newTrackAt(max(0, z.firstAudioIndex - distance))
        }
    }

    /// Where the audio half of a drop lands. Always route to the cursor-indicated track (audio itself or its mirror across the divider), even if there's content there.
    func resolveAudioDropTarget(cursor: TrackDropTarget) -> TrackDropTarget {
        let z = zones

        if z.trackCount == 0 { return .newTrackAt(1) }

        // newTrackAt cursor: compute the clamped insertion index directly.
        if case .newTrackAt(let insertIdx) = cursor {
            if insertIdx > z.firstAudioIndex {
                return .newTrackAt(insertIdx)
            }
            let distance = z.firstAudioIndex - insertIdx
            let clamped = min(distance, z.audioTrackCount)
            return .newTrackAt(z.firstAudioIndex + clamped)
        }

        if let idx = preferredAudioTrack(cursor: cursor) {
            return .existingTrack(idx)
        }
        // No audio tracks exist yet — create one at the bottom.
        return .newTrackAt(z.trackCount)
    }

    /// The audio track the cursor points at: the track itself if audio, else
    /// the mirrored audio track across the zone divider (V1 ↔ A1, V2 ↔ A2).
    private func preferredAudioTrack(cursor: TrackDropTarget) -> Int? {
        guard case .existingTrack(let idx) = cursor,
              timeline.tracks.indices.contains(idx) else { return nil }
        let z = zones
        guard z.audioTrackCount > 0 else { return nil }
        if timeline.tracks[idx].type == .audio { return idx }
        let distanceFromDivider = z.firstAudioIndex - 1 - idx
        let mirrored = z.firstAudioIndex + distanceFromDivider
        return (z.firstAudioIndex..<z.trackCount).contains(mirrored) ? mirrored : z.firstAudioIndex
    }

    /// Bump an audio target by +1 when a preceding visual insertion lands at-or-before it, so the resolved (current-state) index still points at the right slot post-insertion.
    func shiftAfterVisualInsertion(audio: TrackDropTarget, visual: TrackDropTarget) -> TrackDropTarget {
        guard case .newTrackAt(let visualInsertIdx) = visual else { return audio }
        switch audio {
        case .existingTrack(let idx):
            return idx >= visualInsertIdx ? .existingTrack(idx + 1) : audio
        case .newTrackAt(let idx):
            return idx >= visualInsertIdx ? .newTrackAt(idx + 1) : audio
        }
    }

    // MARK: - DropPlan

    /// Resolved drop target for a set of assets
    struct DropPlan {
        let placements: [Placement]
        let visualTarget: TrackDropTarget?
        let audioTarget: TrackDropTarget?

        var visualAssets: [MediaAsset] {
            placements.filter(\.hasVisual).map(\.asset)
        }

        var audioOnlyAssets: [MediaAsset] {
            placements.filter { !$0.hasVisual && $0.hasAudio }.map(\.asset)
        }

        var visualDurationFrames: Int {
            placements.filter(\.hasVisual).reduce(0) { $0 + $1.durationFrames }
        }

        var audioOnlyDurationFrames: Int {
            placements.filter { !$0.hasVisual && $0.hasAudio }.reduce(0) { $0 + $1.durationFrames }
        }

        struct Placement {
            let asset: MediaAsset
            let startFrame: Int
            let durationFrames: Int
            let hasVisual: Bool
            let hasAudio: Bool
        }
    }

    /// Compute the ghost+commit plan for dropping `assets` at `atFrame` with the cursor over `cursor`.
    func resolveDropPlan(cursor: TrackDropTarget, assets: [MediaAsset], atFrame: Int, segments: [String: ClosedRange<Double>] = [:]) -> DropPlan {
        var placements: [DropPlan.Placement] = []
        var c = atFrame
        for asset in assets {
            let dur = clipDurationFrames(for: asset, segment: segments[asset.id])
            let hasVisual = asset.type.isVisual
            let hasAudio = asset.type == .audio || (asset.type == .video && asset.hasAudio)
            placements.append(.init(
                asset: asset, startFrame: c, durationFrames: dur,
                hasVisual: hasVisual, hasAudio: hasAudio
            ))
            c += dur
        }
        let hasAnyVisual = placements.contains(where: \.hasVisual)
        let hasAnyAudio = placements.contains(where: \.hasAudio)
        let visualTarget = hasAnyVisual ? resolveVisualDropTarget(cursor: cursor) : nil
        let audioTarget = hasAnyAudio ? resolveAudioDropTarget(cursor: cursor) : nil
        return DropPlan(placements: placements, visualTarget: visualTarget, audioTarget: audioTarget)
    }

    /// Shared placement for media dropped on the timeline (panel assets and Finder files).
    func placeDroppedAssets(
        _ assets: [MediaAsset],
        cursor: TrackDropTarget,
        atFrame: Int,
        segments: [String: ClosedRange<Double>] = [:],
        ripple: Bool
    ) {
        undo.perform("Add Clips") {
            let plan = resolveDropPlan(cursor: cursor, assets: assets, atFrame: atFrame, segments: segments)
            let (visualIdx, audioIdx) = materialize(plan: plan)

            @MainActor func insert(_ assets: [MediaAsset], trackIndex: Int, linkedAudio: Int?) {
                if ripple {
                    rippleInsertClips(assets: assets, trackIndex: trackIndex, atFrame: atFrame, segments: segments)
                } else {
                    addClips(assets: assets, trackIndex: trackIndex, startFrame: atFrame, linkedAudioTrackIndex: linkedAudio, segments: segments)
                }
            }
            let visualAssets = plan.visualAssets
            if !visualAssets.isEmpty, let vIdx = visualIdx {
                insert(visualAssets, trackIndex: vIdx, linkedAudio: audioIdx)
            }
            let audioOnlyAssets = plan.audioOnlyAssets
            if !audioOnlyAssets.isEmpty, let aIdx = audioIdx {
                insert(audioOnlyAssets, trackIndex: aIdx, linkedAudio: nil)
            }
        }
    }

    func materialize(plan: DropPlan) -> (visual: Int?, audio: Int?) {
        let visualIdx = plan.visualTarget.map { materializeTrackIndex(target: $0, type: .video) }
        let audioIdx = audioTargetAfterVisualInsertion(plan: plan).map { materializeTrackIndex(target: $0, type: .audio) }
        return (visualIdx, audioIdx)
    }

    func audioTargetAfterVisualInsertion(plan: DropPlan) -> TrackDropTarget? {
        plan.audioTarget.map { audio in
            plan.visualTarget.map { shiftAfterVisualInsertion(audio: audio, visual: $0) } ?? audio
        }
    }

    /// Resolve a `TrackDropTarget` into a concrete track index, creating a new track if needed.
    func materializeTrackIndex(target: TrackDropTarget, type: ClipType) -> Int {
        switch target {
        case .existingTrack(let idx):
            return idx
        case .newTrackAt(let idx):
            return insertTrack(at: idx, type: type)
        }
    }

    func resolveOrCreateAudioTrack(startFrame: Int, duration: Int) -> Int {
        if let i = availableAudioTrackIndex(startFrame: startFrame, duration: duration) {
            return i
        }
        return insertTrack(at: timeline.tracks.count, type: .audio)
    }

    // MARK: - Link eligibility

    func unlinkTargets(for ids: Set<String>) -> Set<String> {
        expandToLinkGroup(ids).filter { clipFor(id: $0)?.linkGroupId != nil }
    }

    func linkTargets(for ids: Set<String>) -> Set<String>? {
        let ids = expandToLinkGroup(ids)
        guard ids.count >= 2 else { return nil }
        let clips = ids.compactMap(clipFor)
        guard clips.count == ids.count, Set(clips.map(\.mediaType)).count >= 2 else { return nil }
        let linkedGroups = clips.compactMap(\.linkGroupId)
        let groups = Set(linkedGroups)
        let ungrouped = clips.count - linkedGroups.count
        guard groups.count != 1 || ungrouped != 0 else { return nil }
        return ids
    }

    var canUnlinkSelected: Bool {
        !unlinkTargets(for: selectedClipIds).isEmpty
    }

    var canLinkSelected: Bool {
        linkTargets(for: selectedClipIds) != nil
    }
}
