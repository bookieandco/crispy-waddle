<?php

/**
 * tirreno ~ open-source security framework
 * Copyright (c) Tirreno Technologies Sàrl (https://www.tirreno.com)
 *
 * Licensed under GNU Affero General Public License version 3 of the or any later version.
 * For full copyright and license information, please see the LICENSE
 * Redistributions of files must retain the above copyright notice.
 *
 * @copyright     Copyright (c) Tirreno Technologies Sàrl (https://www.tirreno.com)
 * @license       https://opensource.org/licenses/AGPL-3.0 AGPL License
 * @link          https://www.tirreno.com Tirreno(tm)
 */

declare(strict_types=1);

return [
    'settings_timezone_form_title' => 'Time zone',
    'settings_timezone_form_title_tooltip' => 'Select the server\'s time zone.',
    'settings_timezone_form_button_save' => 'Update',

    'settings_timezone_form_field_timezone_label' => 'City',
    'settings_timezone_changeTimezone_success_message' => 'Time zone has been successfully updated.',
];
