﻿open System
open Aardvark.Base
open Aardvark.Application
open Aardvark.Application.Slim
open Aardvark.UI
open Aardvark.UI.Suave
open Aardium
open VirtualTreeExample
open VirtualTree.Utilities
open FSharp.Data.Adaptive

[<EntryPoint; STAThread>]
let main argv =

    //let children =
    //    HashMap.ofList [
    //        1, [2; 3]
    //        2, [4; 5]
    //        4, [8; 9; 10]
    //        9, [6; 7]
    //    ]

    //let getChildren (n : int) =
    //    match children.TryFindV n with
    //    | ValueSome c -> c
    //    | _ -> []

    //let tree = FlatTree.ofHierarchy getChildren 1
    //Log.line "%A" tree
    //Log.line "Count: %A" (FlatTree.count tree)
    //Log.line "Path from 10: %A" (tree |> FlatTree.rootPath 10)
    //Log.line "Parent of 10: %A" (tree |> FlatTree.parent 10)

    //let children =
    //    HashMap.ofList [
    //        11, [12; 13; 15]
    //        13, [14]
    //        15, [16]
    //    ]

    //let getChildren (n : int) =
    //    match children.TryFindV n with
    //    | ValueSome c -> c
    //    | _ -> []

    //let repl =
    //    FlatTree.ofHierarchy getChildren 11
    //    |> FlatTree.delete 15

    //Log.line "\n\nReplace 3 with %A" repl
    //let tree = tree |> FlatTree.replace 3 repl

    //Log.line "%A" tree
    //Log.line "Count: %A" (FlatTree.count tree)
    //Log.line "Path from 14: %A" (tree |> FlatTree.rootPath 14)
    //Log.line "Parent of 13: %A" (tree |> FlatTree.parent 13)

    //Log.line "Insert 42 as child of 9"
    //let tree = tree |> FlatTree.insert 9 42

    //Log.line "%A" tree
    //Log.line "Count: %A" (FlatTree.count tree)
    //Log.line "Path from 42: %A" (tree |> FlatTree.rootPath 42)
    //Log.line "Path from 10: %A" (tree |> FlatTree.rootPath 10)
    //Log.line "Path from 5: %A" (tree |> FlatTree.rootPath 5)

    //Log.line "Insert 43 as child of 1"
    //let tree = tree |> FlatTree.insert 1 43

    //Log.line "%A" tree
    //Log.line "Path from 43: %A" (tree |> FlatTree.rootPath 43)
    //Log.line "Descendants of 4: %A" (tree |> FlatTree.descendantCount 4)

    //Log.line "Insert 44 as child of 43"
    //let tree = tree |> FlatTree.insert 43 44

    //Log.line "%A" tree
    //Log.line "Path from 44: %A" (tree |> FlatTree.rootPath 44)

    //Environment.Exit 0

    Aardvark.Init()
    Aardium.Init()

    use app = new OpenGlApplication()
    use mapp = App.app |> App.start

    Server.startLocalhost 4321 mapp.CancellationToken [
        MutableApp.toWebPart' app.Runtime false mapp
        WebPart.ofAssembly <| typeof<Primitives.EmbeddedResources>.Assembly
        WebPart.ofAssembly <| Reflection.Assembly.GetEntryAssembly()
    ] |> ignore

    Aardium.run {
        url "http://localhost:4321/"
        width 1024
        height 768
#if DEBUG
        debug true
        log (fun msg -> Report.Line(2, $"[Aardium] {msg}"))
#else
        debug false
#endif
    }

    0