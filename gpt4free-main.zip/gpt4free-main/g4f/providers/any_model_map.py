audio_models = ['openai-audio', 'openai-audio-large', 'gpt-audio-mini', 'gpt-audio-mini-2025-12-15', 'gpt-4o-mini-audio-preview', 'gpt-4o-mini-audio-preview-2024-12-17', 'gpt-audio', 'gpt-audio-1.5', 'gpt-audio-2025-12-15']
image_models = ['dall-e-3', 'gpt-image', 'sdxl-turbo', 'sd-3.5-large', 'flux', 'flux-pro', 'flux-kontext', 'black-forest-labs/FLUX-2-klein-4b', 'black-forest-labs/FLUX-2-klein-9b', 'flux-2-klein-4b', 'flux-2-klein-9b', 'flux-dev', 'sd-3.5-large', 'flux', 'flux-kontext-dev', 'flux-dev', 'sd-3.5-large', 'flux', 'flux-kontext-dev']
vision_models = []
video_models = ['video']
model_map = {
  "default": {
    "OperaAria": "",
    "DeepInfra": "",
    "CopilotApp": "",
    "Qwen": "",
    "Together": "",
    "Ollama": "",
    "OpenaiChat": "",
    "GLM": "",
    "Pollinations": "",
    "TeachAnything": "",
    "WeWordle": ""
  },
  "gpt-4": {
    "CopilotApp": "chat",
    "Yqcloud": "gpt-4",
    "WeWordle": "gpt-4",
    "OpenaiChat": "gpt-4",
    "Airforce": "gpt-4",
    "Copilot": "Copilot",
    "CopilotAccount": "Copilot",
    "CopilotSession": "Copilot",
    "GithubCopilot": "gpt-4",
    "OpenRouter": "openai/gpt-4",
    "Puter": "openrouter:openai/gpt-4"
  },
  "gpt-4o": {
    "CopilotApp": "chat",
    "OpenaiChat": "gpt-4o",
    "Copilot": "Copilot",
    "CopilotAccount": "Copilot",
    "CopilotSession": "Copilot",
    "GithubCopilot": "gpt-4o",
    "OpenRouter": "openai/gpt-4o-2024-05-13",
    "Puter": "openrouter:openai/gpt-4o-2024-11-20",
    "WeWordle": "gpt-4o"
  },
  "gpt-4o-mini": {
    "OpenaiChat": "gpt-4o-mini",
    "Airforce": "gpt-4o-mini",
    "GithubCopilot": "gpt-4o-mini",
    "OpenRouter": "openai/gpt-4o-mini-2024-07-18",
    "Puter": "openrouter:openai/gpt-4o-mini-2024-07-18",
    "WeWordle": "gpt-4o-mini"
  },
  "gpt-4o-mini-tts": {
    "OpenAIFM": "coral",
    "Airforce": "gpt-4o-mini-tts"
  },
  "o1": {
    "OpenaiAccount": "o1",
    "Airforce": "o1",
    "Copilot": "Think Deeper",
    "CopilotAccount": "Think Deeper",
    "CopilotApp": "reasoning",
    "CopilotSession": "Think Deeper",
    "OpenRouter": "openai/o1",
    "OpenaiChat": "o1",
    "Puter": "openai:openai/o1"
  },
  "o1-mini": {
    "OpenaiAccount": "o1-mini",
    "OpenaiChat": "o1-mini",
    "Puter": "openai:openai/o1-mini"
  },
  "o3-mini": {
    "OpenaiChat": "o3-mini",
    "Airforce": "o3-mini-2025-01-31",
    "CopilotApp": "reasoning",
    "LMArena": "o3-mini",
    "OpenRouter": "openai/o3-mini",
    "Puter": "openai:openai/o3-mini"
  },
  "o3-mini-high": {
    "OpenaiAccount": "o3-mini-high",
    "OpenRouter": "openai/o3-mini-high",
    "OpenaiChat": "o3-mini-high",
    "Puter": "openrouter:openai/o3-mini-high"
  },
  "o4-mini": {
    "OpenaiChat": "o4-mini",
    "Airforce": "o4-mini",
    "LMArena": "o4-mini-2025-04-16",
    "OpenRouter": "openai/o4-mini",
    "Puter": "openai:openai/o4-mini"
  },
  "o4-mini-high": {
    "OpenaiChat": "o4-mini-high",
    "OpenRouter": "openai/o4-mini-high",
    "Puter": "openrouter:openai/o4-mini-high"
  },
  "gpt-4.1": {
    "OpenaiChat": "gpt-4-1",
    "Airforce": "gpt-4.1",
    "GithubCopilot": "gpt-4.1",
    "LMArena": "gpt-4.1-2025-04-14",
    "OpenRouter": "openai/gpt-4.1",
    "Puter": "openai:openai/gpt-4.1"
  },
  "gpt-4.1-mini": {
    "OpenaiChat": "gpt-4-1-mini",
    "LMArena": "gpt-4.1-mini-2025-04-14",
    "OpenRouter": "openai/gpt-4.1-mini",
    "Puter": "openai:openai/gpt-4.1-mini"
  },
  "gpt-4.1-nano": {
    "Pollinations": "openai-fast",
    "Airforce": "gpt-4.1-nano",
    "OpenRouter": "openai/gpt-4.1-nano",
    "Puter": "openai:openai/gpt-4.1-nano"
  },
  "gpt-4.5": {
    "OpenaiChat": "gpt-4-5",
    "Puter": "openai:openai/gpt-4.5-preview"
  },
  "gpt-oss-120b": {
    "Together": "openai/gpt-oss-120b",
    "OpenRouter": "openai/gpt-oss-120b",
    "Groq": "openai/gpt-oss-120b",
    "HuggingFace": "openai/gpt-oss-120b",
    "Airforce": "gpt-oss-120b",
    "Cloudflare": "@cf/openai/gpt-oss-120b",
    "HuggingChat": "openai/gpt-oss-120b",
    "LMArena": "gpt-oss-120b",
    "Nvidia": "openai/gpt-oss-120b",
    "Ollama": "gpt-oss:120b",
    "Pollinations": "Catniti/gpt-oss-120b",
    "Puter": "togetherai:openai/gpt-oss-120b"
  },
  "dall-e-3": {
    "OpenaiAccount": "dall-e-3",
    "MicrosoftDesigner": "dall-e-3",
    "BingCreateImages": "dall-e-3",
    "CopilotAccount": "Copilot",
    "OpenaiChat": "gpt-image"
  },
  "gpt-image": {
    "PollinationsImage": "gpt-image",
    "OpenaiChat": "gpt-image",
    "Pollinations": "gptimage"
  },
  "meta-ai": {
    "MetaAI": "meta-ai",
    "MetaAIAccount": "meta-ai"
  },
  "llama-2-70b": {
    "Together": "llama-2-70b",
    "Nvidia": "meta/llama2-70b",
    "Puter": "openrouter:meta-llama/llama-2-70b-chat"
  },
  "llama-3-8b": {
    "Together": "llama-3-8b",
    "Cloudflare": "@hf/meta-llama/meta-llama-3-8b-instruct",
    "PerplexityApi": "llama-3-8b-instruct",
    "Puter": "openrouter:meta-llama/llama-3-8b-instruct"
  },
  "llama-3-70b": {
    "Together": "llama-3-70b",
    "PerplexityApi": "llama-3-70b-instruct",
    "Puter": "openrouter:meta-llama/llama-3-70b-instruct",
    "Replicate": "meta/meta-llama-3-70b-instruct"
  },
  "llama-3.1-8b": {
    "Together": "llama-3.1-8b",
    "HuggingFace": "meta-llama/Llama-3.1-8B-Instruct",
    "Cerebras": "llama3.1-8b",
    "Cloudflare": "@cf/meta/llama-3.1-8b-instruct-fp8",
    "GlhfChat": "hf:meta-llama/Llama-3.1-8B-Instruct",
    "HuggingChat": "meta-llama/Llama-3.1-8B-Instruct",
    "Nvidia": "meta/llama-3.1-8b-instruct",
    "OpenRouter": "meta-llama/llama-3.1-8b-instruct",
    "Puter": [
      "openrouter:meta-llama/llama-3.1-8b-instruct:free",
      "openrouter:meta-llama/llama-3.1-8b-instruct"
    ]
  },
  "llama-3.1-70b": {
    "Together": "llama-3.1-70b",
    "Cerebras": "llama3.1-70b",
    "GlhfChat": "hf:meta-llama/Llama-3.1-70B-Instruct",
    "Nvidia": "meta/llama-3.1-70b-instruct",
    "OpenRouter": "meta-llama/llama-3.1-70b-instruct",
    "Puter": "openrouter:meta-llama/llama-3.1-70b-instruct"
  },
  "llama-3.1-405b": {
    "Together": "llama-3.1-405b",
    "GlhfChat": "hf:meta-llama/Llama-3.1-405B-Instruct",
    "Puter": [
      "openrouter:meta-llama/llama-3.1-405b:free",
      "openrouter:meta-llama/llama-3.1-405b",
      "openrouter:meta-llama/llama-3.1-405b-instruct"
    ]
  },
  "llama-3.2-3b": {
    "Together": "llama-3.2-3b",
    "Cloudflare": "@cf/meta/llama-3.2-3b-instruct",
    "GlhfChat": "hf:meta-llama/Llama-3.2-3B-Instruct",
    "Nvidia": "meta/llama-3.2-3b-instruct",
    "OpenRouter": "meta-llama/llama-3.2-3b-instruct",
    "Puter": [
      "openrouter:meta-llama/llama-3.2-3b-instruct:free",
      "openrouter:meta-llama/llama-3.2-3b-instruct"
    ]
  },
  "llama-3.2-90b": {
    "Together": "llama-3.2-90b",
    "Puter": "openrouter:meta-llama/llama-3.2-90b-vision-instruct"
  },
  "llama-4-scout": {
    "Pollinations": "llama-scout",
    "Together": "llama-4-scout",
    "Cloudflare": "@cf/meta/llama-4-scout-17b-16e-instruct",
    "OpenRouter": "meta-llama/llama-4-scout",
    "Puter": [
      "openrouter:meta-llama/llama-4-scout:free",
      "openrouter:meta-llama/llama-4-scout"
    ]
  },
  "llama-4-maverick": {
    "Together": "llama-4-maverick",
    "OpenRouter": "meta-llama/llama-4-maverick",
    "Pollinations": "llama-maverick",
    "Puter": [
      "openrouter:meta-llama/llama-4-maverick:free",
      "openrouter:meta-llama/llama-4-maverick"
    ]
  },
  "mistral-7b": {
    "Together": "mistral-7b"
  },
  "mixtral-8x7b": {
    "Together": "mixtral-8x7b",
    "Groq": "mixtral-8x7b-32768"
  },
  "mistral-small-24b": {
    "Together": "mistral-small-24b"
  },
  "mistral-small-3.1-24b": {
    "Pollinations": "mistral-small",
    "Airforce": "mistral-small-3.1-24b-instruct",
    "Cloudflare": "@cf/mistralai/mistral-small-3.1-24b-instruct",
    "OpenRouter": "mistralai/mistral-small-3.1-24b-instruct",
    "Puter": "openrouter:mistralai/mistral-small-3.1-24b-instruct"
  },
  "hermes-2-dpo": {
    "Together": "hermes-2-dpo",
    "Puter": "openrouter:nousresearch/nous-hermes-2-mixtral-8x7b-dpo"
  },
  "gemini-2.5-flash": {
    "Gemini": "gemini-3.5-flash",
    "GeminiPro": "gemini-2.5-flash",
    "GeminiCLI": "gemini-2.5-flash",
    "Antigravity": "gemini-2.5-flash",
    "Airforce": "gemini-2.5-flash",
    "LMArena": "gemini-2.5-flash",
    "OpenRouter": "google/gemini-2.5-flash",
    "Puter": "openrouter:google/gemini-2.5-flash-preview"
  },
  "gemini-2.5-pro": {
    "Gemini": "gemini-3.1-pro",
    "GeminiPro": "gemini-2.5-pro",
    "GeminiCLI": "gemini-2.5-pro",
    "Antigravity": "gemini-2.5-pro",
    "Airforce": "gemini-2.5-pro",
    "GithubCopilot": "gemini-2.5-pro",
    "LMArena": "gemini-2.5-pro",
    "OpenRouter": "google/gemini-2.5-pro-preview-05-06",
    "Pollinations": "gemini-large",
    "Puter": [
      "openrouter:google/gemini-2.5-pro-preview",
      "openrouter:google/gemini-2.5-pro-exp-03-25"
    ]
  },
  "gemini-3-pro-preview": {
    "GeminiCLI": "gemini-3-pro-preview",
    "GeminiPro": "gemini-3-pro-preview"
  },
  "gemini-3.1-pro": {
    "Gemini": "gemini-3.1-pro",
    "Airforce": "gemini-3.1-pro",
    "GeminiPro": "gemini-3.1-pro",
    "GithubCopilot": "gemini-3.1-pro-preview",
    "LMArena": "gemini-3.1-pro",
    "OpenRouter": "google/gemini-3.1-pro-preview",
    "Pollinations": "gemini-large",
    "Puter": "openrouter:google/gemini-3.1-pro-preview"
  },
  "gemini-3.1-flash-lite": {
    "Gemini": "gemini-flash-lite",
    "Antigravity": "gemini-3.1-flash-lite",
    "Airforce": "gemini-3.1-flash-lite",
    "GeminiCLI": "gemini-3.1-flash-lite",
    "GeminiPro": "gemini-3.1-flash-lite",
    "LMArena": "gemini-3.1-flash-lite",
    "OpenRouter": "google/gemini-3.1-flash-lite-preview",
    "Pollinations": "gemini-flash-lite-3.5",
    "Puter": "openrouter:google/gemini-3.1-flash-lite-preview"
  },
  "gemini-3.5-flash": {
    "Gemini": "gemini-3.5-flash",
    "Airforce": "gemini-3.5-flash",
    "GeminiPro": "gemini-3.5-flash",
    "GithubCopilot": "gemini-3.5-flash",
    "LMArena": "gemini-3.5-flash",
    "OpenRouter": "google/gemini-3.5-flash",
    "Pollinations": "gemini",
    "Puter": "openrouter:google/gemini-3.5-flash"
  },
  "gemini-3.5-flash-thinking": {
    "Gemini": "gemini-3.5-flash-thinking",
    "GeminiPro": "gemini-3.5-flash-thinking"
  },
  "gemini-auto": {
    "Gemini": "gemini-auto",
    "GeminiPro": "gemini-auto"
  },
  "gemini-3.5-flash-thinking-lite": {
    "Gemini": "gemini-3.5-flash-thinking-lite",
    "GeminiPro": "gemini-3.5-flash-thinking-lite"
  },
  "gemini-flash-lite": {
    "Gemini": "gemini-flash-lite",
    "GeminiPro": "gemini-flash-lite",
    "Pollinations": "gemini-flash-lite-3.5"
  },
  "command-r7b": {
    "HuggingSpace": [
      "command-r7b-12-2024",
      "command-r7b-arabic-02-2025"
    ],
    "CohereForAI_C4AI_Command": [
      "command-r7b-12-2024",
      "command-r7b-arabic-02-2025"
    ],
    "Puter": "openrouter:cohere/command-r7b-12-2024"
  },
  "command-a": {
    "HuggingSpace": "command-a-03-2025",
    "CohereForAI_C4AI_Command": "command-a-03-2025",
    "OpenRouter": "cohere/command-a",
    "Puter": "openrouter:cohere/command-a"
  },
  "qwen-2.5-coder-32b": {
    "Together": "qwen-2.5-coder-32b",
    "HuggingChat": "Qwen/Qwen2.5-Coder-32B-Instruct",
    "HuggingFace": "Qwen/Qwen2.5-Coder-32B-Instruct",
    "Cloudflare": "@cf/qwen/qwen2.5-coder-32b-instruct",
    "GlhfChat": "hf:Qwen/Qwen2.5-Coder-32B-Instruct",
    "OpenRouter": "qwen/qwen-2.5-coder-32b-instruct",
    "Pollinations": "qwen-3-coder",
    "Puter": [
      "openrouter:qwen/qwen-2.5-coder-32b-instruct:free",
      "openrouter:qwen/qwen-2.5-coder-32b-instruct"
    ]
  },
  "qwen-2.5-vl-72b": {
    "Together": "qwen-2.5-vl-72b",
    "HuggingFace": "Qwen/Qwen2.5-VL-72B-Instruct",
    "HuggingChat": "Qwen/Qwen2.5-VL-72B-Instruct",
    "OpenRouter": "qwen/qwen2.5-vl-72b-instruct",
    "Puter": [
      "openrouter:qwen/qwen2.5-vl-72b-instruct:free",
      "openrouter:qwen/qwen2.5-vl-72b-instruct"
    ]
  },
  "qwen-3-235b": {
    "Together": "qwen-3-235b",
    "Puter": [
      "openrouter:qwen/qwen3-235b-a22b:free",
      "openrouter:qwen/qwen3-235b-a22b"
    ]
  },
  "qwen-3-32b": {
    "Together": "qwen-3-32b",
    "HuggingFace": "Qwen/Qwen3-32B",
    "Airforce": "qwen3-32b",
    "HuggingChat": "Qwen/Qwen3-32B",
    "OpenRouter": "qwen/qwen3-32b",
    "Puter": [
      "openrouter:qwen/qwen3-32b:free",
      "openrouter:qwen/qwen3-32b"
    ]
  },
  "qwq-32b": {
    "Together": "qwq-32b",
    "HuggingChat": "qwq-32b",
    "Cloudflare": "@cf/qwen/qwq-32b",
    "GlhfChat": "hf:Qwen/QwQ-32B-Preview",
    "LMArena": "qwq-32b",
    "Puter": [
      "openrouter:qwen/qwq-32b-preview",
      "openrouter:qwen/qwq-32b:free",
      "openrouter:qwen/qwq-32b"
    ]
  },
  "deepseek-v3": {
    "Together": "deepseek-v3",
    "Puter": "openrouter:deepseek/deepseek-v3-base:free"
  },
  "deepseek-r1": {
    "Pollinations": "deepseek-reasoning",
    "Together": "deepseek-r1",
    "HuggingFace": "deepseek-ai/DeepSeek-R1",
    "Airforce": "deepseek-r1",
    "Cerebras": "deepseek-r1-distill-llama-70b",
    "DeepSeek": "deepseek-r1",
    "HuggingChat": "deepseek-ai/DeepSeek-R1",
    "OpenRouter": "deepseek/deepseek-r1",
    "Puter": [
      "deepseek-reasoner",
      "openrouter:deepseek/deepseek-r1:free",
      "openrouter:deepseek/deepseek-r1"
    ],
    "WeWordle": "v3"
  },
  "deepseek-r1-distill-llama-70b": {
    "Together": "deepseek-r1-distill-llama-70b",
    "HuggingFace": "deepseek-ai/DeepSeek-R1-Distill-Llama-70B",
    "Cerebras": "deepseek-r1-distill-llama-70b",
    "HuggingChat": "deepseek-ai/DeepSeek-R1-Distill-Llama-70B",
    "OpenRouter": "deepseek/deepseek-r1-distill-llama-70b",
    "Puter": [
      "openrouter:deepseek/deepseek-r1-distill-llama-70b:free",
      "openrouter:deepseek/deepseek-r1-distill-llama-70b"
    ]
  },
  "deepseek-r1-distill-qwen-1.5b": {
    "Together": "deepseek-r1-distill-qwen-1.5b",
    "Puter": "openrouter:deepseek/deepseek-r1-distill-qwen-1.5b"
  },
  "deepseek-r1-distill-qwen-14b": {
    "Together": "deepseek-r1-distill-qwen-14b",
    "HuggingFace": "deepseek-ai/DeepSeek-R1-Distill-Qwen-14B",
    "HuggingChat": "deepseek-ai/DeepSeek-R1-Distill-Qwen-14B",
    "Puter": [
      "openrouter:deepseek/deepseek-r1-distill-qwen-14b:free",
      "openrouter:deepseek/deepseek-r1-distill-qwen-14b"
    ]
  },
  "grok-2": {
    "Grok": "grok-2",
    "Puter": [
      "openrouter:x-ai/grok-2-vision-1212",
      "openrouter:x-ai/grok-2-1212"
    ]
  },
  "grok-3": {
    "Grok": "grok-3",
    "Airforce": "grok-3",
    "Puter": "x-ai:x-ai/grok-3"
  },
  "grok-3-r1": {
    "Grok": "grok-3-reasoning"
  },
  "kimi-k2": {
    "Groq": "moonshotai/Kimi-K2-Instruct",
    "HuggingFace": "moonshotai/Kimi-K2-Instruct",
    "Airforce": "kimi-k2",
    "HuggingChat": "moonshotai/Kimi-K2-Instruct",
    "OpenRouter": "moonshotai/kimi-k2",
    "Puter": "openrouter:moonshotai/kimi-k2"
  },
  "sonar": {
    "Puter": "openrouter:perplexity/sonar",
    "OpenRouter": "perplexity/sonar",
    "Pollinations": "perplexity-fast"
  },
  "sonar-pro": {
    "Puter": "openrouter:perplexity/sonar-pro",
    "OpenRouter": "perplexity/sonar-pro",
    "Pollinations": "perplexity"
  },
  "sonar-reasoning": {
    "Puter": "openrouter:perplexity/sonar-reasoning",
    "Pollinations": "perplexity-reasoning"
  },
  "sonar-reasoning-pro": {
    "Puter": "openrouter:perplexity/sonar-reasoning-pro",
    "OpenRouter": "perplexity/sonar-reasoning-pro",
    "Pollinations": "perplexity-reasoning"
  },
  "r1-1776": {
    "Together": "r1-1776",
    "Puter": "openrouter:perplexity/r1-1776",
    "Perplexity": "r1-1776"
  },
  "nemotron-70b": {
    "Together": "nemotron-70b",
    "HuggingChat": "nemotron-70b",
    "Puter": "openrouter:nvidia/llama-3.1-nemotron-70b-instruct"
  },
  "aria": {
    "OperaAria": "aria"
  },
  "sdxl-turbo": {
    "HuggingFaceMedia": "stabilityai/sdxl-turbo",
    "PollinationsImage": "sdxl-turbo",
    "Pollinations": "turbo"
  },
  "sd-3.5-large": {
    "HuggingFaceMedia": "stabilityai/stable-diffusion-3.5-large",
    "HuggingSpace": "stabilityai-stable-diffusion-3-5-large",
    "StabilityAI_SD35Large": "stabilityai-stable-diffusion-3-5-large"
  },
  "flux": {
    "HuggingFaceMedia": "black-forest-labs/FLUX.1-dev",
    "PollinationsImage": "flux",
    "Together": "flux",
    "HuggingSpace": "black-forest-labs-flux-1-dev",
    "BlackForestLabs_Flux1Dev": "black-forest-labs-flux-1-dev",
    "Pollinations": "flux"
  },
  "flux-pro": {
    "PollinationsImage": "flux-pro",
    "Together": "flux-pro",
    "Pollinations": "flux"
  },
  "flux-kontext": {
    "Pollinations": "kontext",
    "Together": "flux-kontext"
  },
  "glm-5.2": {
    "DeepInfra": "zai-org/GLM-5.2",
    "HuggingFace": "zai-org/GLM-5.2-FP8",
    "Airforce": "glm-5.2",
    "Cloudflare": "@cf/zai-org/glm-5.2",
    "GLM": "GLM-5.2",
    "HuggingChat": "zai-org/GLM-5.2-FP8",
    "Nvidia": "z-ai/glm-5.2",
    "Ollama": "glm-5.2",
    "OpenRouter": "z-ai/glm-5.2",
    "Pollinations": "glm",
    "Puter": "z-ai:z-ai/glm-5.2"
  },
  "kimi-k2.7-code": {
    "DeepInfra": "moonshotai/Kimi-K2.7-Code",
    "HuggingFace": "moonshotai/Kimi-K2.7-Code",
    "Airforce": "kimi-k2.7-code",
    "Cloudflare": "@cf/moonshotai/kimi-k2.7-code",
    "GithubCopilot": "kimi-k2.7-code",
    "HuggingChat": "moonshotai/Kimi-K2.7-Code",
    "LMArena": "kimi-k2.7-code",
    "Ollama": "kimi-k2.7-code",
    "OpenRouter": "moonshotai/kimi-k2.7-code",
    "Pollinations": "kimi-code",
    "Puter": "togetherai:moonshotai/kimi-k2.7-code"
  },
  "nvidia-nemotron-3-ultra-550b-a55b": {
    "DeepInfra": "nvidia/NVIDIA-Nemotron-3-Ultra-550B-A55B",
    "HuggingFace": "nvidia/NVIDIA-Nemotron-3-Ultra-550B-A55B-BF16",
    "HuggingChat": "nvidia/NVIDIA-Nemotron-3-Ultra-550B-A55B-BF16"
  },
  "deepseek-v4-flash": {
    "DeepInfra": "deepseek-ai/DeepSeek-V4-Flash",
    "HuggingFace": "deepseek-ai/DeepSeek-V4-Flash",
    "Airforce": "deepseek-v4-flash",
    "HuggingChat": "deepseek-ai/DeepSeek-V4-Flash",
    "LMArena": "deepseek-v4-flash",
    "Nvidia": "deepseek-ai/deepseek-v4-flash",
    "Ollama": "deepseek-v4-flash",
    "OpenRouter": "deepseek/deepseek-v4-flash",
    "Pollinations": "deepseek",
    "Puter": "deepseek:deepseek/deepseek-v4-flash"
  },
  "deepseek-v4-pro": {
    "DeepInfra": "deepseek-ai/DeepSeek-V4-Pro",
    "HuggingFace": "deepseek-ai/DeepSeek-V4-Pro",
    "Airforce": "deepseek-v4-pro",
    "HuggingChat": "deepseek-ai/DeepSeek-V4-Pro",
    "LMArena": "deepseek-v4-pro",
    "Nvidia": "deepseek-ai/deepseek-v4-pro",
    "Ollama": "deepseek-v4-pro",
    "OpenRouter": "deepseek/deepseek-v4-pro",
    "Pollinations": "deepseek-pro",
    "Puter": "deepseek:deepseek/deepseek-v4-pro"
  },
  "kimi-k2.6": {
    "DeepInfra": "moonshotai/Kimi-K2.6",
    "HuggingFace": "moonshotai/Kimi-K2.6",
    "Airforce": "kimi-k2.6",
    "Cloudflare": "@cf/moonshotai/kimi-k2.6",
    "HuggingChat": "moonshotai/Kimi-K2.6",
    "LMArena": "kimi-k2.6",
    "Nvidia": "moonshotai/kimi-k2.6",
    "Ollama": "kimi-k2.6",
    "OpenRouter": "moonshotai/kimi-k2.6",
    "Pollinations": "kimi",
    "Puter": "moonshotai:moonshotai/kimi-k2.6"
  },
  "mimo-v2.5-pro": {
    "DeepInfra": "XiaomiMiMo/MiMo-V2.5-Pro",
    "HuggingFace": "XiaomiMiMo/MiMo-V2.5-Pro",
    "Airforce": "mimo-v2.5-pro",
    "HuggingChat": "XiaomiMiMo/MiMo-V2.5-Pro",
    "LMArena": "mimo-v2.5-pro",
    "OpenRouter": "xiaomi/mimo-v2.5-pro",
    "Pollinations": "mimo-v2.5-pro",
    "Puter": "openrouter:xiaomi/mimo-v2.5-pro"
  },
  "qwen-3.6-35b-a3b": {
    "DeepInfra": "Qwen/Qwen3.6-35B-A3B",
    "HuggingFace": "Qwen/Qwen3.6-35B-A3B",
    "Airforce": "qwen3.6-35b-a3b",
    "HuggingChat": "Qwen/Qwen3.6-35B-A3B",
    "OpenRouter": "qwen/qwen3.6-35b-a3b",
    "Puter": "alibaba:qwen/qwen3.6-35b-a3b",
    "Qwen": "qwen3.6-35b-a3b"
  },
  "glm-5.1": {
    "DeepInfra": "zai-org/GLM-5.1",
    "HuggingFace": "zai-org/GLM-5.1-FP8",
    "Airforce": "glm-5.1",
    "GLM": "GLM-5.1",
    "HuggingChat": "zai-org/GLM-5.1-FP8",
    "LMArena": "glm-5.1",
    "Ollama": "glm-5.1",
    "OpenRouter": "z-ai/glm-5.1",
    "Puter": "z-ai:z-ai/glm-5.1"
  },
  "qwen-3.5-397b-a17b": {
    "DeepInfra": "Qwen/Qwen3.5-397B-A17B",
    "HuggingFace": "Qwen/Qwen3.5-397B-A17B",
    "Airforce": "qwen3.5-397b-a17b",
    "HuggingChat": "Qwen/Qwen3.5-397B-A17B",
    "LMArena": "qwen3.5-397b-a17b",
    "Nvidia": "qwen/qwen3.5-397b-a17b",
    "OpenRouter": "qwen/qwen3.5-397b-a17b",
    "Puter": "alibaba:qwen/qwen3.5-397b-a17b",
    "Qwen": "qwen3.5-397b-a17b"
  },
  "gemma-4-26b-a4b-it": {
    "DeepInfra": "google/gemma-4-26B-A4B-it",
    "HuggingFace": "google/gemma-4-26B-A4B-it",
    "Airforce": "gemma-4-26b-a4b-it",
    "Cloudflare": "@cf/google/gemma-4-26b-a4b-it",
    "GeminiPro": "gemma-4-26b-a4b-it",
    "HuggingChat": "google/gemma-4-26B-A4B-it",
    "OpenRouter": "google/gemma-4-26b-a4b-it:free",
    "Pollinations": "gemma",
    "Puter": "openrouter:google/gemma-4-26b-a4b-it:free"
  },
  "gemma-4-31b-it": {
    "DeepInfra": "google/gemma-4-31B-it",
    "HuggingFace": "google/gemma-4-31B-it",
    "GeminiPro": "gemma-4-31b-it",
    "HuggingChat": "google/gemma-4-31B-it",
    "LMArena": "gemma-4-31b-it",
    "Nvidia": "google/gemma-4-31b-it",
    "OpenRouter": "google/gemma-4-31b-it:free",
    "Pollinations": "gemma-4-31b",
    "Puter": "togetherai:google/gemma-4-31b-it"
  },
  "nvidia-nemotron-3-super-120b-a12b": {
    "DeepInfra": "nvidia/NVIDIA-Nemotron-3-Super-120B-A12B"
  },
  "glm-5": {
    "DeepInfra": "zai-org/GLM-5",
    "HuggingFace": "zai-org/GLM-5",
    "Airforce": "glm-5",
    "HuggingChat": "zai-org/GLM-5",
    "LMArena": "glm-5",
    "OpenRouter": "z-ai/glm-5",
    "Puter": "z-ai:z-ai/glm-5"
  },
  "minimax-m2.5": {
    "DeepInfra": "MiniMaxAI/MiniMax-M2.5",
    "HuggingFace": "MiniMaxAI/MiniMax-M2.5",
    "Airforce": "minimax-m2.5",
    "HuggingChat": "MiniMaxAI/MiniMax-M2.5",
    "LMArena": "minimax-m2.5",
    "Ollama": "minimax-m2.5",
    "OpenRouter": "minimax/minimax-m2.5",
    "Pollinations": "minimax-m2.7",
    "Puter": "minimax:minimax/minimax-m2.5"
  },
  "qwen-3-max": {
    "DeepInfra": "Qwen/Qwen3-Max",
    "Airforce": "qwen3-max",
    "LMArena": "qwen3-max-2025-09-26",
    "OpenRouter": "qwen/qwen3-max",
    "Puter": "alibaba:qwen/qwen3-max",
    "Qwen": "qwen3-max-2026-01-23"
  },
  "qwen-3-max-thinking": {
    "DeepInfra": "Qwen/Qwen3-Max-Thinking",
    "LMArena": "qwen3-max-thinking",
    "OpenRouter": "qwen/qwen3-max-thinking",
    "Puter": "openrouter:qwen/qwen3-max-thinking"
  },
  "kimi-k2.5": {
    "DeepInfra": "moonshotai/Kimi-K2.5",
    "HuggingFace": "moonshotai/Kimi-K2.5",
    "Airforce": "kimi-k2.5",
    "HuggingChat": "moonshotai/Kimi-K2.5",
    "LMArena": "kimi-k2.5",
    "Ollama": "kimi-k2.5",
    "OpenRouter": "moonshotai/kimi-k2.5",
    "Puter": "moonshotai:moonshotai/kimi-k2.5"
  },
  "glm-4.7-flash": {
    "DeepInfra": "zai-org/GLM-4.7-Flash",
    "HuggingFace": "zai-org/GLM-4.7-Flash",
    "Airforce": "glm-4.7-flash",
    "Cloudflare": "@cf/zai-org/glm-4.7-flash",
    "HuggingChat": "zai-org/GLM-4.7-Flash",
    "OpenRouter": "z-ai/glm-4.7-flash",
    "Pollinations": "Catniti/glm-4.7-flash",
    "Puter": "z-ai:z-ai/glm-4.7-flash"
  },
  "deepseek-v3.2": {
    "DeepInfra": "deepseek-ai/DeepSeek-V3.2",
    "HuggingFace": "deepseek-ai/DeepSeek-V3.2",
    "Airforce": "deepseek-v3.2",
    "HuggingChat": "deepseek-ai/DeepSeek-V3.2",
    "OpenRouter": "deepseek/deepseek-v3.2",
    "Pollinations": "Minor-fun/deepseek-v3.2",
    "Puter": "openrouter:deepseek/deepseek-v3.2"
  },
  "flux-2-klein-4b": {
    "DeepInfra": "black-forest-labs/FLUX-2-klein-4b"
  },
  "flux-2-klein-9b": {
    "DeepInfra": "black-forest-labs/FLUX-2-klein-9b"
  },
  "inkling": {
    "HuggingFace": "thinkingmachines/Inkling",
    "HuggingChat": "thinkingmachines/Inkling",
    "LMArena": "inkling",
    "Nvidia": "thinkingmachines/inkling",
    "OpenRouter": "thinkingmachines/inkling",
    "Puter": "togetherai:thinkingmachines/inkling"
  },
  "ternary-bonsai-27b-gguf": {
    "HuggingFace": "prism-ml/Ternary-Bonsai-27B-gguf",
    "HuggingChat": "prism-ml/Ternary-Bonsai-27B-gguf"
  },
  "qwen-3.6-27b": {
    "HuggingFace": "Qwen/Qwen3.6-27B",
    "Groq": "qwen/qwen3.6-27b",
    "HuggingChat": "Qwen/Qwen3.6-27B",
    "LMArena": "qwen3.6-27b",
    "OpenRouter": "qwen/qwen3.6-27b",
    "Puter": "alibaba:qwen/qwen3.6-27b",
    "Qwen": "qwen3.6-27b"
  },
  "hy3": {
    "HuggingFace": "tencent/Hy3",
    "HuggingChat": "tencent/Hy3",
    "LMArena": "hy3",
    "OpenRouter": "tencent/hy3-preview",
    "Puter": "openrouter:tencent/hy3-preview"
  },
  "ornith-1.0-35b": {
    "HuggingFace": "deepreinforce-ai/Ornith-1.0-35B-FP8",
    "HuggingChat": "deepreinforce-ai/Ornith-1.0-35B-FP8"
  },
  "apertus-v1.5-70b": {
    "HuggingFace": "swiss-ai/Apertus-v1.5-70B",
    "HuggingChat": "swiss-ai/Apertus-v1.5-70B"
  },
  "minimax-m3": {
    "HuggingFace": "MiniMaxAI/MiniMax-M3",
    "Airforce": "minimax-m3",
    "HuggingChat": "MiniMaxAI/MiniMax-M3",
    "LMArena": "minimax-m3",
    "MiniMax": "MiniMax-M3",
    "Nvidia": "minimaxai/minimax-m3",
    "Ollama": "minimax-m3",
    "OpenRouter": "minimax/minimax-m3",
    "Pollinations": "minimax",
    "Puter": "minimax:minimax/minimax-m3"
  },
  "apertus-v1.5-8b": {
    "HuggingFace": "swiss-ai/Apertus-v1.5-8B",
    "HuggingChat": "swiss-ai/Apertus-v1.5-8B"
  },
  "qwen-3.5-9b": {
    "HuggingFace": "Qwen/Qwen3.5-9B",
    "HuggingChat": "Qwen/Qwen3.5-9B",
    "OpenRouter": "qwen/qwen3.5-9b",
    "Puter": "togetherai:qwen/qwen3.5-9b"
  },
  "qwen-3-8b": {
    "HuggingFace": "Qwen/Qwen3-8B",
    "Airforce": "qwen3-8b",
    "HuggingChat": "Qwen/Qwen3-8B",
    "OpenRouter": "qwen/qwen3-8b",
    "Puter": [
      "openrouter:qwen/qwen3-8b:free",
      "openrouter:qwen/qwen3-8b"
    ]
  },
  "gpt-oss-20b": {
    "HuggingFace": "openai/gpt-oss-20b",
    "Airforce": "gpt-oss-20b",
    "Cloudflare": "@cf/openai/gpt-oss-20b",
    "Groq": "openai/gpt-oss-20b",
    "HuggingChat": "openai/gpt-oss-20b",
    "LMArena": "gpt-oss-20b",
    "Nvidia": "openai/gpt-oss-20b",
    "Ollama": "gpt-oss:20b",
    "OpenRouter": "openai/gpt-oss-20b:free",
    "Pollinations": "gpt-oss",
    "Puter": "togetherai:openai/gpt-oss-20b"
  },
  "qwen-3.5-27b": {
    "HuggingFace": "Qwen/Qwen3.5-27B",
    "HuggingChat": "Qwen/Qwen3.5-27B",
    "LMArena": "qwen3.5-27b",
    "OpenRouter": "qwen/qwen3.5-27b",
    "Puter": "alibaba:qwen/qwen3.5-27b",
    "Qwen": "qwen3.5-27b"
  },
  "qwen-3-coder-30b-a3b": {
    "HuggingFace": "Qwen/Qwen3-Coder-30B-A3B-Instruct",
    "Airforce": "qwen3-coder-30b-a3b",
    "HuggingChat": "Qwen/Qwen3-Coder-30B-A3B-Instruct",
    "OpenRouter": "qwen/qwen3-coder-30b-a3b-instruct",
    "Puter": "alibaba:qwen/qwen3-coder-30b-a3b-instruct"
  },
  "mimo-v2.5": {
    "HuggingFace": "XiaomiMiMo/MiMo-V2.5",
    "Airforce": "mimo-v2.5",
    "HuggingChat": "XiaomiMiMo/MiMo-V2.5",
    "LMArena": "mimo-v2.5",
    "OpenRouter": "xiaomi/mimo-v2.5",
    "Pollinations": "MarcosFRG/mimo-v2.5",
    "Puter": "openrouter:xiaomi/mimo-v2.5"
  },
  "qwen-3-coder-next": {
    "HuggingFace": "Qwen/Qwen3-Coder-Next",
    "HuggingChat": "Qwen/Qwen3-Coder-Next",
    "OpenRouter": "qwen/qwen3-coder-next",
    "Puter": "openrouter:qwen/qwen3-coder-next"
  },
  "gemma-3-4b-it": {
    "HuggingFace": "google/gemma-3-4b-it",
    "GeminiPro": "gemma-3-4b-it",
    "HuggingChat": "google/gemma-3-4b-it",
    "Nvidia": "google/gemma-3-4b-it",
    "OpenRouter": "google/gemma-3-4b-it",
    "Puter": "openrouter:google/gemma-3-4b-it"
  },
  "qwen-3.5-122b-a10b": {
    "HuggingFace": "Qwen/Qwen3.5-122B-A10B",
    "HuggingChat": "Qwen/Qwen3.5-122B-A10B",
    "LMArena": "qwen3.5-122b-a10b",
    "OpenRouter": "qwen/qwen3.5-122b-a10b",
    "Puter": "alibaba:qwen/qwen3.5-122b-a10b",
    "Qwen": "qwen3.5-122b-a10b"
  },
  "ling-2.6-1t": {
    "HuggingFace": "inclusionAI/Ling-2.6-1T",
    "HuggingChat": "inclusionAI/Ling-2.6-1T",
    "OpenRouter": "inclusionai/ling-2.6-1t",
    "Puter": "openrouter:inclusionai/ling-2.6-1t"
  },
  "qwen-3-4b-2507": {
    "HuggingFace": "Qwen/Qwen3-4B-Instruct-2507",
    "HuggingChat": "Qwen/Qwen3-4B-Instruct-2507"
  },
  "step-3.7-flash": {
    "HuggingFace": "stepfun-ai/Step-3.7-Flash",
    "HuggingChat": "stepfun-ai/Step-3.7-Flash",
    "LMArena": "step-3.7-flash",
    "Nvidia": "stepfun-ai/step-3.7-flash",
    "OpenRouter": "stepfun/step-3.7-flash",
    "Pollinations": "step-flash",
    "Puter": "openrouter:stepfun/step-3.7-flash"
  },
  "glm-4.5-air": {
    "HuggingFace": "zai-org/GLM-4.5-Air",
    "Airforce": "glm-4.5-air",
    "GLM": "GLM-4.5-Air",
    "HuggingChat": "zai-org/GLM-4.5-Air",
    "OpenRouter": "z-ai/glm-4.5-air",
    "Puter": "z-ai:z-ai/glm-4.5-air"
  },
  "qwen-3-14b": {
    "HuggingFace": "Qwen/Qwen3-14B",
    "Airforce": "qwen3-14b",
    "HuggingChat": "Qwen/Qwen3-14B",
    "OpenRouter": "qwen/qwen3-14b",
    "Puter": [
      "openrouter:qwen/qwen3-14b:free",
      "openrouter:qwen/qwen3-14b"
    ]
  },
  "qwen-3-next-80b-a3b": {
    "HuggingFace": "Qwen/Qwen3-Next-80B-A3B-Instruct",
    "Airforce": "qwen3-next-80b-a3b",
    "HuggingChat": "Qwen/Qwen3-Next-80B-A3B-Instruct",
    "LMArena": "qwen3-next-80b-a3b-instruct",
    "Nvidia": "qwen/qwen3-next-80b-a3b-instruct",
    "OpenRouter": "qwen/qwen3-next-80b-a3b-instruct",
    "Puter": "alibaba:qwen/qwen3-next-80b-a3b-instruct"
  },
  "qwen-2.5-coder-7b": {
    "HuggingFace": "Qwen/Qwen2.5-Coder-7B-Instruct",
    "HuggingChat": "Qwen/Qwen2.5-Coder-7B-Instruct",
    "Puter": "openrouter:qwen/qwen2.5-coder-7b-instruct"
  },
  "nvidia-nemotron-3-ultra-550b-a55b-nvfp4": {
    "HuggingFace": "nvidia/NVIDIA-Nemotron-3-Ultra-550B-A55B-NVFP4",
    "HuggingChat": "nvidia/NVIDIA-Nemotron-3-Ultra-550B-A55B-NVFP4"
  },
  "qwen-3.5-35b-a3b": {
    "HuggingFace": "Qwen/Qwen3.5-35B-A3B",
    "HuggingChat": "Qwen/Qwen3.5-35B-A3B",
    "LMArena": "qwen3.5-35b-a3b",
    "OpenRouter": "qwen/qwen3.5-35b-a3b",
    "Puter": "alibaba:qwen/qwen3.5-35b-a3b",
    "Qwen": "qwen3.5-35b-a3b"
  },
  "gemma-3-27b-it": {
    "HuggingFace": "google/gemma-3-27b-it",
    "GeminiPro": "gemma-3-27b-it",
    "HuggingChat": "google/gemma-3-27b-it",
    "LMArena": "gemma-3-27b-it",
    "OpenRouter": "google/gemma-3-27b-it",
    "Puter": "openrouter:google/gemma-3-27b-it"
  },
  "gemma-3-12b-it": {
    "HuggingFace": "google/gemma-3-12b-it",
    "GeminiPro": "gemma-3-12b-it",
    "HuggingChat": "google/gemma-3-12b-it",
    "Nvidia": "google/gemma-3-12b-it",
    "OpenRouter": "google/gemma-3-12b-it",
    "Puter": "openrouter:google/gemma-3-12b-it"
  },
  "phi-4": {
    "HuggingFace": "microsoft/phi-4",
    "HuggingChat": "microsoft/phi-4",
    "OpenRouter": "microsoft/phi-4",
    "Puter": "openrouter:microsoft/phi-4"
  },
  "qwen-3-vl-30b-a3b": {
    "HuggingFace": "Qwen/Qwen3-VL-30B-A3B-Instruct",
    "Airforce": "qwen3-vl-30b-a3b",
    "HuggingChat": "Qwen/Qwen3-VL-30B-A3B-Instruct",
    "OpenRouter": "qwen/qwen3-vl-30b-a3b-instruct",
    "Puter": "openrouter:qwen/qwen3-vl-30b-a3b-instruct"
  },
  "ternary-bonsai-27b-awq-4bit": {
    "HuggingFace": "prism-ml/Ternary-Bonsai-27B-AWQ-4bit",
    "HuggingChat": "prism-ml/Ternary-Bonsai-27B-AWQ-4bit"
  },
  "kimi-k2-0905": {
    "HuggingFace": "moonshotai/Kimi-K2-Instruct-0905",
    "HuggingChat": "moonshotai/Kimi-K2-Instruct-0905",
    "LMArena": "kimi-k2-0905-preview",
    "OpenRouter": "moonshotai/kimi-k2-0905",
    "Puter": "openrouter:moonshotai/kimi-k2-0905"
  },
  "qwen-2.5-7b": {
    "HuggingFace": "Qwen/Qwen2.5-7B-Instruct",
    "GlhfChat": "hf:Qwen/Qwen2.5-7B-Instruct",
    "HuggingChat": "Qwen/Qwen2.5-7B-Instruct",
    "OpenRouter": "qwen/qwen-2.5-7b-instruct",
    "Puter": [
      "openrouter:qwen/qwen-2.5-7b-instruct:free",
      "openrouter:qwen/qwen-2.5-7b-instruct"
    ]
  },
  "qwen-3-vl-235b-a22b": {
    "HuggingFace": "Qwen/Qwen3-VL-235B-A22B-Instruct",
    "Airforce": "qwen3-vl-235b-a22b",
    "HuggingChat": "Qwen/Qwen3-VL-235B-A22B-Instruct",
    "LMArena": "qwen3-vl-235b-a22b-instruct",
    "OpenRouter": "qwen/qwen3-vl-235b-a22b-instruct",
    "Puter": "openrouter:qwen/qwen3-vl-235b-a22b-instruct"
  },
  "llama-3.3-70b": {
    "HuggingFace": "meta-llama/Llama-3.3-70B-Instruct",
    "Cerebras": "llama-3.3-70b",
    "Cloudflare": "@cf/meta/llama-3.3-70b-instruct-fp8-fast",
    "GlhfChat": "hf:meta-llama/Llama-3.3-70B-Instruct",
    "HuggingChat": "meta-llama/Llama-3.3-70B-Instruct",
    "Nvidia": "meta/llama-3.3-70b-instruct",
    "OpenRouter": "meta-llama/llama-3.3-70b-instruct",
    "Pollinations": "llama",
    "Puter": [
      "openrouter:meta-llama/llama-3.3-70b-instruct:free",
      "openrouter:meta-llama/llama-3.3-70b-instruct"
    ]
  },
  "qwen-3-coder-480b-a35b": {
    "HuggingFace": "Qwen/Qwen3-Coder-480B-A35B-Instruct",
    "Airforce": "qwen3-coder-480b-a35b",
    "HuggingChat": "Qwen/Qwen3-Coder-480B-A35B-Instruct",
    "LMArena": "qwen3-coder-480b-a35b-instruct",
    "Puter": "alibaba:qwen/qwen3-coder-480b-a35b-instruct"
  },
  "gpt-oss-safeguard-20b": {
    "HuggingFace": "openai/gpt-oss-safeguard-20b",
    "Groq": "openai/gpt-oss-safeguard-20b",
    "HuggingChat": "openai/gpt-oss-safeguard-20b",
    "OpenRouter": "openai/gpt-oss-safeguard-20b",
    "Puter": "openrouter:openai/gpt-oss-safeguard-20b"
  },
  "command-r7b24": {
    "HuggingFace": "CohereLabs/c4ai-command-r7b-12-2024",
    "HuggingSpace": "command-r7b-12-2024",
    "Cohere": "command-r7b-12-2024",
    "CohereForAI_C4AI_Command": "command-r7b-12-2024",
    "HuggingChat": "CohereLabs/c4ai-command-r7b-12-2024",
    "OpenRouter": "cohere/command-r7b-12-2024",
    "Puter": "openrouter:cohere/command-r7b-12-2024"
  },
  "qwen-3-235b-a22b-2507": {
    "HuggingFace": "Qwen/Qwen3-235B-A22B-Instruct-2507",
    "HuggingChat": "Qwen/Qwen3-235B-A22B-Instruct-2507",
    "LMArena": "qwen3-235b-a22b-instruct-2507",
    "OpenRouter": "qwen/qwen3-235b-a22b-2507",
    "Puter": "openrouter:qwen/qwen3-235b-a22b-2507"
  },
  "llama-4-scout-17b-16e": {
    "HuggingFace": "meta-llama/Llama-4-Scout-17B-16E-Instruct",
    "Airforce": "llama-4-scout-17b-16e-instruct",
    "HuggingChat": "meta-llama/Llama-4-Scout-17B-16E-Instruct"
  },
  "step-3.5-flash": {
    "HuggingFace": "stepfun-ai/Step-3.5-Flash",
    "HuggingChat": "stepfun-ai/Step-3.5-Flash",
    "LMArena": "step-3.5-flash",
    "Nvidia": "stepfun-ai/step-3.5-flash",
    "OpenRouter": "stepfun/step-3.5-flash",
    "Pollinations": "step-3.5-flash",
    "Puter": "openrouter:stepfun/step-3.5-flash"
  },
  "qwen-2.5-coder-3b": {
    "HuggingFace": "Qwen/Qwen2.5-Coder-3B-Instruct",
    "HuggingChat": "Qwen/Qwen2.5-Coder-3B-Instruct"
  },
  "l3-8b-stheno-v3.2": {
    "HuggingFace": "Sao10K/L3-8B-Stheno-v3.2",
    "HuggingChat": "Sao10K/L3-8B-Stheno-v3.2"
  },
  "deepseek-r1-distill-qwen-7b": {
    "HuggingFace": "deepseek-ai/DeepSeek-R1-Distill-Qwen-7B",
    "HuggingChat": "deepseek-ai/DeepSeek-R1-Distill-Qwen-7B"
  },
  "llama-guard-4-12b": {
    "HuggingFace": "meta-llama/Llama-Guard-4-12B",
    "HuggingChat": "meta-llama/Llama-Guard-4-12B",
    "Nvidia": "meta/llama-guard-4-12b",
    "OpenRouter": "meta-llama/llama-guard-4-12b",
    "Puter": "togetherai:meta-llama/llama-guard-4-12b"
  },
  "qwen-3-4b-thinking-2507": {
    "HuggingFace": "Qwen/Qwen3-4B-Thinking-2507",
    "HuggingChat": "Qwen/Qwen3-4B-Thinking-2507"
  },
  "glm-4.7": {
    "HuggingFace": "zai-org/GLM-4.7",
    "Airforce": "glm-4.7",
    "GLM": "GLM-4.7",
    "HuggingChat": "zai-org/GLM-4.7",
    "LMArena": "glm-4.7",
    "OpenRouter": "z-ai/glm-4.7",
    "Pollinations": "Catniti/glm-4.7",
    "Puter": "z-ai:z-ai/glm-4.7"
  },
  "gemma-sea-lion-v4-27b-it": {
    "HuggingFace": "aisingapore/Gemma-SEA-LION-v4-27B-IT",
    "GeminiPro": "gemma-sea-lion-v4-27b-it",
    "HuggingChat": "aisingapore/Gemma-SEA-LION-v4-27B-IT"
  },
  "command-a25": {
    "HuggingFace": "CohereLabs/c4ai-command-a-03-2025",
    "HuggingSpace": "command-a-03-2025",
    "Cohere": "command-a-03-2025",
    "CohereForAI_C4AI_Command": "command-a-03-2025",
    "HuggingChat": "CohereLabs/c4ai-command-a-03-2025"
  },
  "deepseek-r1-distill-llama-8b": {
    "HuggingFace": "deepseek-ai/DeepSeek-R1-Distill-Llama-8B",
    "HuggingChat": "deepseek-ai/DeepSeek-R1-Distill-Llama-8B",
    "Puter": "openrouter:deepseek/deepseek-r1-distill-llama-8b"
  },
  "apertus-8b-2509": {
    "HuggingFace": "swiss-ai/Apertus-8B-Instruct-2509",
    "HuggingChat": "swiss-ai/Apertus-8B-Instruct-2509"
  },
  "tiny-aya-global": {
    "HuggingFace": "CohereLabs/tiny-aya-global",
    "Cohere": "tiny-aya-global",
    "HuggingChat": "CohereLabs/tiny-aya-global"
  },
  "qwen-3-235b-a22b": {
    "HuggingFace": "Qwen/Qwen3-235B-A22B",
    "Airforce": "qwen3-235b-a22b",
    "HuggingChat": "Qwen/Qwen3-235B-A22B",
    "LMArena": "qwen3-235b-a22b",
    "OpenRouter": "qwen/qwen3-235b-a22b",
    "Puter": "alibaba:qwen/qwen3-235b-a22b"
  },
  "bielik-11b-v3.0": {
    "HuggingFace": "speakleash/Bielik-11B-v3.0-Instruct",
    "HuggingChat": "speakleash/Bielik-11B-v3.0-Instruct"
  },
  "tiny-aya-earth": {
    "HuggingFace": "CohereLabs/tiny-aya-earth",
    "Cohere": "tiny-aya-earth",
    "HuggingChat": "CohereLabs/tiny-aya-earth"
  },
  "minimax-m2.7": {
    "HuggingFace": "MiniMaxAI/MiniMax-M2.7",
    "Airforce": "minimax-m2.7",
    "HuggingChat": "MiniMaxAI/MiniMax-M2.7",
    "LMArena": "minimax-m2.7",
    "MiniMax": "MiniMax-M2.7",
    "Nvidia": "minimaxai/minimax-m2.7",
    "Ollama": "minimax-m2.7",
    "OpenRouter": "minimax/minimax-m2.7",
    "Pollinations": "minimax-m2.7",
    "Puter": "minimax:minimax/minimax-m2.7"
  },
  "llama-4-maverick-17b-128e": {
    "HuggingFace": "meta-llama/Llama-4-Maverick-17B-128E-Instruct-FP8",
    "HuggingChat": "meta-llama/Llama-4-Maverick-17B-128E-Instruct-FP8",
    "Nvidia": "meta/llama-4-maverick-17b-128e-instruct"
  },
  "deepseek-v3-0324": {
    "HuggingFace": "deepseek-ai/DeepSeek-V3-0324",
    "Airforce": "deepseek-v3-0324",
    "HuggingChat": "deepseek-ai/DeepSeek-V3-0324",
    "Puter": [
      "deepseek-chat",
      "openrouter:deepseek/deepseek-chat-v3-0324:free",
      "openrouter:deepseek/deepseek-chat-v3-0324"
    ]
  },
  "ernie-4.5-vl-424b-a47b-base-pt": {
    "HuggingFace": "baidu/ERNIE-4.5-VL-424B-A47B-Base-PT",
    "HuggingChat": "baidu/ERNIE-4.5-VL-424B-A47B-Base-PT"
  },
  "glm-4-32b-0414": {
    "HuggingFace": "zai-org/GLM-4-32B-0414",
    "HuggingChat": "zai-org/GLM-4-32B-0414"
  },
  "deepseek-r1-0528": {
    "HuggingFace": "deepseek-ai/DeepSeek-R1-0528",
    "HuggingChat": "deepseek-ai/DeepSeek-R1-0528",
    "OpenRouter": "deepseek/deepseek-r1-0528",
    "Puter": "openrouter:deepseek/deepseek-r1-0528"
  },
  "qwen-3-235b-a22b-thinking-2507": {
    "HuggingFace": "Qwen/Qwen3-235B-A22B-Thinking-2507",
    "HuggingChat": "Qwen/Qwen3-235B-A22B-Thinking-2507",
    "LMArena": "qwen3-235b-a22b-thinking-2507",
    "OpenRouter": "qwen/qwen3-235b-a22b-thinking-2507",
    "Puter": "openrouter:qwen/qwen3-235b-a22b-thinking-2507"
  },
  "deepseek": {
    "HuggingFace": "deepseek-ai/DeepSeek-V3",
    "Airforce": "deepseek",
    "DeepSeek": "deepseek-v3",
    "GlhfChat": "hf:deepseek-ai/DeepSeek-V3",
    "HuggingChat": "deepseek-ai/DeepSeek-V3",
    "PhindAi": "deepseek",
    "Pollinations": "deepseek",
    "WeWordle": "v3"
  },
  "glm-4.5": {
    "HuggingFace": "zai-org/GLM-4.5",
    "Airforce": "glm-4.5",
    "GLM": "GLM-4.5",
    "HuggingChat": "zai-org/GLM-4.5",
    "OpenRouter": "z-ai/glm-4.5",
    "Puter": "z-ai:z-ai/glm-4.5"
  },
  "glm-4.5v": {
    "HuggingFace": "zai-org/GLM-4.5V",
    "HuggingChat": "zai-org/GLM-4.5V-FP8",
    "OpenRouter": "z-ai/glm-4.5v",
    "Puter": "z-ai:z-ai/glm-4.5v"
  },
  "wizardlm-2-8x22b": {
    "HuggingFace": "alpindale/WizardLM-2-8x22B",
    "HuggingChat": "alpindale/WizardLM-2-8x22B",
    "OpenRouter": "microsoft/wizardlm-2-8x22b",
    "Puter": "openrouter:microsoft/wizardlm-2-8x22b"
  },
  "qwen-2.5-72b": {
    "HuggingFace": "Qwen/Qwen2.5-72B-Instruct",
    "GlhfChat": "hf:Qwen/Qwen2.5-72B-Instruct",
    "HuggingChat": "Qwen/Qwen2.5-72B-Instruct",
    "OpenRouter": "qwen/qwen-2.5-72b-instruct",
    "Puter": [
      "openrouter:qwen/qwen-2.5-72b-instruct:free",
      "openrouter:qwen/qwen-2.5-72b-instruct"
    ]
  },
  "glm-4.6": {
    "HuggingFace": "zai-org/GLM-4.6",
    "Airforce": "glm-4.6",
    "HuggingChat": "zai-org/GLM-4.6",
    "OpenRouter": "z-ai/glm-4.6",
    "Puter": "z-ai:z-ai/glm-4.6"
  },
  "glm-4.6v-flash": {
    "HuggingFace": "zai-org/GLM-4.6V-Flash",
    "HuggingChat": "zai-org/GLM-4.6V-Flash",
    "Pollinations": "MarcosFRG/glm-4.6v-flash",
    "Puter": "z-ai:z-ai/glm-4.6v-flash"
  },
  "l3-8b-lunaris": {
    "HuggingFace": "Sao10K/L3-8B-Lunaris-v1",
    "HuggingChat": "Sao10K/L3-8B-Lunaris-v1"
  },
  "deepseek-v3.1": {
    "HuggingFace": "deepseek-ai/DeepSeek-V3.1",
    "Airforce": "deepseek-v3.1",
    "HuggingChat": "deepseek-ai/DeepSeek-V3.1"
  },
  "glm-4.6v": {
    "HuggingFace": "zai-org/GLM-4.6V-FP8",
    "GLM": "GLM-4.6V",
    "HuggingChat": "zai-org/GLM-4.6V-FP8",
    "OpenRouter": "z-ai/glm-4.6v",
    "Puter": "z-ai:z-ai/glm-4.6v"
  },
  "minimax-m1-80k": {
    "HuggingFace": "MiniMaxAI/MiniMax-M1-80k",
    "HuggingChat": "MiniMaxAI/MiniMax-M1-80k"
  },
  "deepseek-v3.1-terminus": {
    "HuggingFace": "deepseek-ai/DeepSeek-V3.1-Terminus",
    "Airforce": "deepseek-v3.1-terminus",
    "HuggingChat": "deepseek-ai/DeepSeek-V3.1-Terminus",
    "OpenRouter": "deepseek/deepseek-v3.1-terminus",
    "Puter": "openrouter:deepseek/deepseek-v3.1-terminus"
  },
  "command-r24": {
    "HuggingFace": "CohereLabs/c4ai-command-r-08-2024",
    "HuggingSpace": "command-r-08-2024",
    "Cohere": "command-r-08-2024",
    "CohereForAI_C4AI_Command": "command-r-08-2024",
    "HuggingChat": "CohereLabs/c4ai-command-r-08-2024",
    "OpenRouter": "cohere/command-r-08-2024",
    "Puter": "openrouter:cohere/command-r-08-2024"
  },
  "deepseek-v3.2-exp": {
    "HuggingFace": "deepseek-ai/DeepSeek-V3.2-Exp",
    "HuggingChat": "deepseek-ai/DeepSeek-V3.2-Exp",
    "OpenRouter": "deepseek/deepseek-v3.2-exp",
    "Puter": "openrouter:deepseek/deepseek-v3.2-exp"
  },
  "aya-expanse-32b": {
    "HuggingFace": "CohereLabs/aya-expanse-32b",
    "Cohere": "c4ai-aya-expanse-32b",
    "HuggingChat": "CohereLabs/aya-expanse-32b"
  },
  "aya-vision-32b": {
    "HuggingFace": "CohereLabs/aya-vision-32b",
    "Cohere": "c4ai-aya-vision-32b",
    "HuggingChat": "CohereLabs/aya-vision-32b"
  },
  "minimax-m2": {
    "HuggingFace": "MiniMaxAI/MiniMax-M2",
    "Airforce": "minimax-m2",
    "HuggingChat": "MiniMaxAI/MiniMax-M2",
    "LMArena": "minimax-m2-preview",
    "OpenRouter": "minimax/minimax-m2",
    "Puter": "minimax:minimax/minimax-m2"
  },
  "command-r7b-arabic25": {
    "HuggingFace": "CohereLabs/c4ai-command-r7b-arabic-02-2025",
    "HuggingSpace": "command-r7b-arabic-02-2025",
    "Cohere": "command-r7b-arabic-02-2025",
    "CohereForAI_C4AI_Command": "command-r7b-arabic-02-2025",
    "HuggingChat": "CohereLabs/c4ai-command-r7b-arabic-02-2025"
  },
  "command-a-vision25": {
    "HuggingFace": "CohereLabs/command-a-vision-07-2025",
    "Cohere": "command-a-vision-07-2025",
    "HuggingChat": "CohereLabs/command-a-vision-07-2025"
  },
  "minimax-m2.1": {
    "HuggingFace": "MiniMaxAI/MiniMax-M2.1",
    "Airforce": "minimax-m2.1",
    "HuggingChat": "MiniMaxAI/MiniMax-M2.1",
    "LMArena": "minimax-m2.1-preview",
    "OpenRouter": "minimax/minimax-m2.1",
    "Puter": "minimax:minimax/minimax-m2.1"
  },
  "command-a-reasoning25": {
    "HuggingFace": "CohereLabs/command-a-reasoning-08-2025",
    "Cohere": "command-a-reasoning-08-2025",
    "HuggingChat": "CohereLabs/command-a-reasoning-08-2025"
  },
  "gemma-3n-e4b-it": {
    "HuggingFace": "google/gemma-3n-E4B-it",
    "GeminiPro": "gemma-3n-e4b-it",
    "HuggingChat": "google/gemma-3n-E4B-it",
    "LMArena": "gemma-3n-e4b-it",
    "Nvidia": "google/gemma-3n-e4b-it",
    "OpenRouter": "google/gemma-3n-e4b-it",
    "Puter": "togetherai:google/gemma-3n-e4b-it"
  },
  "command-a-translate25": {
    "HuggingFace": "CohereLabs/command-a-translate-08-2025",
    "Cohere": "command-a-translate-08-2025",
    "HuggingChat": "CohereLabs/command-a-translate-08-2025"
  },
  "qwen-3-vl-235b-a22b-thinking": {
    "HuggingFace": "Qwen/Qwen3-VL-235B-A22B-Thinking",
    "HuggingChat": "Qwen/Qwen3-VL-235B-A22B-Thinking",
    "LMArena": "qwen3-vl-235b-a22b-thinking",
    "OpenRouter": "qwen/qwen3-vl-235b-a22b-thinking",
    "Puter": "openrouter:qwen/qwen3-vl-235b-a22b-thinking"
  },
  "gemma-4-31b-it-pearl": {
    "HuggingFace": "pearl-ai/Gemma-4-31B-it-pearl",
    "GeminiPro": "gemma-4-31b-it-pearl",
    "HuggingChat": "pearl-ai/Gemma-4-31B-it-pearl"
  },
  "tiny-aya-water": {
    "HuggingFace": "CohereLabs/tiny-aya-water",
    "Cohere": "tiny-aya-water",
    "HuggingChat": "CohereLabs/tiny-aya-water"
  },
  "apertus-70b-2509": {
    "HuggingFace": "swiss-ai/Apertus-70B-Instruct-2509",
    "HuggingChat": "swiss-ai/Apertus-70B-Instruct-2509"
  },
  "autoglm-phone-9b-multilingual": {
    "HuggingFace": "zai-org/AutoGLM-Phone-9B-Multilingual",
    "HuggingChat": "zai-org/AutoGLM-Phone-9B-Multilingual"
  },
  "tiny-aya-fire": {
    "HuggingFace": "CohereLabs/tiny-aya-fire",
    "Cohere": "tiny-aya-fire",
    "HuggingChat": "CohereLabs/tiny-aya-fire"
  },
  "qwen-sea-lion-v4-32b-it": {
    "HuggingFace": "aisingapore/Qwen-SEA-LION-v4-32B-IT",
    "HuggingChat": "aisingapore/Qwen-SEA-LION-v4-32B-IT"
  },
  "olmo-3-7b": {
    "HuggingFace": "allenai/Olmo-3-7B-Instruct",
    "HuggingChat": "allenai/Olmo-3-7B-Instruct"
  },
  "eurollm-22b-2512": {
    "HuggingFace": "utter-project/EuroLLM-22B-Instruct-2512",
    "HuggingChat": "utter-project/EuroLLM-22B-Instruct-2512"
  },
  "command-r": {
    "HuggingSpace": "command-r-08-2024",
    "CohereForAI_C4AI_Command": "command-r-08-2024",
    "Puter": [
      "openrouter:cohere/command-r-08-2024",
      "openrouter:cohere/command-r",
      "openrouter:cohere/command-r-03-2024"
    ]
  },
  "command-r-plus": {
    "HuggingSpace": [
      "command-r-plus-08-2024",
      "command-r-plus"
    ],
    "CohereForAI_C4AI_Command": [
      "command-r-plus-08-2024",
      "command-r-plus"
    ],
    "Puter": [
      "openrouter:cohere/command-r-plus-08-2024",
      "openrouter:cohere/command-r-plus",
      "openrouter:cohere/command-r-plus-04-2024"
    ]
  },
  "command-r-plus24": {
    "HuggingSpace": "command-r-plus-08-2024",
    "Cohere": "command-r-plus-08-2024",
    "CohereForAI_C4AI_Command": "command-r-plus-08-2024",
    "OpenRouter": "cohere/command-r-plus-08-2024",
    "Puter": "openrouter:cohere/command-r-plus-08-2024"
  },
  "flux-dev": {
    "HuggingSpace": "black-forest-labs-flux-1-dev",
    "BlackForestLabs_Flux1Dev": "black-forest-labs-flux-1-dev",
    "HuggingFaceMedia": "black-forest-labs/FLUX.1-dev",
    "Pollinations": "flux"
  },
  "flux-kontext-dev": {
    "HuggingSpace": "flux-kontext-dev",
    "BlackForestLabs_Flux1KontextDev": "flux-kontext-dev"
  },
  "perplexity": {
    "Perplexity": "perplexity",
    "Pollinations": "perplexity"
  },
  "pplx_pro": {
    "Perplexity": "pplx_pro"
  },
  "video": {
    "Video": "video"
  }
}
models_count = {
  "default": 11,
  "gpt-4": 11,
  "gpt-4o": 9,
  "gpt-4o-mini": 6,
  "gpt-4o-mini-tts": 2,
  "o1": 9,
  "o1-mini": 3,
  "o3-mini": 6,
  "o3-mini-high": 4,
  "o4-mini": 5,
  "o4-mini-high": 3,
  "gpt-4.1": 6,
  "gpt-4.1-mini": 4,
  "gpt-4.1-nano": 4,
  "gpt-4.5": 2,
  "gpt-oss-120b": 12,
  "dall-e-3": 5,
  "gpt-image": 3,
  "meta-ai": 2,
  "llama-2-70b": 3,
  "llama-3-8b": 4,
  "llama-3-70b": 4,
  "llama-3.1-8b": 9,
  "llama-3.1-70b": 6,
  "llama-3.1-405b": 3,
  "llama-3.2-3b": 6,
  "llama-3.2-90b": 2,
  "llama-4-scout": 5,
  "llama-4-maverick": 4,
  "mixtral-8x7b": 2,
  "mistral-small-3.1-24b": 5,
  "hermes-2-dpo": 2,
  "gemini-2.5-flash": 8,
  "gemini-2.5-pro": 10,
  "gemini-3-pro-preview": 2,
  "gemini-3.1-pro": 8,
  "gemini-3.1-flash-lite": 9,
  "gemini-3.5-flash": 8,
  "gemini-3.5-flash-thinking": 2,
  "gemini-auto": 2,
  "gemini-3.5-flash-thinking-lite": 2,
  "gemini-flash-lite": 3,
  "command-r7b": 3,
  "command-a": 4,
  "qwen-2.5-coder-32b": 8,
  "qwen-2.5-vl-72b": 5,
  "qwen-3-235b": 2,
  "qwen-3-32b": 6,
  "qwq-32b": 6,
  "deepseek-v3": 2,
  "deepseek-r1": 10,
  "deepseek-r1-distill-llama-70b": 6,
  "deepseek-r1-distill-qwen-1.5b": 2,
  "deepseek-r1-distill-qwen-14b": 4,
  "grok-2": 2,
  "grok-3": 3,
  "kimi-k2": 6,
  "sonar": 3,
  "sonar-pro": 3,
  "sonar-reasoning": 2,
  "sonar-reasoning-pro": 3,
  "r1-1776": 3,
  "nemotron-70b": 3,
  "sdxl-turbo": 3,
  "sd-3.5-large": 3,
  "flux": 6,
  "flux-pro": 3,
  "flux-kontext": 2,
  "glm-5.2": 11,
  "kimi-k2.7-code": 11,
  "nvidia-nemotron-3-ultra-550b-a55b": 3,
  "deepseek-v4-flash": 10,
  "deepseek-v4-pro": 10,
  "kimi-k2.6": 11,
  "mimo-v2.5-pro": 8,
  "qwen-3.6-35b-a3b": 7,
  "glm-5.1": 9,
  "qwen-3.5-397b-a17b": 9,
  "gemma-4-26b-a4b-it": 9,
  "gemma-4-31b-it": 9,
  "glm-5": 7,
  "minimax-m2.5": 9,
  "qwen-3-max": 6,
  "qwen-3-max-thinking": 4,
  "kimi-k2.5": 8,
  "glm-4.7-flash": 8,
  "deepseek-v3.2": 7,
  "inkling": 6,
  "ternary-bonsai-27b-gguf": 2,
  "qwen-3.6-27b": 7,
  "hy3": 5,
  "ornith-1.0-35b": 2,
  "apertus-v1.5-70b": 2,
  "minimax-m3": 10,
  "apertus-v1.5-8b": 2,
  "qwen-3.5-9b": 4,
  "qwen-3-8b": 5,
  "gpt-oss-20b": 11,
  "qwen-3.5-27b": 6,
  "qwen-3-coder-30b-a3b": 5,
  "mimo-v2.5": 7,
  "qwen-3-coder-next": 4,
  "gemma-3-4b-it": 6,
  "qwen-3.5-122b-a10b": 6,
  "ling-2.6-1t": 4,
  "qwen-3-4b-2507": 2,
  "step-3.7-flash": 7,
  "glm-4.5-air": 6,
  "qwen-3-14b": 5,
  "qwen-3-next-80b-a3b": 7,
  "qwen-2.5-coder-7b": 3,
  "nvidia-nemotron-3-ultra-550b-a55b-nvfp4": 2,
  "qwen-3.5-35b-a3b": 6,
  "gemma-3-27b-it": 6,
  "gemma-3-12b-it": 6,
  "phi-4": 4,
  "qwen-3-vl-30b-a3b": 5,
  "ternary-bonsai-27b-awq-4bit": 2,
  "kimi-k2-0905": 5,
  "qwen-2.5-7b": 5,
  "qwen-3-vl-235b-a22b": 6,
  "llama-3.3-70b": 9,
  "qwen-3-coder-480b-a35b": 5,
  "gpt-oss-safeguard-20b": 5,
  "command-r7b24": 7,
  "qwen-3-235b-a22b-2507": 5,
  "llama-4-scout-17b-16e": 3,
  "step-3.5-flash": 7,
  "qwen-2.5-coder-3b": 2,
  "l3-8b-stheno-v3.2": 2,
  "deepseek-r1-distill-qwen-7b": 2,
  "llama-guard-4-12b": 5,
  "qwen-3-4b-thinking-2507": 2,
  "glm-4.7": 8,
  "gemma-sea-lion-v4-27b-it": 3,
  "command-a25": 5,
  "deepseek-r1-distill-llama-8b": 3,
  "apertus-8b-2509": 2,
  "tiny-aya-global": 3,
  "qwen-3-235b-a22b": 6,
  "bielik-11b-v3.0": 2,
  "tiny-aya-earth": 3,
  "minimax-m2.7": 10,
  "llama-4-maverick-17b-128e": 3,
  "deepseek-v3-0324": 4,
  "ernie-4.5-vl-424b-a47b-base-pt": 2,
  "glm-4-32b-0414": 2,
  "deepseek-r1-0528": 4,
  "qwen-3-235b-a22b-thinking-2507": 5,
  "deepseek": 8,
  "glm-4.5": 6,
  "glm-4.5v": 4,
  "wizardlm-2-8x22b": 4,
  "qwen-2.5-72b": 5,
  "glm-4.6": 5,
  "glm-4.6v-flash": 4,
  "l3-8b-lunaris": 2,
  "deepseek-v3.1": 3,
  "glm-4.6v": 5,
  "minimax-m1-80k": 2,
  "deepseek-v3.1-terminus": 5,
  "command-r24": 7,
  "deepseek-v3.2-exp": 4,
  "aya-expanse-32b": 3,
  "aya-vision-32b": 3,
  "minimax-m2": 6,
  "command-r7b-arabic25": 5,
  "command-a-vision25": 3,
  "minimax-m2.1": 6,
  "command-a-reasoning25": 3,
  "gemma-3n-e4b-it": 7,
  "command-a-translate25": 3,
  "qwen-3-vl-235b-a22b-thinking": 5,
  "gemma-4-31b-it-pearl": 3,
  "tiny-aya-water": 3,
  "apertus-70b-2509": 2,
  "autoglm-phone-9b-multilingual": 2,
  "tiny-aya-fire": 3,
  "qwen-sea-lion-v4-32b-it": 2,
  "olmo-3-7b": 2,
  "eurollm-22b-2512": 2,
  "command-r": 3,
  "command-r-plus": 3,
  "command-r-plus24": 5,
  "flux-dev": 4,
  "flux-kontext-dev": 2,
  "perplexity": 2
}
parents = {
  "HuggingSpace": [
    "BlackForestLabs_Flux1Dev",
    "BlackForestLabs_Flux1KontextDev",
    "CohereForAI_C4AI_Command",
    "StabilityAI_SD35Large"
  ],
  "Copilot": [
    "CopilotAccount",
    "CopilotSession"
  ],
  "HuggingFace": [
    "HuggingFaceMedia"
  ],
  "MetaAI": [
    "MetaAIAccount"
  ],
  "OpenaiChat": [
    "OpenaiAccount"
  ],
  "Pollinations": [
    "PollinationsAudio",
    "PollinationsImage"
  ]
}
model_aliases = {
  "": "default",
  "chat": "gpt-4o",
  "Copilot": "dall-e-3",
  "openai/gpt-4": "gpt-4",
  "openrouter:openai/gpt-4": "gpt-4",
  "openai/gpt-4o-2024-05-13": "gpt-4o",
  "openrouter:openai/gpt-4o-2024-11-20": "gpt-4o",
  "openai/gpt-4o-mini-2024-07-18": "gpt-4o-mini",
  "openrouter:openai/gpt-4o-mini-2024-07-18": "gpt-4o-mini",
  "coral": "gpt-4o-mini-tts",
  "Think Deeper": "o1",
  "reasoning": "o3-mini",
  "openai/o1": "o1",
  "openai:openai/o1": "o1",
  "openai:openai/o1-mini": "o1-mini",
  "o3-mini-2025-01-31": "o3-mini",
  "openai/o3-mini": "o3-mini",
  "openai:openai/o3-mini": "o3-mini",
  "openai/o3-mini-high": "o3-mini-high",
  "openrouter:openai/o3-mini-high": "o3-mini-high",
  "o4-mini-2025-04-16": "o4-mini",
  "openai/o4-mini": "o4-mini",
  "openai:openai/o4-mini": "o4-mini",
  "openai/o4-mini-high": "o4-mini-high",
  "openrouter:openai/o4-mini-high": "o4-mini-high",
  "gpt-4-1": "gpt-4.1",
  "gpt-4.1-2025-04-14": "gpt-4.1",
  "openai/gpt-4.1": "gpt-4.1",
  "openai:openai/gpt-4.1": "gpt-4.1",
  "gpt-4-1-mini": "gpt-4.1-mini",
  "gpt-4.1-mini-2025-04-14": "gpt-4.1-mini",
  "openai/gpt-4.1-mini": "gpt-4.1-mini",
  "openai:openai/gpt-4.1-mini": "gpt-4.1-mini",
  "openai-fast": "gpt-4.1-nano",
  "openai/gpt-4.1-nano": "gpt-4.1-nano",
  "openai:openai/gpt-4.1-nano": "gpt-4.1-nano",
  "gpt-4-5": "gpt-4.5",
  "openai:openai/gpt-4.5-preview": "gpt-4.5",
  "openai/gpt-oss-120b": "gpt-oss-120b",
  "@cf/openai/gpt-oss-120b": "gpt-oss-120b",
  "gpt-oss:120b": "gpt-oss-120b",
  "Catniti/gpt-oss-120b": "gpt-oss-120b",
  "togetherai:openai/gpt-oss-120b": "gpt-oss-120b",
  "gptimage": "gpt-image",
  "meta/llama2-70b": "llama-2-70b",
  "openrouter:meta-llama/llama-2-70b-chat": "llama-2-70b",
  "@hf/meta-llama/meta-llama-3-8b-instruct": "llama-3-8b",
  "llama-3-8b-instruct": "llama-3-8b",
  "openrouter:meta-llama/llama-3-8b-instruct": "llama-3-8b",
  "llama-3-70b-instruct": "llama-3-70b",
  "openrouter:meta-llama/llama-3-70b-instruct": "llama-3-70b",
  "meta/meta-llama-3-70b-instruct": "llama-3-70b",
  "meta-llama/Llama-3.1-8B-Instruct": "llama-3.1-8b",
  "llama3.1-8b": "llama-3.1-8b",
  "@cf/meta/llama-3.1-8b-instruct-fp8": "llama-3.1-8b",
  "hf:meta-llama/Llama-3.1-8B-Instruct": "llama-3.1-8b",
  "meta/llama-3.1-8b-instruct": "llama-3.1-8b",
  "meta-llama/llama-3.1-8b-instruct": "llama-3.1-8b",
  "llama3.1-70b": "llama-3.1-70b",
  "hf:meta-llama/Llama-3.1-70B-Instruct": "llama-3.1-70b",
  "meta/llama-3.1-70b-instruct": "llama-3.1-70b",
  "meta-llama/llama-3.1-70b-instruct": "llama-3.1-70b",
  "openrouter:meta-llama/llama-3.1-70b-instruct": "llama-3.1-70b",
  "hf:meta-llama/Llama-3.1-405B-Instruct": "llama-3.1-405b",
  "@cf/meta/llama-3.2-3b-instruct": "llama-3.2-3b",
  "hf:meta-llama/Llama-3.2-3B-Instruct": "llama-3.2-3b",
  "meta/llama-3.2-3b-instruct": "llama-3.2-3b",
  "meta-llama/llama-3.2-3b-instruct": "llama-3.2-3b",
  "openrouter:meta-llama/llama-3.2-90b-vision-instruct": "llama-3.2-90b",
  "llama-scout": "llama-4-scout",
  "@cf/meta/llama-4-scout-17b-16e-instruct": "llama-4-scout",
  "meta-llama/llama-4-scout": "llama-4-scout",
  "meta-llama/llama-4-maverick": "llama-4-maverick",
  "llama-maverick": "llama-4-maverick",
  "mixtral-8x7b-32768": "mixtral-8x7b",
  "mistral-small": "mistral-small-3.1-24b",
  "mistral-small-3.1-24b-instruct": "mistral-small-3.1-24b",
  "@cf/mistralai/mistral-small-3.1-24b-instruct": "mistral-small-3.1-24b",
  "mistralai/mistral-small-3.1-24b-instruct": "mistral-small-3.1-24b",
  "openrouter:mistralai/mistral-small-3.1-24b-instruct": "mistral-small-3.1-24b",
  "openrouter:nousresearch/nous-hermes-2-mixtral-8x7b-dpo": "hermes-2-dpo",
  "google/gemini-2.5-flash": "gemini-2.5-flash",
  "openrouter:google/gemini-2.5-flash-preview": "gemini-2.5-flash",
  "google/gemini-2.5-pro-preview-05-06": "gemini-2.5-pro",
  "gemini-large": "gemini-3.1-pro",
  "gemini-3.1-pro-preview": "gemini-3.1-pro",
  "google/gemini-3.1-pro-preview": "gemini-3.1-pro",
  "openrouter:google/gemini-3.1-pro-preview": "gemini-3.1-pro",
  "google/gemini-3.1-flash-lite-preview": "gemini-3.1-flash-lite",
  "gemini-flash-lite-3.5": "gemini-flash-lite",
  "openrouter:google/gemini-3.1-flash-lite-preview": "gemini-3.1-flash-lite",
  "google/gemini-3.5-flash": "gemini-3.5-flash",
  "gemini": "gemini-3.5-flash",
  "openrouter:google/gemini-3.5-flash": "gemini-3.5-flash",
  "openrouter:cohere/command-r7b-12-2024": "command-r7b24",
  "command-a-03-2025": "command-a25",
  "cohere/command-a": "command-a",
  "openrouter:cohere/command-a": "command-a",
  "Qwen/Qwen2.5-Coder-32B-Instruct": "qwen-2.5-coder-32b",
  "@cf/qwen/qwen2.5-coder-32b-instruct": "qwen-2.5-coder-32b",
  "hf:Qwen/Qwen2.5-Coder-32B-Instruct": "qwen-2.5-coder-32b",
  "qwen/qwen-2.5-coder-32b-instruct": "qwen-2.5-coder-32b",
  "qwen-3-coder": "qwen-2.5-coder-32b",
  "Qwen/Qwen2.5-VL-72B-Instruct": "qwen-2.5-vl-72b",
  "qwen/qwen2.5-vl-72b-instruct": "qwen-2.5-vl-72b",
  "Qwen/Qwen3-32B": "qwen-3-32b",
  "qwen3-32b": "qwen-3-32b",
  "qwen/qwen3-32b": "qwen-3-32b",
  "@cf/qwen/qwq-32b": "qwq-32b",
  "hf:Qwen/QwQ-32B-Preview": "qwq-32b",
  "openrouter:deepseek/deepseek-v3-base:free": "deepseek-v3",
  "deepseek-reasoning": "deepseek-r1",
  "deepseek-ai/DeepSeek-R1": "deepseek-r1",
  "deepseek/deepseek-r1": "deepseek-r1",
  "v3": "deepseek",
  "deepseek-ai/DeepSeek-R1-Distill-Llama-70B": "deepseek-r1-distill-llama-70b",
  "deepseek/deepseek-r1-distill-llama-70b": "deepseek-r1-distill-llama-70b",
  "openrouter:deepseek/deepseek-r1-distill-qwen-1.5b": "deepseek-r1-distill-qwen-1.5b",
  "deepseek-ai/DeepSeek-R1-Distill-Qwen-14B": "deepseek-r1-distill-qwen-14b",
  "x-ai:x-ai/grok-3": "grok-3",
  "grok-3-reasoning": "grok-3-r1",
  "moonshotai/Kimi-K2-Instruct": "kimi-k2",
  "moonshotai/kimi-k2": "kimi-k2",
  "openrouter:moonshotai/kimi-k2": "kimi-k2",
  "openrouter:perplexity/sonar": "sonar",
  "perplexity/sonar": "sonar",
  "perplexity-fast": "sonar",
  "openrouter:perplexity/sonar-pro": "sonar-pro",
  "perplexity/sonar-pro": "sonar-pro",
  "openrouter:perplexity/sonar-reasoning": "sonar-reasoning",
  "perplexity-reasoning": "sonar-reasoning-pro",
  "openrouter:perplexity/sonar-reasoning-pro": "sonar-reasoning-pro",
  "perplexity/sonar-reasoning-pro": "sonar-reasoning-pro",
  "openrouter:perplexity/r1-1776": "r1-1776",
  "openrouter:nvidia/llama-3.1-nemotron-70b-instruct": "nemotron-70b",
  "stabilityai/sdxl-turbo": "sdxl-turbo",
  "turbo": "sdxl-turbo",
  "stabilityai/stable-diffusion-3.5-large": "sd-3.5-large",
  "stabilityai-stable-diffusion-3-5-large": "sd-3.5-large",
  "black-forest-labs/FLUX.1-dev": "flux-dev",
  "black-forest-labs-flux-1-dev": "flux-dev",
  "kontext": "flux-kontext",
  "zai-org/GLM-5.2": "glm-5.2",
  "zai-org/GLM-5.2-FP8": "glm-5.2",
  "@cf/zai-org/glm-5.2": "glm-5.2",
  "GLM-5.2": "glm-5.2",
  "z-ai/glm-5.2": "glm-5.2",
  "glm": "glm-5.2",
  "z-ai:z-ai/glm-5.2": "glm-5.2",
  "moonshotai/Kimi-K2.7-Code": "kimi-k2.7-code",
  "@cf/moonshotai/kimi-k2.7-code": "kimi-k2.7-code",
  "moonshotai/kimi-k2.7-code": "kimi-k2.7-code",
  "kimi-code": "kimi-k2.7-code",
  "togetherai:moonshotai/kimi-k2.7-code": "kimi-k2.7-code",
  "nvidia/NVIDIA-Nemotron-3-Ultra-550B-A55B": "nvidia-nemotron-3-ultra-550b-a55b",
  "nvidia/NVIDIA-Nemotron-3-Ultra-550B-A55B-BF16": "nvidia-nemotron-3-ultra-550b-a55b",
  "deepseek-ai/DeepSeek-V4-Flash": "deepseek-v4-flash",
  "deepseek-ai/deepseek-v4-flash": "deepseek-v4-flash",
  "deepseek/deepseek-v4-flash": "deepseek-v4-flash",
  "deepseek:deepseek/deepseek-v4-flash": "deepseek-v4-flash",
  "deepseek-ai/DeepSeek-V4-Pro": "deepseek-v4-pro",
  "deepseek-ai/deepseek-v4-pro": "deepseek-v4-pro",
  "deepseek/deepseek-v4-pro": "deepseek-v4-pro",
  "deepseek-pro": "deepseek-v4-pro",
  "deepseek:deepseek/deepseek-v4-pro": "deepseek-v4-pro",
  "moonshotai/Kimi-K2.6": "kimi-k2.6",
  "@cf/moonshotai/kimi-k2.6": "kimi-k2.6",
  "moonshotai/kimi-k2.6": "kimi-k2.6",
  "kimi": "kimi-k2.6",
  "moonshotai:moonshotai/kimi-k2.6": "kimi-k2.6",
  "XiaomiMiMo/MiMo-V2.5-Pro": "mimo-v2.5-pro",
  "xiaomi/mimo-v2.5-pro": "mimo-v2.5-pro",
  "openrouter:xiaomi/mimo-v2.5-pro": "mimo-v2.5-pro",
  "Qwen/Qwen3.6-35B-A3B": "qwen-3.6-35b-a3b",
  "qwen3.6-35b-a3b": "qwen-3.6-35b-a3b",
  "qwen/qwen3.6-35b-a3b": "qwen-3.6-35b-a3b",
  "alibaba:qwen/qwen3.6-35b-a3b": "qwen-3.6-35b-a3b",
  "zai-org/GLM-5.1": "glm-5.1",
  "zai-org/GLM-5.1-FP8": "glm-5.1",
  "GLM-5.1": "glm-5.1",
  "z-ai/glm-5.1": "glm-5.1",
  "z-ai:z-ai/glm-5.1": "glm-5.1",
  "Qwen/Qwen3.5-397B-A17B": "qwen-3.5-397b-a17b",
  "qwen3.5-397b-a17b": "qwen-3.5-397b-a17b",
  "qwen/qwen3.5-397b-a17b": "qwen-3.5-397b-a17b",
  "alibaba:qwen/qwen3.5-397b-a17b": "qwen-3.5-397b-a17b",
  "google/gemma-4-26B-A4B-it": "gemma-4-26b-a4b-it",
  "@cf/google/gemma-4-26b-a4b-it": "gemma-4-26b-a4b-it",
  "google/gemma-4-26b-a4b-it:free": "gemma-4-26b-a4b-it",
  "gemma": "gemma-4-26b-a4b-it",
  "openrouter:google/gemma-4-26b-a4b-it:free": "gemma-4-26b-a4b-it",
  "google/gemma-4-31B-it": "gemma-4-31b-it",
  "google/gemma-4-31b-it": "gemma-4-31b-it",
  "google/gemma-4-31b-it:free": "gemma-4-31b-it",
  "gemma-4-31b": "gemma-4-31b-it",
  "togetherai:google/gemma-4-31b-it": "gemma-4-31b-it",
  "nvidia/NVIDIA-Nemotron-3-Super-120B-A12B": "nvidia-nemotron-3-super-120b-a12b",
  "zai-org/GLM-5": "glm-5",
  "z-ai/glm-5": "glm-5",
  "z-ai:z-ai/glm-5": "glm-5",
  "MiniMaxAI/MiniMax-M2.5": "minimax-m2.5",
  "minimax/minimax-m2.5": "minimax-m2.5",
  "minimax:minimax/minimax-m2.5": "minimax-m2.5",
  "Qwen/Qwen3-Max": "qwen-3-max",
  "qwen3-max": "qwen-3-max",
  "qwen3-max-2025-09-26": "qwen-3-max",
  "qwen/qwen3-max": "qwen-3-max",
  "alibaba:qwen/qwen3-max": "qwen-3-max",
  "qwen3-max-2026-01-23": "qwen-3-max",
  "Qwen/Qwen3-Max-Thinking": "qwen-3-max-thinking",
  "qwen3-max-thinking": "qwen-3-max-thinking",
  "qwen/qwen3-max-thinking": "qwen-3-max-thinking",
  "openrouter:qwen/qwen3-max-thinking": "qwen-3-max-thinking",
  "moonshotai/Kimi-K2.5": "kimi-k2.5",
  "moonshotai/kimi-k2.5": "kimi-k2.5",
  "moonshotai:moonshotai/kimi-k2.5": "kimi-k2.5",
  "zai-org/GLM-4.7-Flash": "glm-4.7-flash",
  "@cf/zai-org/glm-4.7-flash": "glm-4.7-flash",
  "z-ai/glm-4.7-flash": "glm-4.7-flash",
  "Catniti/glm-4.7-flash": "glm-4.7-flash",
  "z-ai:z-ai/glm-4.7-flash": "glm-4.7-flash",
  "deepseek-ai/DeepSeek-V3.2": "deepseek-v3.2",
  "deepseek/deepseek-v3.2": "deepseek-v3.2",
  "Minor-fun/deepseek-v3.2": "deepseek-v3.2",
  "openrouter:deepseek/deepseek-v3.2": "deepseek-v3.2",
  "black-forest-labs/FLUX-2-klein-4b": "flux-2-klein-4b",
  "black-forest-labs/FLUX-2-klein-9b": "flux-2-klein-9b",
  "thinkingmachines/Inkling": "inkling",
  "thinkingmachines/inkling": "inkling",
  "togetherai:thinkingmachines/inkling": "inkling",
  "prism-ml/Ternary-Bonsai-27B-gguf": "ternary-bonsai-27b-gguf",
  "Qwen/Qwen3.6-27B": "qwen-3.6-27b",
  "qwen/qwen3.6-27b": "qwen-3.6-27b",
  "qwen3.6-27b": "qwen-3.6-27b",
  "alibaba:qwen/qwen3.6-27b": "qwen-3.6-27b",
  "tencent/Hy3": "hy3",
  "tencent/hy3-preview": "hy3",
  "openrouter:tencent/hy3-preview": "hy3",
  "deepreinforce-ai/Ornith-1.0-35B-FP8": "ornith-1.0-35b",
  "swiss-ai/Apertus-v1.5-70B": "apertus-v1.5-70b",
  "MiniMaxAI/MiniMax-M3": "minimax-m3",
  "MiniMax-M3": "minimax-m3",
  "minimaxai/minimax-m3": "minimax-m3",
  "minimax/minimax-m3": "minimax-m3",
  "minimax": "minimax-m3",
  "minimax:minimax/minimax-m3": "minimax-m3",
  "swiss-ai/Apertus-v1.5-8B": "apertus-v1.5-8b",
  "Qwen/Qwen3.5-9B": "qwen-3.5-9b",
  "qwen/qwen3.5-9b": "qwen-3.5-9b",
  "togetherai:qwen/qwen3.5-9b": "qwen-3.5-9b",
  "Qwen/Qwen3-8B": "qwen-3-8b",
  "qwen3-8b": "qwen-3-8b",
  "qwen/qwen3-8b": "qwen-3-8b",
  "openai/gpt-oss-20b": "gpt-oss-20b",
  "@cf/openai/gpt-oss-20b": "gpt-oss-20b",
  "gpt-oss:20b": "gpt-oss-20b",
  "openai/gpt-oss-20b:free": "gpt-oss-20b",
  "gpt-oss": "gpt-oss-20b",
  "togetherai:openai/gpt-oss-20b": "gpt-oss-20b",
  "Qwen/Qwen3.5-27B": "qwen-3.5-27b",
  "qwen3.5-27b": "qwen-3.5-27b",
  "qwen/qwen3.5-27b": "qwen-3.5-27b",
  "alibaba:qwen/qwen3.5-27b": "qwen-3.5-27b",
  "Qwen/Qwen3-Coder-30B-A3B-Instruct": "qwen-3-coder-30b-a3b",
  "qwen3-coder-30b-a3b": "qwen-3-coder-30b-a3b",
  "qwen/qwen3-coder-30b-a3b-instruct": "qwen-3-coder-30b-a3b",
  "alibaba:qwen/qwen3-coder-30b-a3b-instruct": "qwen-3-coder-30b-a3b",
  "XiaomiMiMo/MiMo-V2.5": "mimo-v2.5",
  "xiaomi/mimo-v2.5": "mimo-v2.5",
  "MarcosFRG/mimo-v2.5": "mimo-v2.5",
  "openrouter:xiaomi/mimo-v2.5": "mimo-v2.5",
  "Qwen/Qwen3-Coder-Next": "qwen-3-coder-next",
  "qwen/qwen3-coder-next": "qwen-3-coder-next",
  "openrouter:qwen/qwen3-coder-next": "qwen-3-coder-next",
  "google/gemma-3-4b-it": "gemma-3-4b-it",
  "openrouter:google/gemma-3-4b-it": "gemma-3-4b-it",
  "Qwen/Qwen3.5-122B-A10B": "qwen-3.5-122b-a10b",
  "qwen3.5-122b-a10b": "qwen-3.5-122b-a10b",
  "qwen/qwen3.5-122b-a10b": "qwen-3.5-122b-a10b",
  "alibaba:qwen/qwen3.5-122b-a10b": "qwen-3.5-122b-a10b",
  "inclusionAI/Ling-2.6-1T": "ling-2.6-1t",
  "inclusionai/ling-2.6-1t": "ling-2.6-1t",
  "openrouter:inclusionai/ling-2.6-1t": "ling-2.6-1t",
  "Qwen/Qwen3-4B-Instruct-2507": "qwen-3-4b-2507",
  "stepfun-ai/Step-3.7-Flash": "step-3.7-flash",
  "stepfun-ai/step-3.7-flash": "step-3.7-flash",
  "stepfun/step-3.7-flash": "step-3.7-flash",
  "step-flash": "step-3.7-flash",
  "openrouter:stepfun/step-3.7-flash": "step-3.7-flash",
  "zai-org/GLM-4.5-Air": "glm-4.5-air",
  "GLM-4.5-Air": "glm-4.5-air",
  "z-ai/glm-4.5-air": "glm-4.5-air",
  "z-ai:z-ai/glm-4.5-air": "glm-4.5-air",
  "Qwen/Qwen3-14B": "qwen-3-14b",
  "qwen3-14b": "qwen-3-14b",
  "qwen/qwen3-14b": "qwen-3-14b",
  "Qwen/Qwen3-Next-80B-A3B-Instruct": "qwen-3-next-80b-a3b",
  "qwen3-next-80b-a3b": "qwen-3-next-80b-a3b",
  "qwen3-next-80b-a3b-instruct": "qwen-3-next-80b-a3b",
  "qwen/qwen3-next-80b-a3b-instruct": "qwen-3-next-80b-a3b",
  "alibaba:qwen/qwen3-next-80b-a3b-instruct": "qwen-3-next-80b-a3b",
  "Qwen/Qwen2.5-Coder-7B-Instruct": "qwen-2.5-coder-7b",
  "openrouter:qwen/qwen2.5-coder-7b-instruct": "qwen-2.5-coder-7b",
  "nvidia/NVIDIA-Nemotron-3-Ultra-550B-A55B-NVFP4": "nvidia-nemotron-3-ultra-550b-a55b-nvfp4",
  "Qwen/Qwen3.5-35B-A3B": "qwen-3.5-35b-a3b",
  "qwen3.5-35b-a3b": "qwen-3.5-35b-a3b",
  "qwen/qwen3.5-35b-a3b": "qwen-3.5-35b-a3b",
  "alibaba:qwen/qwen3.5-35b-a3b": "qwen-3.5-35b-a3b",
  "google/gemma-3-27b-it": "gemma-3-27b-it",
  "openrouter:google/gemma-3-27b-it": "gemma-3-27b-it",
  "google/gemma-3-12b-it": "gemma-3-12b-it",
  "openrouter:google/gemma-3-12b-it": "gemma-3-12b-it",
  "microsoft/phi-4": "phi-4",
  "openrouter:microsoft/phi-4": "phi-4",
  "Qwen/Qwen3-VL-30B-A3B-Instruct": "qwen-3-vl-30b-a3b",
  "qwen3-vl-30b-a3b": "qwen-3-vl-30b-a3b",
  "qwen/qwen3-vl-30b-a3b-instruct": "qwen-3-vl-30b-a3b",
  "openrouter:qwen/qwen3-vl-30b-a3b-instruct": "qwen-3-vl-30b-a3b",
  "prism-ml/Ternary-Bonsai-27B-AWQ-4bit": "ternary-bonsai-27b-awq-4bit",
  "moonshotai/Kimi-K2-Instruct-0905": "kimi-k2-0905",
  "kimi-k2-0905-preview": "kimi-k2-0905",
  "moonshotai/kimi-k2-0905": "kimi-k2-0905",
  "openrouter:moonshotai/kimi-k2-0905": "kimi-k2-0905",
  "Qwen/Qwen2.5-7B-Instruct": "qwen-2.5-7b",
  "hf:Qwen/Qwen2.5-7B-Instruct": "qwen-2.5-7b",
  "qwen/qwen-2.5-7b-instruct": "qwen-2.5-7b",
  "Qwen/Qwen3-VL-235B-A22B-Instruct": "qwen-3-vl-235b-a22b",
  "qwen3-vl-235b-a22b": "qwen-3-vl-235b-a22b",
  "qwen3-vl-235b-a22b-instruct": "qwen-3-vl-235b-a22b",
  "qwen/qwen3-vl-235b-a22b-instruct": "qwen-3-vl-235b-a22b",
  "openrouter:qwen/qwen3-vl-235b-a22b-instruct": "qwen-3-vl-235b-a22b",
  "meta-llama/Llama-3.3-70B-Instruct": "llama-3.3-70b",
  "@cf/meta/llama-3.3-70b-instruct-fp8-fast": "llama-3.3-70b",
  "hf:meta-llama/Llama-3.3-70B-Instruct": "llama-3.3-70b",
  "meta/llama-3.3-70b-instruct": "llama-3.3-70b",
  "meta-llama/llama-3.3-70b-instruct": "llama-3.3-70b",
  "llama": "llama-3.3-70b",
  "Qwen/Qwen3-Coder-480B-A35B-Instruct": "qwen-3-coder-480b-a35b",
  "qwen3-coder-480b-a35b": "qwen-3-coder-480b-a35b",
  "qwen3-coder-480b-a35b-instruct": "qwen-3-coder-480b-a35b",
  "alibaba:qwen/qwen3-coder-480b-a35b-instruct": "qwen-3-coder-480b-a35b",
  "openai/gpt-oss-safeguard-20b": "gpt-oss-safeguard-20b",
  "openrouter:openai/gpt-oss-safeguard-20b": "gpt-oss-safeguard-20b",
  "CohereLabs/c4ai-command-r7b-12-2024": "command-r7b24",
  "command-r7b-12-2024": "command-r7b24",
  "cohere/command-r7b-12-2024": "command-r7b24",
  "Qwen/Qwen3-235B-A22B-Instruct-2507": "qwen-3-235b-a22b-2507",
  "qwen3-235b-a22b-instruct-2507": "qwen-3-235b-a22b-2507",
  "qwen/qwen3-235b-a22b-2507": "qwen-3-235b-a22b-2507",
  "openrouter:qwen/qwen3-235b-a22b-2507": "qwen-3-235b-a22b-2507",
  "meta-llama/Llama-4-Scout-17B-16E-Instruct": "llama-4-scout-17b-16e",
  "llama-4-scout-17b-16e-instruct": "llama-4-scout-17b-16e",
  "stepfun-ai/Step-3.5-Flash": "step-3.5-flash",
  "stepfun-ai/step-3.5-flash": "step-3.5-flash",
  "stepfun/step-3.5-flash": "step-3.5-flash",
  "openrouter:stepfun/step-3.5-flash": "step-3.5-flash",
  "Qwen/Qwen2.5-Coder-3B-Instruct": "qwen-2.5-coder-3b",
  "Sao10K/L3-8B-Stheno-v3.2": "l3-8b-stheno-v3.2",
  "deepseek-ai/DeepSeek-R1-Distill-Qwen-7B": "deepseek-r1-distill-qwen-7b",
  "meta-llama/Llama-Guard-4-12B": "llama-guard-4-12b",
  "meta/llama-guard-4-12b": "llama-guard-4-12b",
  "meta-llama/llama-guard-4-12b": "llama-guard-4-12b",
  "togetherai:meta-llama/llama-guard-4-12b": "llama-guard-4-12b",
  "Qwen/Qwen3-4B-Thinking-2507": "qwen-3-4b-thinking-2507",
  "zai-org/GLM-4.7": "glm-4.7",
  "GLM-4.7": "glm-4.7",
  "z-ai/glm-4.7": "glm-4.7",
  "Catniti/glm-4.7": "glm-4.7",
  "z-ai:z-ai/glm-4.7": "glm-4.7",
  "aisingapore/Gemma-SEA-LION-v4-27B-IT": "gemma-sea-lion-v4-27b-it",
  "CohereLabs/c4ai-command-a-03-2025": "command-a25",
  "deepseek-ai/DeepSeek-R1-Distill-Llama-8B": "deepseek-r1-distill-llama-8b",
  "openrouter:deepseek/deepseek-r1-distill-llama-8b": "deepseek-r1-distill-llama-8b",
  "swiss-ai/Apertus-8B-Instruct-2509": "apertus-8b-2509",
  "CohereLabs/tiny-aya-global": "tiny-aya-global",
  "Qwen/Qwen3-235B-A22B": "qwen-3-235b-a22b",
  "qwen3-235b-a22b": "qwen-3-235b-a22b",
  "qwen/qwen3-235b-a22b": "qwen-3-235b-a22b",
  "alibaba:qwen/qwen3-235b-a22b": "qwen-3-235b-a22b",
  "speakleash/Bielik-11B-v3.0-Instruct": "bielik-11b-v3.0",
  "CohereLabs/tiny-aya-earth": "tiny-aya-earth",
  "MiniMaxAI/MiniMax-M2.7": "minimax-m2.7",
  "MiniMax-M2.7": "minimax-m2.7",
  "minimaxai/minimax-m2.7": "minimax-m2.7",
  "minimax/minimax-m2.7": "minimax-m2.7",
  "minimax:minimax/minimax-m2.7": "minimax-m2.7",
  "meta-llama/Llama-4-Maverick-17B-128E-Instruct-FP8": "llama-4-maverick-17b-128e",
  "meta/llama-4-maverick-17b-128e-instruct": "llama-4-maverick-17b-128e",
  "deepseek-ai/DeepSeek-V3-0324": "deepseek-v3-0324",
  "baidu/ERNIE-4.5-VL-424B-A47B-Base-PT": "ernie-4.5-vl-424b-a47b-base-pt",
  "zai-org/GLM-4-32B-0414": "glm-4-32b-0414",
  "deepseek-ai/DeepSeek-R1-0528": "deepseek-r1-0528",
  "deepseek/deepseek-r1-0528": "deepseek-r1-0528",
  "openrouter:deepseek/deepseek-r1-0528": "deepseek-r1-0528",
  "Qwen/Qwen3-235B-A22B-Thinking-2507": "qwen-3-235b-a22b-thinking-2507",
  "qwen3-235b-a22b-thinking-2507": "qwen-3-235b-a22b-thinking-2507",
  "qwen/qwen3-235b-a22b-thinking-2507": "qwen-3-235b-a22b-thinking-2507",
  "openrouter:qwen/qwen3-235b-a22b-thinking-2507": "qwen-3-235b-a22b-thinking-2507",
  "deepseek-ai/DeepSeek-V3": "deepseek",
  "hf:deepseek-ai/DeepSeek-V3": "deepseek",
  "zai-org/GLM-4.5": "glm-4.5",
  "GLM-4.5": "glm-4.5",
  "z-ai/glm-4.5": "glm-4.5",
  "z-ai:z-ai/glm-4.5": "glm-4.5",
  "zai-org/GLM-4.5V": "glm-4.5v",
  "zai-org/GLM-4.5V-FP8": "glm-4.5v",
  "z-ai/glm-4.5v": "glm-4.5v",
  "z-ai:z-ai/glm-4.5v": "glm-4.5v",
  "alpindale/WizardLM-2-8x22B": "wizardlm-2-8x22b",
  "microsoft/wizardlm-2-8x22b": "wizardlm-2-8x22b",
  "openrouter:microsoft/wizardlm-2-8x22b": "wizardlm-2-8x22b",
  "Qwen/Qwen2.5-72B-Instruct": "qwen-2.5-72b",
  "hf:Qwen/Qwen2.5-72B-Instruct": "qwen-2.5-72b",
  "qwen/qwen-2.5-72b-instruct": "qwen-2.5-72b",
  "zai-org/GLM-4.6": "glm-4.6",
  "z-ai/glm-4.6": "glm-4.6",
  "z-ai:z-ai/glm-4.6": "glm-4.6",
  "zai-org/GLM-4.6V-Flash": "glm-4.6v-flash",
  "MarcosFRG/glm-4.6v-flash": "glm-4.6v-flash",
  "z-ai:z-ai/glm-4.6v-flash": "glm-4.6v-flash",
  "Sao10K/L3-8B-Lunaris-v1": "l3-8b-lunaris",
  "deepseek-ai/DeepSeek-V3.1": "deepseek-v3.1",
  "zai-org/GLM-4.6V-FP8": "glm-4.6v",
  "GLM-4.6V": "glm-4.6v",
  "z-ai/glm-4.6v": "glm-4.6v",
  "z-ai:z-ai/glm-4.6v": "glm-4.6v",
  "MiniMaxAI/MiniMax-M1-80k": "minimax-m1-80k",
  "deepseek-ai/DeepSeek-V3.1-Terminus": "deepseek-v3.1-terminus",
  "deepseek/deepseek-v3.1-terminus": "deepseek-v3.1-terminus",
  "openrouter:deepseek/deepseek-v3.1-terminus": "deepseek-v3.1-terminus",
  "CohereLabs/c4ai-command-r-08-2024": "command-r24",
  "command-r-08-2024": "command-r",
  "cohere/command-r-08-2024": "command-r24",
  "openrouter:cohere/command-r-08-2024": "command-r24",
  "deepseek-ai/DeepSeek-V3.2-Exp": "deepseek-v3.2-exp",
  "deepseek/deepseek-v3.2-exp": "deepseek-v3.2-exp",
  "openrouter:deepseek/deepseek-v3.2-exp": "deepseek-v3.2-exp",
  "CohereLabs/aya-expanse-32b": "aya-expanse-32b",
  "c4ai-aya-expanse-32b": "aya-expanse-32b",
  "CohereLabs/aya-vision-32b": "aya-vision-32b",
  "c4ai-aya-vision-32b": "aya-vision-32b",
  "MiniMaxAI/MiniMax-M2": "minimax-m2",
  "minimax-m2-preview": "minimax-m2",
  "minimax/minimax-m2": "minimax-m2",
  "minimax:minimax/minimax-m2": "minimax-m2",
  "CohereLabs/c4ai-command-r7b-arabic-02-2025": "command-r7b-arabic25",
  "command-r7b-arabic-02-2025": "command-r7b-arabic25",
  "CohereLabs/command-a-vision-07-2025": "command-a-vision25",
  "command-a-vision-07-2025": "command-a-vision25",
  "MiniMaxAI/MiniMax-M2.1": "minimax-m2.1",
  "minimax-m2.1-preview": "minimax-m2.1",
  "minimax/minimax-m2.1": "minimax-m2.1",
  "minimax:minimax/minimax-m2.1": "minimax-m2.1",
  "CohereLabs/command-a-reasoning-08-2025": "command-a-reasoning25",
  "command-a-reasoning-08-2025": "command-a-reasoning25",
  "google/gemma-3n-E4B-it": "gemma-3n-e4b-it",
  "google/gemma-3n-e4b-it": "gemma-3n-e4b-it",
  "togetherai:google/gemma-3n-e4b-it": "gemma-3n-e4b-it",
  "CohereLabs/command-a-translate-08-2025": "command-a-translate25",
  "command-a-translate-08-2025": "command-a-translate25",
  "Qwen/Qwen3-VL-235B-A22B-Thinking": "qwen-3-vl-235b-a22b-thinking",
  "qwen3-vl-235b-a22b-thinking": "qwen-3-vl-235b-a22b-thinking",
  "qwen/qwen3-vl-235b-a22b-thinking": "qwen-3-vl-235b-a22b-thinking",
  "openrouter:qwen/qwen3-vl-235b-a22b-thinking": "qwen-3-vl-235b-a22b-thinking",
  "pearl-ai/Gemma-4-31B-it-pearl": "gemma-4-31b-it-pearl",
  "CohereLabs/tiny-aya-water": "tiny-aya-water",
  "swiss-ai/Apertus-70B-Instruct-2509": "apertus-70b-2509",
  "zai-org/AutoGLM-Phone-9B-Multilingual": "autoglm-phone-9b-multilingual",
  "CohereLabs/tiny-aya-fire": "tiny-aya-fire",
  "aisingapore/Qwen-SEA-LION-v4-32B-IT": "qwen-sea-lion-v4-32b-it",
  "allenai/Olmo-3-7B-Instruct": "olmo-3-7b",
  "utter-project/EuroLLM-22B-Instruct-2512": "eurollm-22b-2512",
  "command-r-plus-08-2024": "command-r-plus24",
  "cohere/command-r-plus-08-2024": "command-r-plus24",
  "openrouter:cohere/command-r-plus-08-2024": "command-r-plus24"
}
