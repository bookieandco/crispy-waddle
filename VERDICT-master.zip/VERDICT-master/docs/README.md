# VERDICT: Tools for architectural and behavioral analysis of AADL models

[OSATE](https://osate.org/about-osate.html) is an Open Source AADL
Tool Environment based on the Eclipse Modeling Tools IDE.  The VERDICT
tools consist of a VERDICT plugin for OSATE and a set of VERDICT
back-end programs invoked by the plugin to perform cyber resiliency
analysis (CRV) and model based architecture analysis (MBAA).  The
plugin has two ways to call the back-end programs; it can run an
executable jar called verdict-bundle-app-\<VERSION\>-capsule.jar in a
subprocess or it can run a Docker image called gehighassurance/verdict
in a temporary container.

## 1. Install OSATE and our VERDICT plugin

Front-end **prerequisites**

- [Java 17](https://adoptium.net/)
- [OSATE 2.10.2](https://osate-build.sei.cmu.edu/download/osate/stable/2.10.2-vfinal/products/)

Maven's Eclipse Tycho build system no longer supports Java 11 so you
will need [Java 17](https://adoptium.net/) to build our VERDICT plugin
source code.  However, you will not need Java 17 to use OSATE with our
VERDICT plugin because VERDICT is compatible with Java 11 and OSATE
uses its own Java 11 bundled inside OSATE to run OSATE anyway.

You will need [OSATE](https://osate.org/about-osate.html) (Open Source
AADL Tool Environment) in order to use our VERDICT plugin:

- Download the [OSATE
  2.10.2](https://osate-build.sei.cmu.edu/download/osate/stable/2.10.2-vfinal/products/)
  product for your operating system.

- If necessary, refer to these [installation
  instructions](https://osate.org/download-and-install.html) to
  install OSATE.

- Start OSATE and open its Install New Software wizard using the
  pulldown menu (Help > Install New Software...).

- Click the Add... button in the Install dialog.

- Paste the following URL in the Location field to install VERDICT's
  latest stable version:

  <https://raw.githubusercontent.com/ge-high-assurance/VERDICT-update-sites/master/verdict-latest>

  If you would rather install VERDICT's most current development
  version, then paste the following URL instead:

  <https://raw.githubusercontent.com/ge-high-assurance/VERDICT-update-sites/master/verdict-dev>

- Click the Finish button in the Install dialog and restart OSATE when
  prompted to do so.

Our VERDICT plugin also requires another OSATE plugin called
[AGREE](https://github.com/loonwerks/AGREE-updates) to be installed in
OSATE.  AGREE is short for "Assume-Guarantee REasoning Environment"
and you can learn more about it at
<https://github.com/loonwerks/AGREE>.  OSATE does not come with AGREE
already installed, so we bundle only the specific parts we need from
the AGREE 2.9.1 plugin in our VERDICT update site to allow you to
install VERDICT in OSATE without having to install AGREE as well.
These bundled AGREE parts work only in OSATE 2.10.2, however.  To be
safer, you can install AGREE in OSATE first before installing VERDICT
by applying the following URL in OSATE's "Install New Software..."
dialog:

<https://loonwerks.github.io/AGREE-Updates>

The above URL will install an AGREE plugin matching your OSATE version
automatically, allowing you to use all of AGREE's functionality or
install VERDICT in earlier or later OSATE versions than OSATE 2.10.2.
We have not tested all combinations, but we have tested that the
current combination of OSATE 2.10.2, AGREE 2.9.1, and VERDICT works
together as well as the previous combination of OSATE 2.7.1, AGREE
2.5.2, and VERDICT.

Note that every released AGREE version works only with one specific
OSATE version and you may find some OSATE versions lack a matching
AGREE version, making these OSATE versions unusable for VERDICT even
though we try to make our VERDICT plugin work with any OSATE and AGREE
version.

## 2. Install the VERDICT back-end tool chain

We support two ways to run the VERDICT back-end programs: Docker image
and native binaries.  Users may choose whichever approach they prefer.
The native binaries work only on current OS X (Catalina 10.15) and
Ubuntu (Focal 20.04) distributions.  The Docker image works on any
platform which can run Docker.

### a. Run the back-end tool chain via Docker

Docker **prerequisites**

- [Docker](https://docs.docker.com/get-docker/)
- [extern.zip](https://github.com/ge-high-assurance/VERDICT/releases)

Install Docker if you haven't installed it yet.  If Docker is already
installed, make sure it is the latest version available for that
platform.  If you are running Docker on Windows, you will also have to
do the following to allow our plugin to communicate with Docker:

- Set an environment variable called DOCKER_HOST to the value
  "tcp://localhost:2375" to tell our plugin to connect to the daemon
  using the daemon's TCP port instead of the daemon's Unix file
  socket.

- Go into Settings in Docker Desktop and enable the checkbox next to
  "Expose daemon on tcp://localhost:2375 without TLS".

- Click the "Apply & Restart" button at the bottom to restart Docker
  after these changes.

If you are running Docker on macOS, you will also have to 
configure the following:

- Click on Resources under Settings, click on FILE SHARING under
  Resources, and add your workspace directory to the list of directories 
  which Docker can bind mount into containers.

- Click the "Apply & Restart" button at the bottom to restart Docker
  after these changes.

Once Docker is installed, you also need to pull a VERDICT Docker image
from Docker Hub to your machine by running one of the following
commands in your terminal depending on whether you want the latest
release image or the most current development image::

```shell
docker pull gehighassurance/verdict:latest
docker pull gehighassurance/verdict-dev:latest
```

Also download the extern.zip archive and unpack it somewhere on your
machine.  You will need some files from the extern folder regardless
of whether you use Docker or native binaries.  After unpacking
extern.zip (make sure you remember the location of the unpacked extern
folder), then configure some VERDICT settings in OSATE:

- Launch OSATE, go to Window (OSATE for macOS) > Preferences > Verdict > Verdict
  Settings, and fill out the following fields.

- Click the Browse... button next to the "STEM Project PATH:" field,
  navigate to the "STEM" folder inside the "extern" folder, and make
  it the field's setting.

- Click within the "Bundle Docker Image:" field and type our Docker
  image's name "gehighassurance/verdict" in that field.

  If you want to use VERDICT's most current development image
  rather than VERDICT's latest release image, then enter the
  following name instead: "gehighassurance/verdict-dev".

- Click the "Apply and Close" button to save all the settings that you
  just entered into the fields.

### b. Run the back-end binaries natively

You can run the VERDICT back-end native binaries on Ubuntu 20.04 and
MacOS 10.15.

Native **prerequisites**

- [extern.zip](https://github.com/ge-high-assurance/VERDICT/releases):
  VERDICT back-end programs
- [GraphViz](https://www.graphviz.org/download/): Graph Visualization Software
- [Z3](https://github.com/Z3Prover/z3): The Z3 Theorem Prover

Make sure both graphviz and z3 are installed under your system path.
On Ubuntu, you would say "sudo apt install graphviz z3".  On MacOS,
you would say "brew install graphviz z3".

Download the extern.zip archive and unpack it somewhere on your
machine.  You will need some files from the extern folder regardless
of whether you use Docker or native binaries.  After unpacking
extern.zip (make sure you remember the location of the unpacked extern
folder), then configure some VERDICT settings in OSATE:

- Launch OSATE, go to Window (OSATE for macOS) > Preferences > Verdict > Verdict
  Settings, and fill out the following fields.

- Click the Browse... button next to the "STEM Project PATH:" field,
  navigate to the "STEM" folder inside the "extern" folder, and make
  it the field's setting.

- Make sure the field "Bundle Docker Image:" stays empty and perform
  the following steps instead.

- Click the Browse... button next to the "Bundle Jar:" field, navigate
  to the "verdict-bundle-app-\<VERSION\>-capsule.jar" file inside the
  "extern" folder, and make it the field's setting.

- Click the Browse... button next to the "Kind2 Binary:" field,
  navigate to the appropriate "kind2" binary for your operating system
  inside either the "extern/mac" or "extern/nix" folders, and make it
  the field's setting.

- Click the Browse... button next to the "Soteria++ Binary:" field,
  navigate to the appropriate "soteria_pp" binary for your operating
  system inside either the "extern/mac" or "extern/nix" folders, and
  make it the field's setting.

- Click the Browse... button next to the "GraphViz Path:" field,
  navigate to the folder on your operating system where your GraphViz
  Graph Visualization software is installed, and make it the field's
  setting. On Ubuntu, that location would be "/usr/bin".

- Click the "Apply and Close" button to save all the settings that you
  just entered into the fields.

## 3. Run VERDICT

Now you are ready to run our VERDICT plugin on an AADL model.  You can
pick one of the example AADL models in the extern.zip file you unpacked
(for example, "extern/examples/DeliveryDrone") and use OSATE's "File >
Import... > General > Existing Projects into Workspace" wizard to
import that model into your OSATE workspace.  You can open the model's
AADL files to see how that model uses AGREE annexes, VERDICT annexes,
and VERDICT properties.

You can invoke VERDICT's functionality from the Verdict pulldown menu 
(in the OSATE application toolbar). First click on a project's name in 
the AADL Navigator pane to make it the currently selected project, then 
pull down the Verdict menu and run the appropriate back-end tools 
(MBAA, MBAS, CRV, etc.). 

Our plugin will use Docker Java API calls to pull the appropriate Docker
image from Docker Hub (only if the image isn't already in your
Docker's local cache), start a temporary Docker container to run the
MBAA or CRV command, and then display any output from that command.
If you use the executable jar instead of the Docker image, the plugin
will run the executable jar in a subprocess directly on your system.
Both the temporary container and the executable jar will run several
VERDICT back-end tool chain programs in additional subprocesses inside
the temporary container or directly on your system as well.

For further information how to analyze a model's system architecture
using our VERDICT tools, please read our VERDICT wiki's
[documentation](https://github.com/ge-high-assurance/VERDICT/wiki).
