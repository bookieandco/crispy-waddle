<?php

/**
 * tirreno ~ open-source security framework
 * Copyright (c) Tirreno Technologies Sàrl (https://www.tirreno.com)
 *
 * Licensed under GNU Affero General Public License version 3 of the or any later version.
 * For full copyright and license information, please see the LICENSE
 * Redistributions of files must retain the above copyright notice.
 *
 * @copyright     Copyright (c) Tirreno Technologies Sàrl (https://www.tirreno.com)
 * @license       https://opensource.org/licenses/AGPL-3.0 AGPL License
 * @link          https://www.tirreno.com Tirreno(tm)
 */

declare(strict_types=1);

return [
    'ips_page_title' => 'IPs',
    'ips_breadcrumb_title' => 'IPs',
    'ips_search_placeholder' => 'IP, ASN, Country or Network operator',
    'users_ip_type_search_placeholder' => '+ Add another IP type',

    'ips_table_title' => 'IP addresses',
    'ips_table_title_tooltip' => 'This page outputs information grouped by IP address. The data is shown for a selected period of time. To open a page with more details, click on a table row. The chart shows the number of the residential (considered safe) and non-residential (considered a warning signal) IP addresses from which the requests were made each day.',

    'ips_map_title' => 'Locations & connections',
];
