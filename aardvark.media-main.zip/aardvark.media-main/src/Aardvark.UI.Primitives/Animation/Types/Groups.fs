﻿namespace Aardvark.UI.Animation

open Aardvark.Base

[<CompilationRepresentation(CompilationRepresentationFlags.ModuleSuffix)>]
module internal Groups =

    [<Struct>]
    type Segment =
        { Start : LocalTime; End : LocalTime }

    [<CompilationRepresentation(CompilationRepresentationFlags.ModuleSuffix)>]
    module Segment =

        let create (s : LocalTime) (e : LocalTime) =
            { Start = s; End = e}

        let ofDuration (d : Duration) =
            { Start = LocalTime.zero; End = LocalTime.ofDuration d }


    /// Computes the duration scale for the group animation
    let scale (duration : Duration) (animation : IAnimation<'Model>) =
        if animation.Duration.IsZero then
            Log.warn "[Animation] Cannot scale composite animation with zero duration"
            1.0
        else
            duration / animation.Duration

    /// Applies the distance-time function of the animation to the given time stamp.
    let applyDistanceTimeToLocalTime (localTime : LocalTime) (animation : IAnimation) =
        let duration = animation.Duration
        if duration.IsFinite then
            let t = animation.DistanceTime(localTime)
            t |> LocalTime.ofNormalizedPosition duration
        else
            localTime

    /// Applies the distance-time function of the animation to time stamps contained in the given action.
    let applyDistanceTimeToAction (action : Action) (animation : IAnimation) =
        match action with
        | Action.Start startFrom ->
            let startFrom = startFrom |> clamp LocalTime.zero animation.FinalPosition
            Action.Start (applyDistanceTimeToLocalTime startFrom animation)

        | Action.Update (time, finalize) ->
            Action.Update (applyDistanceTimeToLocalTime time animation, finalize)

        | _ ->
            action

    /// Performs a group action for the given member.
    let perform (segment : Segment) (action : Action) (group : IAnimationInstance<'Model>) (animation : IAnimationInstance<'Model>) =
        let isFirstSegment = (segment.Start = LocalTime.zero)
        let isLastSegment = (segment.End = LocalTime.ofDuration group.Duration)

        let inBounds t =
            (t >= segment.Start || isFirstSegment) && (t < segment.End || isLastSegment)

        let localBoundary start =
            if start then LocalTime.zero else segment.End - segment.Start

        // Start the member if inbounds, stop if out of bounds
        let start groupLocalTime =
            if inBounds groupLocalTime then
                animation.Perform <| Action.Start (groupLocalTime - segment.Start)
            else
                animation.Perform Action.Stop

        // Update the member if inbounds (start if necessary), finalize otherwise
        let update groupLocalTime finalize =
            if inBounds groupLocalTime then
                let localTime = groupLocalTime - segment.Start

                if animation.IsRunning then
                    animation.Perform <| Action.Update (localTime, finalize)
                else
                    let startTime = localBoundary (group.Position < groupLocalTime)
                    animation.Perform <| Action.Start startTime
                    animation.Perform <| Action.Update (startTime, false)

                    if startTime <> localTime then
                        animation.Perform <| Action.Update (localTime, false)
            else
                let endTime = localBoundary (group.Position > groupLocalTime)
                animation.Perform <| Action.Update (endTime, true)

        match action with
        | Action.Start groupLocalTime ->
            start groupLocalTime

        | Action.Update (groupLocalTime, finalize) when group.IsRunning ->
            update groupLocalTime finalize

        | _ ->
            ()