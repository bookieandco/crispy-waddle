import Foundation
#if PRODUCTION_TELEMETRY
import PostHog
#endif

enum Analytics {
    typealias Payload = [String: Any]

    struct Origin: Sendable {
        let source: String
        let sessionID: String
    }

    /// Attributes synchronous work started by the agent or an MCP client.
    @TaskLocal static var origin: Origin?

    static let manualSource = "manual"

    static func originProperties() -> Payload {
        guard let origin else { return ["source": manualSource] }
        return ["source": origin.source, "session_id": origin.sessionID]
    }

    struct SessionActivation {
        private(set) var isActivated: Bool

        init(isActivated: Bool = false) {
            self.isActivated = isActivated
        }

        mutating func activate() -> Bool {
            guard !isActivated else { return false }
            isActivated = true
            return true
        }
    }

    enum Event: String, CaseIterable {
        case appOpened = "app opened"
        case projectCreated = "project created"
        case projectOpened = "project opened"
        case projectActive = "project active"
        case exportStarted = "export started"
        case exportFinished = "export finished"
        case exportFailed = "export failed"
        case agentSessionStarted = "agent session started"
        case agentToolCalled = "agent tool called"
        case agentStarterPromptClicked = "agent starter prompt clicked"
        case editorEditCommitted = "editor edit committed"
        case generationSubmitted = "generation submitted"
        case mcpSessionActivated = "mcp session activated"
        case onboardingCompleted = "onboarding completed"
    }

    #if PRODUCTION_TELEMETRY
    private static let projectToken = Bundle.main.object(forInfoDictionaryKey: "PostHogProjectToken") as? String ?? ""
    private static let host = Bundle.main.object(forInfoDictionaryKey: "PostHogHost") as? String ?? PostHogConfig.defaultHost
    private static let captureQueue = DispatchQueue(label: "io.palmier.pro.analytics.capture")
    #endif
    private static let enabledKey = "io.palmier.pro.analytics.enabled"

    static var isEnabled: Bool {
        get {
            let defaults = UserDefaults.standard
            if defaults.object(forKey: enabledKey) == nil { return true }
            return defaults.bool(forKey: enabledKey)
        }
        set {
            UserDefaults.standard.set(newValue, forKey: enabledKey)
            #if PRODUCTION_TELEMETRY
            guard didStart else { return }
            if newValue {
                PostHogSDK.shared.optIn()
            } else {
                PostHogSDK.shared.optOut()
            }
            #endif
        }
    }

    static let enabledForCurrentLaunch: Bool = isEnabled

    nonisolated(unsafe) private static var didStart = false
    nonisolated(unsafe) private static var activeProjectMarks: Set<String> = []
    private static let lock = NSLock()

    static var canCapture: Bool {
        #if PRODUCTION_TELEMETRY
        didStart && isEnabled
        #else
        false
        #endif
    }

    static func start() {
        #if PRODUCTION_TELEMETRY
        guard !didStart else { return }
        guard !projectToken.isEmpty else { return }

        let config = PostHogConfig(projectToken: projectToken, host: host)
        config.optOut = !enabledForCurrentLaunch
        config.captureApplicationLifecycleEvents = false
        config.captureScreenViews = false
        config.enableSwizzling = false
        config.preloadFeatureFlags = false
        config.sendFeatureFlagEvent = false
        config.setDefaultPersonProperties = false
        config.errorTrackingConfig.autoCapture = false
        config.errorTrackingConfig.exceptionSteps.enabled = false
        config.setBeforeSend { event in
            guard Self.allowedEvents.contains(event.event) else { return nil }
            event.properties = Self.allowedProperties(for: event.event, properties: event.properties)
            return event
        }

        PostHogSDK.shared.setup(config)
        didStart = true
        #endif
    }

    static func identifyUser(id: String?, properties: Payload = [:]) {
        #if PRODUCTION_TELEMETRY
        guard didStart, isEnabled else { return }
        guard let id, !id.isEmpty else { return }
        let userProperties = cleanedCustomPayload(properties)
        PostHogSDK.shared.identify(id, userProperties: userProperties.isEmpty ? nil : userProperties)
        #endif
    }

    static func resetUser() {
        #if PRODUCTION_TELEMETRY
        guard didStart else { return }
        PostHogSDK.shared.reset()
        #endif
    }

    @discardableResult
    static func capture(_ event: Event, properties: Payload = [:]) -> Bool {
        #if PRODUCTION_TELEMETRY
        guard canCapture else { return false }
        let properties = cleanedPayload(properties)
        guard let data = try? JSONSerialization.data(withJSONObject: properties) else { return false }
        captureQueue.async {
            guard let properties = try? JSONSerialization.jsonObject(with: data) as? Payload else { return }
            PostHogSDK.shared.capture(event.rawValue, properties: properties)
        }
        return true
        #else
        return false
        #endif
    }

    static func captureProjectActive(projectId: String?, properties: Payload = [:]) {
        let day = Self.dayString(Date())
        let id = projectId ?? "unknown"
        let key = "\(day):\(id)"
        lock.lock()
        let shouldCapture = activeProjectMarks.insert(key).inserted
        lock.unlock()
        guard shouldCapture else { return }
        var payload = properties
        payload["active_day"] = day
        if !capture(.projectActive, properties: payload) {
            lock.lock()
            activeProjectMarks.remove(key)
            lock.unlock()
        }
    }

    private static let allowedEvents = Set(Event.allCases.map(\.rawValue)).union(["$identify"])

    private static func cleanedPayload(_ payload: Payload) -> Payload {
        var out: Payload = [:]
        for (key, value) in payload {
            guard let clean = clean(value) else { continue }
            out[key] = clean
        }
        return out
    }

    private static func cleanedCustomPayload(_ payload: Payload) -> Payload {
        var out: Payload = [:]
        for (key, value) in payload {
            guard let clean = clean(value) else { continue }
            out[key] = clean
        }
        return out
    }

    private static func allowedProperties(for event: String, properties: Payload) -> Payload {
        if event == "$identify" {
            return allowedIdentifyProperties(properties)
        }
        let allowed = allowedCapturePropertyKeys
        return properties.reduce(into: Payload()) { out, entry in
            guard allowed.contains(entry.key), let clean = clean(entry.value) else { return }
            out[entry.key] = clean
        }
    }

    private static func allowedIdentifyProperties(_ properties: Payload) -> Payload {
        var out: Payload = [:]
        for key in ["distinct_id", "$anon_distinct_id", "$process_person_profile"] {
            guard let value = properties[key], let clean = clean(value) else { continue }
            out[key] = clean
        }
        if let set = properties["$set"] as? Payload {
            var allowedSet: Payload = [:]
            if let tier = set["tier"], let clean = clean(tier) {
                allowedSet["tier"] = clean
            }
            if !allowedSet.isEmpty {
                out["$set"] = allowedSet
            }
        }
        return out
    }

    private static var allowedCapturePropertyKeys: Set<String> {
        Set([
            "active_day",
            "caption_clip_count",
            "caption_group_count",
            "clip_count",
            "client_info",
            "error_message",
            "export_duration_seconds",
            "export_filename",
            "failure_reason",
            "format",
            "generated_visual_clip_count",
            "generated_visual_clip_ratio",
            "generated_visual_duration_ratio",
            "generation_type",
            "imported_visual_clip_count",
            "interests",
            "mode",
            "model",
            "output_count",
            "project_id",
            "resolution",
            "roles",
            "session_id",
            "source",
            "starter_prompt",
            "status",
            "survey_version",
            "timeline_count",
            "timeline_changed",
            "timeline_snapshot",
            "timeline_snapshot_schema",
            "track_count",
            "tool_name",
            "tool_duration_seconds",
            "upscaled_visual_clip_count",
            "video_types",
            "visual_clip_count",
        ])
    }

    static func clean(_ value: Any) -> Any? {
        switch value {
        case let value as String:
            return value
        case let value as NSNumber:
            if CFGetTypeID(value) == CFBooleanGetTypeID() {
                return value.boolValue
            }
            guard value.doubleValue.isFinite else { return nil }
            return value
        case let value as [String: Any]:
            var out: [String: Any] = [:]
            for (key, child) in value {
                guard let clean = clean(child) else { continue }
                out[key] = clean
            }
            return out
        case let value as [Any]:
            return value.compactMap(clean)
        default:
            return nil
        }
    }

    private static func dayString(_ date: Date) -> String {
        let components = Calendar.current.dateComponents([.year, .month, .day], from: date)
        guard let year = components.year, let month = components.month, let day = components.day else {
            return "unknown"
        }
        return String(format: "%04d-%02d-%02d", year, month, day)
    }
}
