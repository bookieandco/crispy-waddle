<?php

/**
 * tirreno ~ open-source security framework
 * Copyright (c) Tirreno Technologies Sàrl (https://www.tirreno.com)
 *
 * Licensed under GNU Affero General Public License version 3 of the or any later version.
 * For full copyright and license information, please see the LICENSE
 * Redistributions of files must retain the above copyright notice.
 *
 * @copyright     Copyright (c) Tirreno Technologies Sàrl (https://www.tirreno.com)
 * @license       https://opensource.org/licenses/AGPL-3.0 AGPL License
 * @link          https://www.tirreno.com Tirreno(tm)
 */

declare(strict_types=1);

return [
    'ips_map_title_tooltip' => 'Information detected by IP addresses assigned to the ISP. The map visualizes the geolocated countries along with the number of events reported for the ISP.',
    'users_table_title_tooltip' => 'A list of entities associated with the ISP.',
    'events_table_title_tooltip' => 'A list of events recorded for the ISP. The chart shows the number of events reported each day.',
];
