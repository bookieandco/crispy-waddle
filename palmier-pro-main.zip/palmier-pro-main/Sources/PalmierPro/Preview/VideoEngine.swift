import AVFoundation
import AppKit
import CoreImage

enum PreviewSeekMode: String {
    case exact
    case interactiveScrub
    case audibleStepForward
    case audibleStepBackward
}

@MainActor
final class VideoEngine {
    enum VisualRefreshAction: Equatable {
        case meterPlayback
        case seekToActiveFrame
        case none
    }

    private(set) var player = AVPlayer()
    private let scrubAudioEngine: ScrubAudioEngine

    weak var previewView: PreviewNSView?

    weak var editor: EditorViewModel?

    private var timeObserver: Any?
    private var playbackEndObserver: NSObjectProtocol?
    private(set) var rebuildTask: Task<Void, Never>?
    private var rebuildGeneration = 0
    private(set) var sourcePreviewTask: Task<Void, Never>?
    private var sourcePreviewGeneration = 0
    private var sourceTrackStart: CMTime = .zero

    private enum SourcePreviewError: LocalizedError {
        case noVideoTrack
        case invalidTimeRange

        var errorDescription: String? {
            switch self {
            case .noVideoTrack: "No video track is available."
            case .invalidTimeRange: "The video track has no valid duration."
            }
        }
    }

    private var trackMappings: [TrackMapping] = []
    private var clipNaturalSizes: [String: CGSize] = [:]
    private var resolveTimelineSnapshot: @Sendable (String) -> Timeline? = { _ in nil }
    private var clipTransforms: [String: CGAffineTransform] = [:]
    private var compositionDuration: CMTime = .zero

    private var pendingInteractiveSeek: (time: CMTime, tolerance: CMTime)?
    private var interactiveThrottleTask: Task<Void, Never>?
    private var lastInteractiveDispatchTime: TimeInterval = 0

    init(editor: EditorViewModel) {
        self.editor = editor
        scrubAudioEngine = ScrubAudioEngine(meter: editor.audioMeter)
        player.defaultRate = editor.playbackRate.rawValue
        installTimeObserver(for: editor.playbackRate)
        installPlaybackEndObserver()
    }

    func teardown() {
        invalidateRebuild()
        cancelSourcePreviewLoad()
        compositionCache.removeAll()
        invalidateSeekState()
        scrubAudioEngine.teardown()
        if let timeObserver { player.removeTimeObserver(timeObserver) }
        timeObserver = nil
        if let playbackEndObserver { NotificationCenter.default.removeObserver(playbackEndObserver) }
        playbackEndObserver = nil
    }

    // MARK: - Playback

    func setPlaybackRate(_ rate: PreviewPlaybackRate) {
        player.defaultRate = rate.rawValue
        installTimeObserver(for: rate)
        if !rate.allowsAudioMetering {
            scrubAudioEngine.stopPlaybackMetering()
        }
        if editor?.isPlaying == true, player.timeControlStatus != .paused {
            player.rate = rate.rawValue
        }
    }

    func play() {
        guard let editor else { return }
        scrubAudioEngine.stopScrubbing()
        editor.isPlaying = true
        guard rebuildTask == nil, sourcePreviewTask == nil else { return }
        let frame = playbackStartFrame(for: editor)
        seek(to: frame, mode: .exact)
        player.play()
    }

    func pause() {
        scrubAudioEngine.stopScrubbing()
        editor?.isPlaying = false
        player.pause()
    }

    func resumePlayback() {
        scrubAudioEngine.stopScrubbing()
        editor?.isPlaying = true
        guard sourcePreviewTask == nil else { return }
        player.play()
    }

    func togglePlayback() {
        if editor?.isPlaying == true { pause() } else { play() }
    }

    func seek(to frame: Int, mode: PreviewSeekMode = .exact) {
        guard let editor else { return }

        let time = SourceMediaTimebase.absoluteTime(
            relativeFrame: frame,
            fps: editor.timeline.fps,
            trackStart: sourceTrackStart
        )
        let tolerance: CMTime = mode == .interactiveScrub
            ? interactiveTolerance(activeLayerCount: activeVideoLayerCount(at: frame, editor: editor))
            : .zero

        switch mode {
        case .exact:
            scrubAudioEngine.stopScrubbing()
            cancelInteractiveSeek()
            performSeek(time: time, tolerance: tolerance)
        case .interactiveScrub:
            scrubAudioEngine.scrub(to: time)
            enqueueInteractiveSeek(time: time, tolerance: tolerance)
        case .audibleStepForward, .audibleStepBackward:
            if editor.isPlaying { pause() }
            scrubAudioEngine.scrub(to: time, movingForward: mode == .audibleStepForward)
            cancelInteractiveSeek()
            performSeek(time: time, tolerance: tolerance)
        }
    }

    // MARK: - Preview Items

    func previewAsset(_ asset: MediaAsset) {
        cancelSourcePreviewLoad()
        if asset.type == .lottie {
            // AVPlayer can't read Lottie JSON — bake (cached) to a playable mov first.
            let url = asset.url, ref = asset.id
            let size = CGSize(width: asset.sourceWidth ?? 512, height: asset.sourceHeight ?? 512)
            let startFrame = editor?.sourcePlayheadFrame ?? 0
            Task { @MainActor [weak self] in
                guard let self, let mov = try? await LottieVideoGenerator.lottieVideo(for: url, mediaRef: ref, size: size) else { return }
                guard case .mediaAsset(let activeId, _, _) = self.editor?.activePreviewTab, activeId == ref else { return }
                self.replacePlayerItem(AVPlayerItem(url: mov), reason: "previewLottie")
                self.seek(to: startFrame, mode: .exact)
            }
            return
        }
        if asset.type == .video {
            loadSourcePreview(id: asset.id, url: asset.url)
            return
        }
        replacePlayerItem(AVPlayerItem(url: asset.url), reason: "previewAsset")
    }

    private func loadSourcePreview(id: String, url: URL) {
        let generation = sourcePreviewGeneration
        replacePlayerItem(nil, reason: "previewAssetLoading")
        sourcePreviewTask = Task { @MainActor [weak self] in
            guard let self else { return }
            var shouldPause = false
            defer {
                if generation == self.sourcePreviewGeneration {
                    self.sourcePreviewTask = nil
                    if shouldPause { self.pause() }
                }
            }
            let trackStart: CMTime
            do {
                trackStart = try await Self.loadVideoTrackStart(url: url)
            } catch {
                guard !Task.isCancelled,
                      self.isCurrentSourcePreview(id: id, url: url, generation: generation) else { return }
                shouldPause = true
                Log.preview.warning(
                    "source preview timing load failed asset=\(id.prefix(8)): \(error.localizedDescription)"
                )
                return
            }
            guard !Task.isCancelled,
                  self.isCurrentSourcePreview(id: id, url: url, generation: generation) else { return }
            self.replacePlayerItem(
                AVPlayerItem(url: url),
                reason: "previewAsset",
                sourceTrackStart: trackStart
            )
            guard let editor = self.editor else { return }
            let time = SourceMediaTimebase.absoluteTime(
                relativeFrame: editor.playheadState.sourceFrame,
                fps: editor.timeline.fps,
                trackStart: trackStart
            )
            let didSeek = await self.seekPlayer(to: time)
            guard !Task.isCancelled,
                  self.isCurrentSourcePreview(id: id, url: url, generation: generation) else { return }
            shouldPause = !didSeek
            if didSeek, editor.isPlaying { self.player.play() }
        }
    }

    func activateTab(_ tab: PreviewTab) {
        guard let editor else { return }
        invalidateRebuild()
        cancelSourcePreviewLoad()
        sourceTrackStart = .zero
        invalidateSeekState()
        pause()

        switch tab {
        case .timeline:
            rebuild()
        case .mediaAsset(let id, _, let type):
            guard let asset = editor.mediaAssets.first(where: { $0.id == id }) else { return }
            if type == .image {
                replacePlayerItem(nil, reason: "imagePreview")
            } else {
                previewAsset(asset)
                seek(to: editor.sourcePlayheadFrame, mode: .exact)
            }
        }
    }

    private func replacePlayerItem(
        _ item: AVPlayerItem?,
        reason: String,
        sourceTrackStart: CMTime = .zero
    ) {
        invalidateSeekState()
        self.sourceTrackStart = sourceTrackStart
        scrubAudioEngine.configure(asset: item?.asset, audioMix: item?.audioMix)
        player.replaceCurrentItem(with: item)
        Log.preview.debug("seek state invalidated reason=\(reason)")
    }

    @concurrent
    private static func loadVideoTrackStart(url: URL) async throws -> CMTime {
        let asset = AVURLAsset(url: url)
        guard let track = try await asset.loadTracks(withMediaType: .video).first else {
            throw SourcePreviewError.noVideoTrack
        }
        let timeRange = try await track.load(.timeRange)
        try Task.checkCancellation()
        guard timeRange.isValid,
              timeRange.start.isNumeric,
              timeRange.duration.isNumeric,
              timeRange.duration > .zero else { throw SourcePreviewError.invalidTimeRange }
        return timeRange.start
    }

    // The URL check catches in-place asset replacement, which doesn't bump the generation.
    private func isCurrentSourcePreview(id: String, url: URL, generation: Int) -> Bool {
        guard generation == sourcePreviewGeneration,
              case .mediaAsset(let activeId, _, _) = editor?.activePreviewTab,
              activeId == id,
              editor?.mediaAssets.first(where: { $0.id == id })?.url == url else { return false }
        return true
    }

    private func cancelSourcePreviewLoad() {
        sourcePreviewTask?.cancel()
        sourcePreviewTask = nil
        sourcePreviewGeneration &+= 1
    }

    // MARK: - Composition

    /// Everything CompositionBuilder.build reads; equal inputs → identical composition.
    private struct RebuildInputs: Equatable {
        let involved: [Timeline]  // active timeline plus nested children
        let mediaURLs: [String: URL]
        let assetSizes: [String: CGSize]
        let missingMediaRefs: Set<String>
    }

    func rebuild() {
        guard let editor, editor.activePreviewTab == .timeline else { return }
        let generation = invalidateRebuild()

        let mediaURLs = editor.mediaResolver.expectedURLMap()
        let missingMediaRefs = editor.missingMediaRefs
        let assetSizes: [String: CGSize] = Dictionary(
            uniqueKeysWithValues: editor.mediaAssets.compactMap { asset in
                guard let w = asset.sourceWidth, let h = asset.sourceHeight, w > 0, h > 0 else { return nil }
                return (asset.id, CGSize(width: w, height: h))
            }
        )
        let resolveTimeline = editor.timelineResolver()

        let timelineId = editor.timeline.id
        let inputs = RebuildInputs(
            involved: [editor.timeline] + editor.timeline.reachableTimelines(resolve: { editor.timeline(for: $0) }),
            mediaURLs: mediaURLs,
            assetSizes: assetSizes,
            missingMediaRefs: missingMediaRefs
        )
        if let cached = compositionCache[timelineId], cached.inputs == inputs {
            apply(cached.result, resolveTimeline: resolveTimeline, editor: editor)
            return
        }

        let snapshot = inputs.involved[0]
        rebuildTask = Task {
            let result: CompositionResult
            do {
                result = try await CompositionBuilder.build(
                    timeline: snapshot,
                    resolveURL: { mediaURLs[$0] },
                    resolveSourceSize: { assetSizes[$0] },
                    resolveTimeline: resolveTimeline,
                    missingMediaRefs: missingMediaRefs,
                    renderSize: CGSize(width: snapshot.width, height: snapshot.height)
                )
            } catch {
                guard generation == rebuildGeneration else { return }
                rebuildTask = nil
                if !Task.isCancelled {
                    Log.preview.error("rebuild failed: \(error.localizedDescription)")
                }
                return
            }

            guard generation == rebuildGeneration else { return }
            rebuildTask = nil
            guard !Task.isCancelled else { return }

            if result.offlineMediaRefs.isEmpty && result.unprocessableMediaRefs.isEmpty {
                compositionCache[timelineId] = (inputs, result)
            }
            compositionCache = compositionCache.filter { editor.openTimelineIds.contains($0.key) }
            apply(result, resolveTimeline: resolveTimeline, editor: editor)
        }
    }

    @discardableResult
    private func invalidateRebuild() -> Int {
        rebuildGeneration &+= 1
        rebuildTask?.cancel()
        rebuildTask = nil
        return rebuildGeneration
    }

    private var compositionCache: [String: (inputs: RebuildInputs, result: CompositionResult)] = [:]

    func evictComposition(for timelineId: String) {
        compositionCache.removeValue(forKey: timelineId)
    }

    private func apply(_ result: CompositionResult, resolveTimeline: @escaping @Sendable (String) -> Timeline?, editor: EditorViewModel) {
        trackMappings = result.trackMappings
        clipNaturalSizes = result.clipNaturalSizes
        clipTransforms = result.clipTransforms
        compositionDuration = result.composition.duration
        resolveTimelineSnapshot = resolveTimeline
        editor.offlineMediaRefs = result.offlineMediaRefs
        editor.unprocessableMediaRefs = result.unprocessableMediaRefs

        let item = AVPlayerItem(asset: result.composition)
        item.audioMix = result.audioMix
        item.videoComposition = result.videoComposition
        replacePlayerItem(item, reason: "rebuild")

        seek(to: editor.currentFrame, mode: .exact)
        if editor.isPlaying { player.play() }
    }

    func refreshVisuals() {
        guard let editor, editor.activePreviewTab == .timeline,
              let currentItem = player.currentItem,
              !trackMappings.isEmpty else {
            rebuild()
            return
        }

        let (audioMix, videoComposition) = CompositionBuilder.buildVisuals(
            timeline: editor.timeline,
            trackMappings: trackMappings,
            clipNaturalSizes: clipNaturalSizes,
            clipTransforms: clipTransforms,
            resolveTimeline: resolveTimelineSnapshot,
            compositionDuration: compositionDuration,
            renderSize: CGSize(width: editor.timeline.width, height: editor.timeline.height)
        )
        currentItem.audioMix = audioMix
        currentItem.videoComposition = videoComposition
        scrubAudioEngine.configure(asset: currentItem.asset, audioMix: audioMix, resetMeter: false)
        switch Self.visualRefreshAction(isPlaying: editor.isPlaying, playbackRate: editor.playbackRate) {
        case .meterPlayback:
            scrubAudioEngine.meterPlayback(at: player.currentTime())
        case .seekToActiveFrame:
            guard let time = playerTime(forPreviewFrame: editor.activeFrame) else { return }
            cancelInteractiveSeek()
            performSeek(time: time, tolerance: .zero)
        case .none:
            break
        }
    }

    // MARK: - Scopes

    /// Luma + per-channel histogram of the current composited frame (downsampled), normalized 0…1.
    func histogramYRGB(frame: Int? = nil, count: Int = 256) async
        -> (y: [Float], r: [Float], g: [Float], b: [Float])? {
        guard let item = player.currentItem,
              (try? await item.asset.loadTracks(withMediaType: .video).first) != nil else { return nil }
        let time = frame.flatMap(playerTime(forPreviewFrame:)) ?? player.currentTime()
        let generator = AVAssetImageGenerator(asset: item.asset)
        generator.videoComposition = item.videoComposition
        generator.requestedTimeToleranceBefore = .zero
        generator.requestedTimeToleranceAfter = .zero
        generator.maximumSize = CGSize(width: 320, height: 180)
        guard let cg = try? await generator.image(at: time).image else { return nil }
        return Self.histogram(from: cg, count: count)
    }

    /// Normalized luma + RGB bins; luma needs its own pass (per-pixel 709 mix). Testable without a player.
    nonisolated static func histogram(from cg: CGImage, count: Int = 256)
        -> (y: [Float], r: [Float], g: [Float], b: [Float])? {
        let image = CIImage(cgImage: cg)
        let extent = image.extent
        guard extent.width > 0, extent.height > 0 else { return nil }
        let ext = CIVector(cgRect: extent)

        func bins(_ img: CIImage) -> [Float] {
            let hist = img.applyingFilter("CIAreaHistogram", parameters: [
                kCIInputExtentKey: ext, "inputScale": 1.0, "inputCount": count,
            ])
            var raw = [Float](repeating: 0, count: count * 4)
            ColorScopes.context.render(
                hist, toBitmap: &raw, rowBytes: count * 4 * MemoryLayout<Float>.size,
                bounds: CGRect(x: 0, y: 0, width: count, height: 1), format: .RGBAf, colorSpace: nil)
            return raw
        }

        // Rec.709 luma collapsed into every channel, so its histogram lives in R.
        let lumaVec = CIVector(x: 0.2126, y: 0.7152, z: 0.0722, w: 0)
        let luma = image.applyingFilter("CIColorMatrix", parameters: [
            "inputRVector": lumaVec, "inputGVector": lumaVec, "inputBVector": lumaVec,
            "inputAVector": CIVector(x: 0, y: 0, z: 0, w: 1),
        ])
        let rgbRaw = bins(image)
        let lumaRaw = bins(luma)

        var y = [Float](repeating: 0, count: count), r = y, g = y, b = y
        var maxV: Float = 0
        for i in 0..<count {
            y[i] = lumaRaw[i * 4]
            r[i] = rgbRaw[i * 4]; g[i] = rgbRaw[i * 4 + 1]; b[i] = rgbRaw[i * 4 + 2]
            maxV = max(maxV, max(y[i], max(r[i], max(g[i], b[i]))))
        }
        if maxV > 0 { for i in 0..<count { y[i] /= maxV; r[i] /= maxV; g[i] /= maxV; b[i] /= maxV } }
        return (y, r, g, b)
    }

    /// Hue distribution of the current composited frame — pixel count per hue bucket, weighted by
    /// saturation so achromatic pixels don't show. Drives the silhouette behind the hue curves.
    func hueHistogram(frame: Int? = nil, count: Int = 96) async -> [Float]? {
        guard let item = player.currentItem,
              (try? await item.asset.loadTracks(withMediaType: .video).first) != nil else { return nil }
        let time = frame.flatMap(playerTime(forPreviewFrame:)) ?? player.currentTime()
        let generator = AVAssetImageGenerator(asset: item.asset)
        generator.videoComposition = item.videoComposition
        generator.requestedTimeToleranceBefore = .zero
        generator.requestedTimeToleranceAfter = .zero
        generator.maximumSize = CGSize(width: 320, height: 180)
        guard let cg = try? await generator.image(at: time).image else { return nil }
        return Self.hueHistogram(from: cg, count: count)
    }

    /// Saturation-weighted hue histogram; sqrt-compressed so small humps stay visible. Testable.
    nonisolated static func hueHistogram(from cg: CGImage, count: Int = 96) -> [Float]? {
        let w = cg.width, h = cg.height
        guard w > 0, h > 0 else { return nil }
        var px = [UInt8](repeating: 0, count: w * h * 4)
        guard let ctx = px.withUnsafeMutableBytes({ ptr in
            CGContext(data: ptr.baseAddress, width: w, height: h, bitsPerComponent: 8,
                      bytesPerRow: w * 4, space: CGColorSpaceCreateDeviceRGB(),
                      bitmapInfo: CGImageAlphaInfo.premultipliedLast.rawValue)
        }) else { return nil }
        ctx.draw(cg, in: CGRect(x: 0, y: 0, width: w, height: h))

        var bins = [Float](repeating: 0, count: count)
        var i = 0
        while i < px.count {
            let r = Float(px[i]) / 255, g = Float(px[i + 1]) / 255, b = Float(px[i + 2]) / 255
            i += 4
            let mx = max(r, max(g, b)), mn = min(r, min(g, b)), d = mx - mn
            guard d > 1e-4, mx > 1e-4 else { continue }
            var hue: Float = mx == r ? (g - b) / d : (mx == g ? (b - r) / d + 2 : (r - g) / d + 4)
            hue = (hue / 6).truncatingRemainder(dividingBy: 1); if hue < 0 { hue += 1 }
            bins[min(count - 1, Int(hue * Float(count)))] += d / mx
        }
        var maxV: Float = 0; for v in bins { maxV = max(maxV, v) }
        if maxV > 0 { for j in 0..<count { bins[j] = (bins[j] / maxV).squareRoot() } }
        return bins
    }

    func sampleKeyHue(at normalizedPoint: CGPoint, frame: Int? = nil) async -> Double? {
        guard let item = player.currentItem,
              (try? await item.asset.loadTracks(withMediaType: .video).first) != nil else { return nil }
        let time = frame.flatMap(playerTime(forPreviewFrame:)) ?? player.currentTime()
        let generator = AVAssetImageGenerator(asset: item.asset)
        generator.videoComposition = item.videoComposition
        guard let cg = try? await generator.image(at: time).image else { return nil }
        return Self.sampleKeyHue(from: cg, at: normalizedPoint)
    }

    nonisolated static func sampleKeyHue(
        from cg: CGImage,
        at normalizedPoint: CGPoint,
    ) -> Double? {
        let image = CIImage(cgImage: cg)
        let center = CGPoint(
            x: normalizedPoint.x * image.extent.width,
            y: (1 - normalizedPoint.y) * image.extent.height
        )
        let patch = CGRect(x: center.x - 4, y: center.y - 4, width: 9, height: 9)
            .intersection(image.extent)
        let average = image.applyingFilter("CIAreaAverage", parameters: [kCIInputExtentKey: CIVector(cgRect: patch)])
        var rgba = [Float](repeating: 0, count: 4)
        ColorScopes.context.render(
            average, toBitmap: &rgba, rowBytes: 4 * MemoryLayout<Float>.size,
            bounds: CGRect(x: 0, y: 0, width: 1, height: 1), format: .RGBAf, colorSpace: nil)
        var hue: CGFloat = 0, saturation: CGFloat = 0, brightness: CGFloat = 0, alpha: CGFloat = 0
        NSColor(red: CGFloat(rgba[0]), green: CGFloat(rgba[1]), blue: CGFloat(rgba[2]), alpha: 1)
            .getHue(&hue, saturation: &saturation, brightness: &brightness, alpha: &alpha)
        return saturation >= 0.12 ? Double(hue) : nil
    }

    // MARK: - Seek Coordinator

    private func enqueueInteractiveSeek(time: CMTime, tolerance: CMTime) {
        pendingInteractiveSeek = (time, tolerance)
        guard interactiveThrottleTask == nil else { return }

        let elapsed = CACurrentMediaTime() - lastInteractiveDispatchTime
        let delay = max(0, Self.interactiveSeekInterval - elapsed)
        guard delay > 0 else {
            flushPendingInteractiveSeek()
            return
        }

        interactiveThrottleTask = Task { @MainActor [weak self] in
            try? await Task.sleep(nanoseconds: UInt64(delay * 1_000_000_000))
            guard !Task.isCancelled else { return }
            self?.interactiveThrottleTask = nil
            self?.flushPendingInteractiveSeek()
        }
    }

    private func flushPendingInteractiveSeek() {
        guard let pending = pendingInteractiveSeek else { return }
        pendingInteractiveSeek = nil
        lastInteractiveDispatchTime = CACurrentMediaTime()
        performSeek(time: pending.time, tolerance: pending.tolerance)
    }

    private func performSeek(time: CMTime, tolerance: CMTime) {
        guard let item = player.currentItem else { return }
        item.cancelPendingSeeks()
        player.seek(to: time, toleranceBefore: tolerance, toleranceAfter: tolerance)
    }

    private func seekPlayer(to time: CMTime) async -> Bool {
        await withCheckedContinuation { continuation in
            player.seek(to: time, toleranceBefore: .zero, toleranceAfter: .zero) { completed in
                continuation.resume(returning: completed)
            }
        }
    }

    private func playerTime(forPreviewFrame frame: Int) -> CMTime? {
        guard let fps = editor?.timeline.fps, fps > 0 else { return nil }
        return SourceMediaTimebase.absoluteTime(
            relativeFrame: frame,
            fps: fps,
            trackStart: sourceTrackStart
        )
    }

    private func invalidateSeekState() {
        player.currentItem?.cancelPendingSeeks()
        cancelInteractiveSeek()
        lastInteractiveDispatchTime = 0
    }

    private func cancelInteractiveSeek() {
        interactiveThrottleTask?.cancel()
        interactiveThrottleTask = nil
        pendingInteractiveSeek = nil
    }

    private func interactiveTolerance(activeLayerCount: Int) -> CMTime {
        let seconds = min(0.75, 0.15 * Double(max(1, activeLayerCount)))
        return CMTime(seconds: seconds, preferredTimescale: 600)
    }

    private func activeVideoLayerCount(at frame: Int, editor: EditorViewModel) -> Int {
        guard editor.activePreviewTab == .timeline else { return 1 }
        return editor.timeline.tracks.count { track in
            guard track.type == .video, !track.hidden else { return false }
            return track.clips.contains { clip in
                (clip.mediaType == .video || clip.mediaType == .image || clip.mediaType == .sequence)
                    && frame >= clip.startFrame
                    && frame < clip.endFrame
            }
        }
    }

    // MARK: - Time Observer

    nonisolated static func visualRefreshAction(
        isPlaying: Bool,
        playbackRate: PreviewPlaybackRate
    ) -> VisualRefreshAction {
        guard isPlaying else { return .seekToActiveFrame }
        return playbackRate.allowsAudioMetering ? .meterPlayback : .none
    }

    private func installPlaybackEndObserver() {
        playbackEndObserver = NotificationCenter.default.addObserver(
            forName: AVPlayerItem.didPlayToEndTimeNotification,
            object: nil,
            queue: .main
        ) { [weak self] notification in
            guard let object = notification.object else { return }
            let itemIdentifier = ObjectIdentifier(object as AnyObject)
            MainActor.assumeIsolated {
                self?.handlePlaybackEnd(for: itemIdentifier)
            }
        }
    }

    private func handlePlaybackEnd(for itemIdentifier: ObjectIdentifier) {
        guard let item = player.currentItem,
              ObjectIdentifier(item) == itemIdentifier,
              let editor else { return }
        pause()
        let duration = playbackDurationFrames(for: editor)
        if editor.activePreviewTab == .timeline {
            editor.currentFrame = duration
        } else {
            editor.sourcePlayheadFrame = duration
        }
    }

    private func installTimeObserver(for playbackRate: PreviewPlaybackRate) {
        if let timeObserver {
            player.removeTimeObserver(timeObserver)
            self.timeObserver = nil
        }
        let interval = Self.playheadObserverInterval(for: playbackRate)
        timeObserver = player.addPeriodicTimeObserver(forInterval: interval, queue: .main) { [weak self] time in
            MainActor.assumeIsolated {
                self?.updatePlaybackTime(time)
            }
        }
    }

    private func updatePlaybackTime(_ time: CMTime) {
        guard let editor, editor.isPlaying, !editor.isScrubbing else { return }
        if editor.playbackRate.allowsAudioMetering {
            scrubAudioEngine.meterPlayback(at: time)
        }

        let frame = SourceMediaTimebase.relativeFrame(
            absoluteTime: time,
            fps: editor.timeline.fps,
            trackStart: sourceTrackStart
        )
        let duration = playbackDurationFrames(for: editor)
        let clamped = duration > 0 ? min(frame, duration) : frame
        if editor.activePreviewTab == .timeline {
            editor.currentFrame = clamped
        } else {
            editor.sourcePlayheadFrame = clamped
        }
        if duration > 0, frame >= duration {
            pause()
        }
    }

    nonisolated static func playheadObserverInterval(for playbackRate: PreviewPlaybackRate) -> CMTime {
        let updatesPerSecond = 30.0
        return CMTime(
            seconds: Double(playbackRate.rawValue) / updatesPerSecond,
            preferredTimescale: 600
        )
    }

    private func playbackStartFrame(for editor: EditorViewModel) -> Int {
        let duration = playbackDurationFrames(for: editor)
        guard duration > 0 else { return 0 }
        let current = editor.activePreviewTab == .timeline ? editor.currentFrame : editor.sourcePlayheadFrame
        guard current >= duration else { return current }
        if editor.activePreviewTab == .timeline {
            editor.currentFrame = 0
        } else {
            editor.sourcePlayheadFrame = 0
        }
        return 0
    }

    private func playbackDurationFrames(for editor: EditorViewModel) -> Int {
        guard editor.activePreviewTab == .timeline else {
            return editor.activePreviewDurationFrames
        }
        return Self.frameCount(for: compositionDuration, fps: editor.timeline.fps)
    }

    nonisolated static func frameCount(for duration: CMTime, fps: Int) -> Int {
        guard duration.isNumeric,
              let timescale = CMTimeScale(exactly: fps),
              timescale > 0 else { return 0 }
        let scaled = CMTimeConvertScale(duration, timescale: timescale, method: .roundHalfAwayFromZero)
        guard let frames = Int(exactly: scaled.value) else { return 0 }
        return max(0, frames)
    }

    private static let interactiveSeekInterval: TimeInterval = 1.0 / 30.0
}
